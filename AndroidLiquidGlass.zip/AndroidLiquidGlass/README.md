# Liquid Glass Card

Aplikasi Android sederhana: satu card liquid glass yang bisa digeser dan dikustomisasi
(judul, ukuran, sudut, blur, kegelapan, kilau, tepi cahaya, refraksi, aberasi warna).

Efek glass memakai library [`backdrop`](./backdrop) dari
[Kyant0/AndroidLiquidGlass](https://github.com/Kyant0/AndroidLiquidGlass).

## Build

```
./gradlew :androidApp:assembleDebug
```

APK ada di `androidApp/build/outputs/apk/debug/`.

> Blur butuh Android 12+ (API 31), lens/refraksi butuh Android 13+ (API 33).
> Di versi lebih lama card tampil tanpa efek tersebut.
