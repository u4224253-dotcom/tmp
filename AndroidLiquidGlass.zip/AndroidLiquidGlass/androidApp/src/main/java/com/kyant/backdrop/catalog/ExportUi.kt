package com.kyant.backdrop.catalog

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.kyant.backdrop.Backdrop
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.ContinuationInterceptor
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.coroutineContext
import kotlin.math.abs

/** Keadaan dialog export. [fraction] 0..1; [finished] true kalau selesai atau gagal ([isError]). */
internal data class ExportUiState(
    val phase: String,
    val fraction: Float,
    val etaSec: Int? = null,
    val finished: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false
)

/**
 * Seluruh alur export (tahap 1-5 digabung): tunggu analisis audio -> tangkap kaca -> render video ->
 * gabung audio -> simpan ke galeri. Harus dijalankan dari coroutine di thread utama (penangkapan kaca
 * butuh thread utama); bagian berat pindah ke background sendiri. Pembatalan = batalkan coroutine-nya.
 */
internal suspend fun runExport(
    context: Context,
    player: AudioPlayerState,
    bg: BackgroundState,
    capture: GlassCapture,
    measurer: TextMeasurer,
    ink: Color,
    radiusDp: Float,
    onState: (ExportUiState) -> Unit
) {
    val job = coroutineContext[Job]!!
    val startNs = System.nanoTime()
    fun emit(phase: String, f: Float) {
        if (!job.isActive) return
        val elapsed = (System.nanoTime() - startNs) / 1e9
        val eta = if (f > 0.08f) (elapsed * (1f - f) / f).toInt() else null
        onState(ExportUiState(phase, f.coerceIn(0f, 1f), eta))
    }

    val spec = ExportSpec()
    val videoOnly = File(context.cacheDir, "export_video_only.mp4")
    val finalFile = File(context.cacheDir, "export_final.mp4")
    val videoBgUri = bg.videoUri
    var videoBg: VideoFrameSource? = null
    var holding = false
    try {
        val audioUri = player.sourceUri
        if (audioUri == null || !player.loaded || player.durationMs <= 0) {
            throw IllegalStateException("Pilih file audio dulu (ketuk judul di card).")
        }

        emit("Menganalisis audio…", 0f)
        player.awaitAnalysis()

        emit("Merender kaca…", 0.02f)
        fun checkSize(b: ImageBitmap) {
            if (b.width != spec.width || b.height != spec.height) {
                throw IllegalStateException(
                    "Ukuran hasil tangkapan ${b.width}x${b.height}, seharusnya ${spec.width}x${spec.height}"
                )
            }
        }
        var base: ImageBitmap? = null
        var baseAt: (suspend (Float) -> ImageBitmap)? = null
        if (videoBgUri == null) {
            // foto / wallpaper: kaca cukup dirender sekali
            val b = capture.capture()
            checkSize(b)
            base = b
        } else {
            // video: kaca harus dirender ulang tiap frame karena yang dibiaskan ikut bergerak
            val src = withContext(Dispatchers.IO) { VideoFrameSource.open(context, videoBgUri) }
                ?: throw IllegalStateException("Video background tidak bisa dibuka untuk export.")
            videoBg = src
            capture.hold()
            holding = true
            val ui = coroutineContext[ContinuationInterceptor]
            var sizeChecked = false
            baseAt = { tMs ->
                val bmp = withContext(Dispatchers.IO) { src.frameAt(tMs.toLong(), spec.height) }
                withContext(ui ?: EmptyCoroutineContext) {
                    if (bmp != null) bg.frame = bmp.asImageBitmap()
                    val shot = capture.grab()
                    if (!sizeChecked) {
                        sizeChecked = true
                        checkSize(shot)
                    }
                    shot
                }
            }
        }

        // card di canvas export: 360 x 640 dp logis dikali kerapatan (1080 / 360 = 3)
        val k = spec.width / CanvasWDp
        val cardW = CardWDp * k
        val cardH = CardHDp * k
        val card = CardGeometry(
            left = (spec.width - cardW) / 2f,
            top = (spec.height - cardH) / 2f,
            width = cardW,
            height = cardH,
            radius = radiusDp.coerceAtMost(CardWDp / 2f) * k
        )

        val snapshot = player.controlsSnapshot()
        val levels = player.createOfflineLevels()

        emit("Merender video…", 0.03f)
        val video = renderVideoTrack(videoOnly, spec, base, baseAt, card, ink, snapshot, levels, measurer) {
            emit("Merender video…", 0.03f + 0.77f * it)
        }
        if (video.framesWritten == 0) throw IllegalStateException("Encoder tidak menghasilkan frame")
        val videoDurationUs = video.framesWritten * 1_000_000L / spec.fps

        emit("Menggabungkan audio…", 0.8f)
        muxVideoWithAudio(context, audioUri, videoOnly, finalFile, videoDurationUs) {
            emit("Menggabungkan audio…", 0.8f + 0.17f * it)
        }

        emit("Menyimpan ke galeri…", 0.97f)
        val title = player.customTitle.takeIf { it.isNotBlank() } ?: player.title ?: "LiquidGlass"
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val where = saveVideoToGallery(context, finalFile, "${title}_$stamp")

        val dropped = abs(video.framesExpected - video.framesWritten)
        val warn = if (dropped > 2) {
            "\nPeringatan: encoder hanya menulis ${video.framesWritten} dari ${video.framesExpected} frame, " +
                "video bisa lebih pendek dari audio."
        } else ""
        onState(ExportUiState("Selesai", 1f, finished = true, message = "Tersimpan di $where$warn"))
    } catch (e: CancellationException) {
        throw e
    } catch (e: Throwable) {
        onState(
            ExportUiState(
                "Export gagal", 0f, finished = true, isError = true,
                message = e.message ?: e.javaClass.simpleName
            )
        )
    } finally {
        if (holding) capture.release()
        videoBg?.close()
        if (videoBgUri != null) bg.refreshKey++ // preview ambil ulang frame pada posisi sekarang
        runCatching { videoOnly.delete() }
        runCatching { finalFile.delete() }
    }
}

/** Tombol Export di dock. [enabled] false (belum ada audio) -> redup dan tidak bisa diketuk. */
@Composable
internal fun ExportButton(backdrop: Backdrop, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .alpha(if (enabled) 1f else 0.5f)
            .fillMaxWidth()
            .height(46f.dp)
            .glass(backdrop, 23f.dp)
            .clip(RoundedCornerShape(23f.dp))
            .clickable(interactionSource = null, indication = null, enabled = enabled) { onClick() }
            .padding(start = 18f.dp, end = 16f.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicText(
            if (enabled) "Export video (MP4 1080p)" else "Export video: pilih audio dulu",
            style = dockText(14f, FontWeight.SemiBold),
            maxLines = 1
        )
        Canvas(Modifier.size(18f.dp)) { drawExportIcon() }
    }
}

/** Ikon unduh: panah ke bawah di atas garis alas. Grid 24 x 24. */
private fun DrawScope.drawExportIcon() {
    val k = size.width / 24f
    val path = Path().apply {
        moveTo(12f, 4f); lineTo(12f, 15f)
        moveTo(7f, 10.5f); lineTo(12f, 15.5f); lineTo(17f, 10.5f)
        moveTo(5f, 20f); lineTo(19f, 20f)
    }
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawPath(path, DockInk, style = Stroke(width = 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Dialog modal: progres selama export, lalu hasil / galat. Tidak bisa ditutup dengan back selama berjalan. */
@Composable
internal fun ExportDialog(state: ExportUiState, onCancel: () -> Unit, onClose: () -> Unit) {
    Dialog(
        onDismissRequest = { if (state.finished) onClose() },
        properties = DialogProperties(dismissOnBackPress = state.finished, dismissOnClickOutside = false)
    ) {
        val shape = RoundedCornerShape(20f.dp)
        Column(
            Modifier
                .width(300f.dp)
                .background(Color.White, shape)
                .border(1f.dp, DockInk.copy(alpha = 0.12f), shape)
                .padding(20f.dp),
            verticalArrangement = Arrangement.spacedBy(14f.dp)
        ) {
            BasicText(
                if (state.finished) state.phase else "Mengekspor video",
                style = dockText(16f, FontWeight.SemiBold)
            )
            if (!state.finished) {
                BasicText(state.phase, style = dockText(13f, FontWeight.Normal, DockInk.copy(alpha = 0.7f)))
                // bar progres datar: latar tipis + isi warna solid
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(6f.dp)
                        .background(DockInk.copy(alpha = 0.12f), RoundedCornerShape(3f.dp))
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(state.fraction.coerceIn(0f, 1f))
                            .height(6f.dp)
                            .background(DockAccent, RoundedCornerShape(3f.dp))
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    BasicText(
                        "${(state.fraction * 100).toInt()}%",
                        style = dockText(12f, FontWeight.Medium).copy(fontFeatureSettings = "tnum")
                    )
                    BasicText(
                        state.etaSec?.let { "sisa ± ${formatEta(it)}" } ?: "",
                        style = dockText(12f, FontWeight.Normal, DockInk.copy(alpha = 0.6f))
                    )
                }
                BasicText(
                    "Biarkan layar tetap menyala sampai selesai.",
                    style = dockText(11.5f, FontWeight.Normal, DockInk.copy(alpha = 0.55f))
                )
            } else {
                BasicText(
                    state.message ?: "",
                    style = dockText(
                        13f, FontWeight.Normal,
                        if (state.isError) Color(0xFFB3261E) else DockInk.copy(alpha = 0.8f)
                    )
                )
            }
            DialogButton(
                label = if (state.finished) "Tutup" else "Batal",
                filled = state.finished,
                onClick = if (state.finished) onClose else onCancel
            )
        }
    }
}

@Composable
private fun DialogButton(label: String, filled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22f.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .height(44f.dp)
            .then(
                if (filled) Modifier.background(DockInk, shape)
                else Modifier.border(1f.dp, DockInk.copy(alpha = 0.25f), shape)
            )
            .clip(shape)
            .clickable(interactionSource = null, indication = null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        BasicText(
            label,
            style = dockText(14f, FontWeight.SemiBold, if (filled) Color.White else DockInk)
        )
    }
}

private fun formatEta(sec: Int): String =
    if (sec >= 60) "${sec / 60} mnt ${sec % 60} dtk" else "$sec dtk"
