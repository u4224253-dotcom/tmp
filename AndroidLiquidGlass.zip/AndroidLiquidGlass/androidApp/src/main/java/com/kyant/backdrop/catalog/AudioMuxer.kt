package com.kyant.backdrop.catalog

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.min

private const val AacMime = MediaFormat.MIMETYPE_AUDIO_AAC

/** Pilih jalur pertama yang mime-nya diawali [prefix] ("audio/" atau "video/"); null kalau tidak ada. */
private fun MediaExtractor.selectFirstTrack(prefix: String): MediaFormat? {
    for (i in 0 until trackCount) {
        val f = getTrackFormat(i)
        val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
        if (mime.startsWith(prefix)) {
            selectTrack(i)
            return f
        }
    }
    return null
}

/**
 * Tahap 5a: gabungkan video tanpa suara ([videoOnly]) dengan audio lagu menjadi [outFile] (MP4).
 *
 * Audio AAC (m4a/aac) disalin langsung tanpa dikodekan ulang. Format lain (mp3, wav, ogg, flac, dll)
 * di-decode lalu di-encode ke AAC LC 192 kbps lebih dulu. Audio dipotong sampai sepanjang video.
 *
 * @param videoDurationUs panjang video; audio yang lebih panjang dipotong
 * @param onProgress 0..1 untuk seluruh tahap ini
 */
internal suspend fun muxVideoWithAudio(
    context: Context,
    audioUri: Uri,
    videoOnly: File,
    outFile: File,
    videoDurationUs: Long,
    onProgress: (Float) -> Unit
): Unit = withContext(Dispatchers.IO) {
    val tempAac = File(outFile.parentFile, outFile.nameWithoutExtension + "_audio.m4a")
    var finished = false
    var muxer: MediaMuxer? = null
    var muxerStarted = false
    val vEx = MediaExtractor()
    val aEx = MediaExtractor()
    try {
        // --- siapkan sumber audio: salin langsung kalau sudah AAC, kalau tidak transcode dulu ---
        val probe = MediaExtractor()
        val srcMime: String? = try {
            probe.setDataSource(context, audioUri, null)
            probe.selectFirstTrack("audio/")?.getString(MediaFormat.KEY_MIME)
        } finally {
            probe.release()
        }
        if (srcMime == null) throw IllegalStateException("File audio tidak punya jalur suara")

        val audioIsAac = srcMime == AacMime
        if (audioIsAac) {
            aEx.setDataSource(context, audioUri, null)
        } else {
            transcodeToAac(context, audioUri, tempAac, videoDurationUs) { onProgress(it * 0.8f) }
            aEx.setDataSource(tempAac.absolutePath)
        }
        val audioFormat = aEx.selectFirstTrack("audio/")
            ?: throw IllegalStateException("Jalur audio hasil konversi tidak terbaca")

        vEx.setDataSource(videoOnly.absolutePath)
        val videoFormat = vEx.selectFirstTrack("video/")
            ?: throw IllegalStateException("Jalur video tidak terbaca")

        val m = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer = m
        val vTrack = m.addTrack(videoFormat)
        val aTrack = m.addTrack(audioFormat)
        m.start()
        muxerStarted = true

        // --- tulis sampel video & audio bergantian menurut waktu supaya file enak diputar ---
        val buf = ByteBuffer.allocateDirect(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        val baseProgress = if (audioIsAac) 0f else 0.8f
        val span = 1f - baseProgress

        fun copySample(ex: MediaExtractor, track: Int) {
            buf.clear()
            val size = ex.readSampleData(buf, 0)
            if (size < 0) return
            info.set(
                0, size, ex.sampleTime,
                if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
            )
            m.writeSampleData(track, buf, info)
            ex.advance()
        }

        while (true) {
            ensureActive()
            val vt = vEx.sampleTime // -1 kalau habis
            var at = aEx.sampleTime
            if (at > videoDurationUs) at = -1L // audio lebih panjang dari video: potong
            if (vt < 0 && at < 0) break
            if (vt >= 0 && (at < 0 || vt <= at)) {
                copySample(vEx, vTrack)
                onProgress(baseProgress + span * (vt.toFloat() / videoDurationUs).coerceIn(0f, 1f))
            } else {
                copySample(aEx, aTrack)
            }
        }
        m.stop()
        muxerStarted = false
        finished = true
    } finally {
        runCatching { if (muxerStarted) muxer?.stop() }
        runCatching { muxer?.release() }
        runCatching { vEx.release() }
        runCatching { aEx.release() }
        runCatching { tempAac.delete() }
        if (!finished) runCatching { outFile.delete() }
    }
    onProgress(1f)
}

/**
 * Decode audio apa pun lalu encode ke AAC LC (stereo/mono) di [out] (m4a). Berhenti di [limitUs].
 * Timestamp dihitung dari jumlah sampel PCM supaya tepat.
 */
private suspend fun transcodeToAac(
    context: Context,
    uri: Uri,
    out: File,
    limitUs: Long,
    onProgress: (Float) -> Unit
) = withContext(Dispatchers.IO) {
    val ex = MediaExtractor()
    var dec: MediaCodec? = null
    var enc: MediaCodec? = null
    var muxer: MediaMuxer? = null
    var muxerStarted = false
    var done = false
    try {
        ex.setDataSource(context, uri, null)
        val inFmt = ex.selectFirstTrack("audio/") ?: throw IllegalStateException("File audio tidak punya jalur suara")
        val d = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
        dec = d
        d.configure(inFmt, null, null, 0)
        d.start()
        val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer = m

        val decInfo = MediaCodec.BufferInfo()
        val encInfo = MediaCodec.BufferInfo()
        var decInEos = false
        var decOutEos = false
        var encInEos = false
        var sampleRate = 0
        var channels = 0
        var pcm: ByteArray? = null
        var pcmOff = 0
        var framesFed = 0L // jumlah sampel PCM (per kanal) yang sudah masuk ke encoder
        var track = -1

        fun makeEncoder(sr: Int, ch: Int): MediaCodec {
            require(ch in 1..2) { "Audio dengan $ch kanal belum didukung (hanya mono/stereo)" }
            val fmt = MediaFormat.createAudioFormat(AacMime, sr, ch).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            }
            return MediaCodec.createEncoderByType(AacMime).also {
                it.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                it.start()
            }
        }

        while (!done) {
            ensureActive()

            // 1. umpan decoder dengan data terkompres dari file
            if (!decInEos) {
                val ii = d.dequeueInputBuffer(0)
                if (ii >= 0) {
                    val ib = d.getInputBuffer(ii)!!
                    val n = ex.readSampleData(ib, 0)
                    val t = ex.sampleTime
                    if (n < 0 || t > limitUs) {
                        d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        decInEos = true
                    } else {
                        d.queueInputBuffer(ii, 0, n, t, 0)
                        ex.advance()
                        if (limitUs > 0) onProgress((t.toFloat() / limitUs).coerceIn(0f, 1f))
                    }
                }
            }

            // 2. ambil PCM dari decoder (satu potongan sekali waktu)
            if (pcm == null && !decOutEos) {
                val oi = d.dequeueOutputBuffer(decInfo, 0)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = d.outputFormat
                    sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (enc == null) enc = makeEncoder(sampleRate, channels)
                } else if (oi >= 0) {
                    if (decInfo.size > 0) {
                        val ob = d.getOutputBuffer(oi)!!
                        val bytes = ByteArray(decInfo.size)
                        ob.position(decInfo.offset)
                        ob.limit(decInfo.offset + decInfo.size)
                        ob.get(bytes)
                        pcm = bytes
                        pcmOff = 0
                    }
                    if (decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) decOutEos = true
                    d.releaseOutputBuffer(oi, false)
                }
            }

            // 3. masukkan PCM ke encoder (atau tandai akhir)
            val e = enc
            if (e != null) {
                val ptsUs = framesFed * 1_000_000L / sampleRate
                val p = pcm
                if (p != null) {
                    val ei = e.dequeueInputBuffer(0)
                    if (ei >= 0) {
                        val eb = e.getInputBuffer(ei)!!
                        eb.clear()
                        val frameBytes = 2 * channels // PCM 16-bit
                        var n = min(eb.remaining(), p.size - pcmOff)
                        n -= n % frameBytes
                        eb.put(p, pcmOff, n)
                        e.queueInputBuffer(ei, 0, n, ptsUs, 0)
                        framesFed += n / frameBytes
                        pcmOff += n
                        if (pcmOff >= p.size) {
                            pcm = null
                            pcmOff = 0
                        }
                    }
                } else if (decOutEos && !encInEos) {
                    val ei = e.dequeueInputBuffer(0)
                    if (ei >= 0) {
                        e.queueInputBuffer(ei, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        encInEos = true
                    }
                }

                // 4. ambil AAC dari encoder dan tulis ke file m4a sementara
                val eo = e.dequeueOutputBuffer(encInfo, 2_000L)
                if (eo == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = m.addTrack(e.outputFormat)
                    m.start()
                    muxerStarted = true
                } else if (eo >= 0) {
                    val ob = e.getOutputBuffer(eo)
                    if (encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) encInfo.size = 0
                    if (encInfo.size > 0 && muxerStarted && ob != null) {
                        ob.position(encInfo.offset)
                        ob.limit(encInfo.offset + encInfo.size)
                        m.writeSampleData(track, ob, encInfo)
                    }
                    e.releaseOutputBuffer(eo, false)
                    if (encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) done = true
                }
            }
        }
    } finally {
        runCatching { dec?.stop() }
        runCatching { dec?.release() }
        runCatching { enc?.stop() }
        runCatching { enc?.release() }
        runCatching { if (muxerStarted) muxer?.stop() }
        runCatching { muxer?.release() }
        runCatching { ex.release() }
        if (!done) runCatching { out.delete() }
    }
}

/**
 * Tahap 5b: simpan [file] (MP4 final) ke galeri. Mengembalikan teks lokasi untuk ditampilkan ke pengguna.
 *
 * Android 10+: lewat MediaStore ke Movies/LiquidGlass (tanpa izin). Android 9 ke bawah: disalin ke folder
 * Movies milik aplikasi (tanpa izin) lalu dipindai supaya muncul di galeri.
 */
internal suspend fun saveVideoToGallery(context: Context, file: File, displayName: String): String =
    withContext(Dispatchers.IO) {
        val safe = displayName.replace(Regex("[^A-Za-z0-9 _.-]"), "_").trim().ifEmpty { "LiquidGlass" }
        val fileName = "$safe.mp4"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/LiquidGlass")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Gagal membuat berkas di galeri")
            try {
                resolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
                    ?: throw IllegalStateException("Gagal menulis ke galeri")
                resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) {
                runCatching { resolver.delete(uri, null, null) }
                throw e
            }
            "Movies/LiquidGlass/$fileName"
        } else {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
            val dest = File(dir, fileName)
            file.copyTo(dest, overwrite = true)
            MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), arrayOf("video/mp4"), null)
            dest.absolutePath
        }
    }
