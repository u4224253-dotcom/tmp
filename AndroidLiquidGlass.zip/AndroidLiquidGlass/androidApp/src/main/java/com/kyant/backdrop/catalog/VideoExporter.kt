package com.kyant.backdrop.catalog

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.inset
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.ceil
import kotlin.math.min

/** Pengaturan video hasil export. */
internal class ExportSpec(
    val width: Int = 1080,
    val height: Int = 1920,
    val fps: Int = 30,
    val bitrate: Int = 8_000_000
)

/** Posisi dan bentuk card di canvas export (satuan pixel canvas, bukan dp). */
internal class CardGeometry(
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
    val radius: Float
)

/** [framesWritten] = jumlah frame yang keluar dari encoder, [framesExpected] = yang dikirim ke encoder. */
internal class VideoTrackResult(val framesWritten: Int, val framesExpected: Int)

private const val VideoMime = MediaFormat.MIMETYPE_VIDEO_AVC

/**
 * Tahap 4 export: menghasilkan MP4 H.264 TANPA suara ([outFile]).
 *
 * Tiap frame: [base] (foto + kaca, dirender sekali) digambar penuh, lalu controls digambar di atasnya
 * dengan waktu lagu pada frame itu, di-clip ke bentuk card. Frame dikirim ke encoder lewat Surface.
 * Dikerjakan di background; bisa dibatalkan lewat pembatalan coroutine (file sementara dihapus).
 *
 * @param snapshot kondisi controls dasar (judul, artis, sampul, volume, durasi); posisi & status putar diisi per frame
 * @param onProgress 0..1
 */
internal suspend fun renderVideoTrack(
    outFile: File,
    spec: ExportSpec,
    base: ImageBitmap,
    card: CardGeometry,
    ink: Color,
    snapshot: ControlsSnapshot,
    levels: OfflineLevels,
    measurer: TextMeasurer,
    onProgress: (Float) -> Unit
): VideoTrackResult = withContext(Dispatchers.Default) {
    val fps = spec.fps
    val total = ceil(snapshot.durationMs * fps / 1000.0).toInt().coerceAtLeast(1)

    val format = MediaFormat.createVideoFormat(VideoMime, spec.width, spec.height).apply {
        setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        setInteger(MediaFormat.KEY_BIT_RATE, spec.bitrate)
        setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
    }

    var codec: MediaCodec? = null
    var surface: android.view.Surface? = null
    var muxer: MediaMuxer? = null
    var muxerStarted = false
    var trackIndex = -1
    var written = 0
    var finished = false

    try {
        val c = MediaCodec.createEncoderByType(VideoMime)
        codec = c
        c.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val s = c.createInputSurface()
        surface = s
        c.start()
        val m = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer = m

        val info = MediaCodec.BufferInfo()

        // Mengambil semua keluaran encoder yang sudah siap. Timestamp ditulis ulang dari nomor frame
        // (gambar lewat Canvas ke Surface membawa waktu jam dinding, bukan waktu video).
        fun drain(endOfStream: Boolean) {
            var idleTries = 0
            while (true) {
                val idx = c.dequeueOutputBuffer(info, if (endOfStream) 10_000L else 0L)
                when {
                    idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!endOfStream) return
                        if (++idleTries > 500) throw IllegalStateException("Encoder video tidak selesai (timeout)")
                    }
                    idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        trackIndex = m.addTrack(c.outputFormat)
                        m.start()
                        muxerStarted = true
                    }
                    idx >= 0 -> {
                        idleTries = 0
                        val buf = c.getOutputBuffer(idx)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0 && muxerStarted && buf != null) {
                            info.presentationTimeUs = written * 1_000_000L / fps
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            m.writeSampleData(trackIndex, buf, info)
                            written++
                        }
                        c.releaseOutputBuffer(idx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }
        }

        val drawScope = CanvasDrawScope()
        val density = Density(1f)
        val frameSize = Size(spec.width.toFloat(), spec.height.toFloat())
        val lv = FloatArray(EqBars)
        val cardClip = Path().apply {
            addRoundRect(RoundRect(0f, 0f, card.width, card.height, CornerRadius(card.radius, card.radius)))
        }

        for (i in 0 until total) {
            ensureActive()
            val tMs = min(i * 1000f / fps, snapshot.durationMs.toFloat())
            levels.advanceTo(tMs, lv)
            val snap = snapshot.copy(positionMs = tMs.toInt(), isPlaying = true, eqActive = 1f)

            val androidCanvas = s.lockHardwareCanvas()
            try {
                drawScope.draw(density, LayoutDirection.Ltr, Canvas(androidCanvas), frameSize) {
                    drawExportFrame(base, card, cardClip, ink, snap, measurer, lv)
                }
            } finally {
                s.unlockCanvasAndPost(androidCanvas)
            }
            drain(false)
            onProgress((i + 1f) / total)
        }

        c.signalEndOfInputStream()
        drain(true)
        finished = true
        VideoTrackResult(framesWritten = written, framesExpected = total)
    } finally {
        runCatching { codec?.stop() }
        runCatching { codec?.release() }
        runCatching { surface?.release() }
        runCatching { if (muxerStarted) muxer?.stop() }
        runCatching { muxer?.release() }
        if (!finished) runCatching { outFile.delete() } // dibatalkan atau gagal: jangan tinggalkan file rusak
    }
}

/** Satu frame: layer statis + controls (di-clip ke bentuk card) dengan posisi/levels pada waktu frame. */
private fun DrawScope.drawExportFrame(
    base: ImageBitmap,
    card: CardGeometry,
    cardClip: Path,
    ink: Color,
    snap: ControlsSnapshot,
    measurer: TextMeasurer,
    levels: FloatArray
) {
    drawImage(base)
    inset(
        left = card.left,
        top = card.top,
        right = size.width - card.left - card.width,
        bottom = size.height - card.top - card.height
    ) {
        clipPath(cardClip) {
            drawPlayerControlsFitted(ink, snap, measurer, levels)
        }
    }
}
