package com.kyant.backdrop.catalog

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.toIntSize

/**
 * Menangkap isi canvas (foto + blur + kaca liquid glass) ke satu bitmap, TANPA isi controls.
 * Dipakai export video: bagian berat ini cukup dirender sekali, controls digambar ulang tiap frame di atasnya.
 *
 * Saat tidak menangkap, [glassCapture] tidak menambah kerja apa pun (langsung drawContent biasa).
 */
@Stable
internal class GlassCapture(internal val layer: GraphicsLayer) {
    /** true selama penangkapan: canvas direkam ke [layer] dan controls disembunyikan. */
    var capturing by mutableStateOf(false)
        private set

    /**
     * Render canvas 1080x1920 sekali dan kembalikan sebagai bitmap. Harus dipanggil dari coroutine
     * di thread utama. Controls hilang sekitar 2 frame; tutup dengan dialog progres supaya tidak terlihat berkedip.
     */
    suspend fun capture(): ImageBitmap {
        capturing = true
        try {
            return grab()
        } finally {
            capturing = false
        }
    }

    /** Ambil bitmap canvas saat ini (setelah [capturing] true). */
    private suspend fun grab(): ImageBitmap {
        // frame 1: komposisi ulang + gambar direkam ke layer; frame 2: pastikan efek GPU sudah jadi
        withFrameNanos { }
        withFrameNanos { }
        return layer.toImageBitmap()
    }
}

@Composable
internal fun rememberGlassCapture(): GlassCapture {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassCapture(layer) }
}

/** Pasang di node yang membungkus seluruh isi canvas (ukuran pixel asli). */
internal fun Modifier.glassCapture(capture: GlassCapture): Modifier = drawWithContent {
    if (capture.capturing) {
        val outer = Density(density, fontScale)
        val scope = this
        capture.layer.record(size.toIntSize()) {
            // sama seperti library backdrop: record() memakai density 1, kembalikan ke density node
            val prev = drawContext.density
            drawContext.density = outer
            try {
                scope.drawContent()
            } finally {
                drawContext.density = prev
            }
        }
        drawLayer(capture.layer)
    } else {
        drawContent()
    }
}
