package com.kyant.backdrop.catalog

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

private val CometCyan = intArrayOf(25, 184, 255)
private val CometIndigo = intArrayOf(45, 91, 255)
private val CometViolet = intArrayOf(123, 75, 255)

/** Gradasi cyan -> indigo -> violet (warna maskot). [t] 0..1 dari ekor ke kepala, [a] alpha 0..1. */
private fun cometColor(t: Float, a: Float): Color {
    val x = t.coerceIn(0f, 1f)
    val (p, q, k) = if (x < .5f) Triple(CometCyan, CometIndigo, x * 2f) else Triple(CometIndigo, CometViolet, (x - .5f) * 2f)
    return Color(
        (p[0] + (q[0] - p[0]) * k).toInt(),
        (p[1] + (q[1] - p[1]) * k).toInt(),
        (p[2] + (q[2] - p[2]) * k).toInt(),
        (a.coerceIn(0f, 1f) * 255f).toInt()
    )
}

/**
 * Komet tipis yang sesekali berlari menyusuri tepi tombol (jalur tertutup mengikuti sudut [radius]).
 * Muncul di waktu, titik awal, dan arah acak; kepala dan ekor meruncing; ada cahaya lembut di dalam tombol
 * yang ikut berjalan. Digambar di atas isi tombol. Saat [enabled] false efek berhenti dan hilang.
 * Dipindahkan dari AmbientEdge.kt di proyek ChordFinderIsland.
 */
@Composable
internal fun Modifier.cometBorder(radius: Dp, enabled: Boolean = true): Modifier {
    val prog = remember { Animatable(0f) }
    var dir by remember { mutableFloatStateOf(1f) }
    var lenDp by remember { mutableFloatStateOf(80f) }
    var amp by remember { mutableFloatStateOf(1f) }
    var from by remember { mutableFloatStateOf(0f) }   // titik awal sebagai pecahan keliling 0..1

    LaunchedEffect(enabled) {
        if (!enabled) {
            prog.snapTo(0f)
            return@LaunchedEffect
        }
        delay(Random.nextLong(800, 2500))
        while (true) {
            dir = if (Random.nextBoolean()) 1f else -1f
            lenDp = 60f + Random.nextFloat() * 50f
            amp = .7f + Random.nextFloat() * .3f
            from = Random.nextFloat()
            prog.snapTo(0f)
            prog.animateTo(1f, tween(Random.nextInt(1500, 2600), easing = CubicBezierEasing(.45f, 0f, .55f, 1f)))
            delay(Random.nextLong(1800, 6000))   // jeda acak sebelum muncul lagi
        }
    }

    return this.drawWithCache {
        val inset = 1.5f.dp.toPx()                 // garis duduk sedikit di dalam supaya tidak terpotong clip
        val r = radius.toPx()
        val line = Path().apply {
            addRoundRect(
                RoundRect(
                    inset, inset, size.width - inset, size.height - inset,
                    CornerRadius((r - inset).coerceAtLeast(0f))
                )
            )
        }
        val silhouette = Path().apply {
            addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r)))
        }
        val measure = PathMeasure().also { it.setPath(line, true) }
        val total = measure.length
        val glowR = 40f.dp.toPx()
        val maxW = 2.4f.dp.toPx()

        fun at(d: Float): Float {                  // jarak -> posisi di jalur (melingkar, bisa dibalik)
            val s = ((d % total) + total) % total
            return if (dir > 0f) s else total - s
        }

        onDrawWithContent {
            drawContent()
            val p = prog.value
            if (p <= 0f || p >= 1f || total <= 0f) return@onDrawWithContent

            val len = lenDp.dp.toPx().coerceAtMost(total * .5f)
            val head = (from + p * .85f) * total   // jalan sekitar 85% keliling
            val env = sin(PI.toFloat() * p)        // pelan muncul, pelan hilang
            val a = amp * env
            val n = 36

            clipPath(silhouette) {
                val c = measure.getPosition(at(head - len * .35f))
                drawCircle(
                    brush = Brush.radialGradient(
                        0f to cometColor(.75f, .22f * a),
                        .5f to cometColor(.6f, .08f * a),
                        1f to cometColor(.5f, 0f),
                        center = c, radius = glowR
                    ),
                    radius = glowR, center = c
                )
                for (i in 0 until n) {
                    val t0 = i / n.toFloat()
                    val t1 = (i + 1) / n.toFloat()
                    val s0 = at(head - len + t0 * len)
                    val s1 = at(head - len + t1 * len)
                    if (abs(s1 - s0) > total * .5f) continue   // segmen melintasi titik awal jalur: lewati
                    val tm = (t0 + t1) / 2f
                    val taper = sin(PI.toFloat() * tm.pow(1.5f)).coerceAtLeast(0f)   // runcing di kepala dan ekor
                    val w = maxW * taper
                    if (w < .05f) continue
                    drawLine(
                        cometColor(tm, a * taper.pow(.6f)),
                        measure.getPosition(s0), measure.getPosition(s1),
                        strokeWidth = w, cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}
