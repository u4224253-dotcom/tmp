package com.kyant.backdrop.catalog

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Isi card: elemen dari playing_controls.svg (336 x 600), digambar di Canvas dan sekarang
 * INTERAKTIF lewat [AudioPlayerState]:
 *  - ketuk sampul        -> pilih gambar sampul (persegi, di-crop tengah)
 *  - ketuk judul / artis -> edit teksnya langsung di card (kolom teks muncul di tempatnya)
 *  - tahan judul / artis -> pilih file audio (kalau belum ada audio, cukup ketuk)
 *  - ketuk titik progress / play saat belum ada audio -> pilih file audio
 *  - ikon play/pause     -> putar / jeda (ikon pause = Vector.svg)
 *  - bar progress        -> ikut durasi lagu, bisa diketuk & digeser (model sama dengan volume)
 *  - rewind / forward    -> mundur / maju 10 detik
 *  - bar volume          -> hanya tampilan, tidak berfungsi (volume audio default)
 *
 * Koordinat sama persis dengan SVG; seluruhnya diskalakan seragam agar muat di card
 * dan ditaruh di tengah. Warna elemen = [ink].
 */
private const val SvgW = 336f
private const val SvgH = 600f

private const val PATH_PLAY =
    "M157.61 473.988C156.028 473.988 154.914 472.777 154.914 470.844V442.992C154.914 441.059 156.028 439.848 157.61 439.848C158.45 439.848 159.153 440.141 160.051 440.668L183.059 453.988C184.758 454.965 185.422 455.707 185.422 456.918C185.422 458.129 184.758 458.871 183.059 459.848L160.051 473.188C159.153 473.695 158.45 473.988 157.61 473.988Z"

private const val PATH_REWIND =
    "M83.3389 466.016C82.7803 466.016 82.2979 465.851 81.752 465.533L68.752 457.891C67.7998 457.332 67.3301 456.659 67.3301 455.809C67.3301 454.971 67.7998 454.311 68.752 453.739L81.752 446.097C82.3106 445.779 82.7803 445.614 83.3389 445.614C84.4434 445.614 85.3701 446.452 85.3701 447.988V455.301C85.5225 454.691 85.9795 454.184 86.7285 453.739L99.7285 446.097C100.287 445.779 100.757 445.614 101.315 445.614C102.42 445.614 103.347 446.452 103.347 447.988V463.642C103.347 465.178 102.42 466.016 101.315 466.016C100.757 466.016 100.274 465.851 99.7285 465.533L86.7285 457.891C85.9795 457.446 85.5225 456.938 85.3701 456.329V463.642C85.3701 465.178 84.4434 466.016 83.3389 466.016Z"

private const val PATH_FORWARD =
    "M235.269 466.016C234.164 466.016 233.237 465.178 233.237 463.642V447.988C233.237 446.452 234.164 445.614 235.269 445.614C235.827 445.614 236.297 445.779 236.855 446.097L249.855 453.739C250.605 454.184 251.062 454.691 251.214 455.301V447.988C251.214 446.452 252.141 445.614 253.245 445.614C253.804 445.614 254.273 445.779 254.832 446.097L267.832 453.739C268.797 454.311 269.267 454.971 269.267 455.809C269.267 456.659 268.784 457.332 267.832 457.891L254.832 465.533C254.286 465.851 253.804 466.016 253.258 466.016C252.141 466.016 251.214 465.178 251.214 463.642V456.329C251.062 456.938 250.605 457.446 249.855 457.891L236.855 465.533C236.31 465.851 235.827 466.016 235.269 466.016Z"

private const val PATH_VOL_LOW =
    "M33.9248 523.098C33.6011 523.098 33.3345 522.971 33.0171 522.667L30.3574 520.159C30.3193 520.121 30.2686 520.108 30.2114 520.108H28.415C27.4819 520.108 26.9805 519.588 26.9805 518.61V516.249C26.9805 515.265 27.4819 514.751 28.415 514.751H30.2114C30.2686 514.751 30.3193 514.732 30.3574 514.7L33.0171 512.206C33.3599 511.875 33.5947 511.742 33.9121 511.742C34.3945 511.742 34.7437 512.123 34.7437 512.593V522.286C34.7437 522.755 34.3945 523.098 33.9248 523.098Z"

private const val PATH_VOL_HIGH =
    "M305.088 523.644C304.79 523.454 304.745 523.085 304.955 522.755C305.926 521.289 306.529 519.442 306.529 517.417C306.529 515.392 305.926 513.558 304.955 512.085C304.745 511.755 304.79 511.387 305.088 511.196C305.361 511.012 305.729 511.082 305.932 511.393C307.03 513.069 307.716 515.138 307.716 517.417C307.716 519.702 307.049 521.778 305.932 523.447C305.729 523.752 305.361 523.828 305.088 523.644ZM296.925 523.098C296.595 523.098 296.328 522.971 296.011 522.667L293.357 520.159C293.319 520.121 293.269 520.108 293.211 520.108H291.409C290.482 520.108 289.98 519.588 289.98 518.61V516.249C289.98 515.265 290.482 514.751 291.409 514.751H293.211C293.269 514.751 293.319 514.732 293.357 514.7L296.011 512.206C296.36 511.875 296.588 511.742 296.912 511.742C297.395 511.742 297.737 512.123 297.737 512.593V522.286C297.737 522.755 297.395 523.098 296.925 523.098ZM302.536 521.93C302.238 521.74 302.2 521.372 302.416 521.042C303.082 520.045 303.482 518.756 303.482 517.417C303.482 516.071 303.095 514.783 302.416 513.792C302.193 513.462 302.238 513.094 302.536 512.904C302.822 512.72 303.171 512.79 303.368 513.082C304.199 514.237 304.675 515.811 304.675 517.417C304.675 519.023 304.199 520.584 303.368 521.752C303.171 522.044 302.822 522.108 302.536 521.93ZM299.997 520.235C299.692 520.026 299.642 519.664 299.876 519.302C300.226 518.794 300.429 518.122 300.429 517.417C300.429 516.706 300.232 516.033 299.876 515.532C299.635 515.176 299.692 514.808 299.997 514.605C300.264 514.421 300.619 514.484 300.81 514.757C301.324 515.449 301.622 516.414 301.622 517.417C301.622 518.42 301.324 519.391 300.81 520.07C300.619 520.35 300.264 520.407 299.997 520.235Z"

private const val PATH_AIRPLAY =
    "M134.486 557.007C134.486 552.317 138.321 548.449 143.044 548.449C147.759 548.449 151.602 552.317 151.602 557.007C151.602 559.364 150.623 561.514 149.07 563.05C148.946 563.174 148.796 563.174 148.68 563.042L148.29 562.602C148.182 562.469 148.19 562.344 148.298 562.228C149.635 560.892 150.473 559.041 150.473 557.007C150.473 552.956 147.111 549.586 143.044 549.586C138.968 549.586 135.606 552.956 135.606 557.007C135.606 559.032 136.445 560.883 137.781 562.228C137.889 562.344 137.897 562.469 137.79 562.593L137.399 563.033C137.283 563.166 137.125 563.174 137.009 563.042C135.457 561.506 134.486 559.364 134.486 557.007ZM136.901 557.007C136.901 553.637 139.657 550.864 143.044 550.864C146.431 550.864 149.178 553.637 149.178 557.007C149.178 558.642 148.531 560.12 147.468 561.224C147.352 561.365 147.186 561.356 147.078 561.224L146.671 560.784C146.563 560.667 146.58 560.535 146.68 560.41C147.526 559.53 148.049 558.327 148.049 557.007C148.049 554.268 145.792 552.001 143.044 552.001C140.296 552.001 138.039 554.268 138.039 557.007C138.039 558.327 138.553 559.522 139.4 560.41C139.5 560.535 139.516 560.667 139.4 560.784L139.01 561.215C138.894 561.34 138.728 561.356 138.611 561.215C137.549 560.12 136.901 558.642 136.901 557.007ZM139.317 557.007C139.317 554.965 140.994 553.28 143.044 553.28C145.094 553.28 146.763 554.965 146.763 557.007C146.763 557.912 146.431 558.742 145.866 559.364C145.75 559.522 145.584 559.522 145.459 559.381L145.053 558.949C144.945 558.841 144.953 558.717 145.028 558.592C145.41 558.177 145.634 557.613 145.634 557.007C145.634 555.596 144.455 554.417 143.044 554.417C141.625 554.417 140.454 555.596 140.454 557.007C140.454 557.604 140.678 558.169 141.043 558.592C141.126 558.708 141.135 558.833 141.027 558.941L140.62 559.373C140.496 559.514 140.321 559.514 140.213 559.364C139.657 558.733 139.317 557.912 139.317 557.007ZM137.889 565.283C137.491 565.283 137.333 564.859 137.59 564.569L142.662 558.825C142.861 558.601 143.21 558.601 143.409 558.825L148.481 564.569C148.738 564.859 148.581 565.283 148.182 565.283H137.889Z"

internal val PlayerPaths: List<Path> by lazy {
    listOf(
        PATH_PLAY, PATH_REWIND, PATH_FORWARD, PATH_VOL_LOW, PATH_VOL_HIGH, PATH_AIRPLAY
    ).map { PathParser().parsePathString(it).toPath() }
}

private const val IX_PLAY = 0
private const val IX_REWIND = 1
private const val IX_FORWARD = 2
private const val IX_VOL_LOW = 3
private const val IX_VOL_HIGH = 4
private const val IX_AIRPLAY = 5

// ---- geometri (koordinat SVG 336 x 600) ----
// Semua angka diukur piksel-per-piksel dari screenshot referensi iOS (kartu 866 px lebar),
// dikonversi: svgX = 168 + (px - 540) / 2.577 ; svgY = 300 + (px - 1069) / 2.577.
private const val CoverX = 25f
private const val CoverY = 24f
private const val CoverS = 286f
private const val CoverR = 9f

private const val ProgX = 24.8f
private const val ProgY = 393.1f
private const val ProgW = 286.4f
private const val VolX = 51.6f
private const val VolY = 515.7f
private const val VolW = 222.3f
private const val BarH = 7f

private const val TextX = 25f
private const val TitleBaseline = 349.3f
private const val ArtistBaseline = 367.9f
private const val TitleMaxW = 246 // berhenti sebelum indikator spectrum (x = 279)

private const val EqX0 = 280.1f // pusat batang pertama, jarak antar batang 4
private const val EqCY = 353.5f // sejajar di antara baris judul dan artist

// Tinggi batang spectrum (unit SVG) dari video referensi: tiap batang punya rentang sendiri.
// Batang tengah punya dasar tinggi (bentuk busur) dan hanya bergoyang, batang tepi berayun lebar.
// Urutan: bass -> treble.  Diukur dari 2576 frame (60 fps): persentil 5 -> EqLo, persentil 95+ -> EqHi.
private val EqLo = floatArrayOf(2.3f, 2.2f, 8.5f, 9.3f, 8.5f, 4.7f)
private val EqHi = floatArrayOf(15.5f, 11.5f, 16f, 18f, 15.5f, 15.5f)
// Kurva per batang (level^gamma) supaya sebaran tinggi sama dengan referensi:
// batang tepi lebih sering rendah lalu menghentak, batang tengah lebih sering di atas.
private val EqGamma = floatArrayOf(2.0f, 2.1f, 2.0f, 1.3f, 1.8f, 2.4f)
private const val EqDot = 2.2f // tinggi titik saat dijeda

// Inter (SIL OFL, bebas lisensi) = font paling mirip SF Pro; pengganti font iOS yang berlisensi
internal val PlayerFont = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold)
)

private val PlayCenter = Offset(168f, 457.9f)
private val RewindCenter = Offset(98.9f, 457.9f)
private val ForwardCenter = Offset(236.7f, 457.9f)

// path ikon dari SVG lama digeser ke pusat baru (pusat lama: rewind 85.3, forward 251.2, y 455.8)
private val PlayShift = Offset(-1.5f, 1f)
private val RewindShift = Offset(RewindCenter.x - 85.3f, RewindCenter.y - 455.8f)
private val ForwardShift = Offset(ForwardCenter.x - 251.2f, ForwardCenter.y - 455.8f)

// area sentuh
private val RectCover = Rect(CoverX, CoverY, CoverX + CoverS, CoverY + CoverS)
private val RectTitle = Rect(20f, 328f, 316f, 374f)
private const val TitleSplitY = 356f   // di atas garis ini = judul, di bawah = artis
private val RectProgress = Rect(20f, 380f, 316f, 410f)

private fun toSvg(p: Offset, w: Int, h: Int): Offset {
    val s = min(w / SvgW, h / SvgH)
    return Offset((p.x - (w - SvgW * s) / 2f) / s, (p.y - (h - SvgH * s) / 2f) / s)
}

@Composable
fun PlayerControls(ink: Color, player: AudioPlayerState, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val measurer = rememberTextMeasurer()
    // tinggi batang spectrum (0..1), diperbarui tiap frame dari analisis lagu.
    // Loop hanya jalan saat diputar, dan berhenti setelah semua batang turun ke dasar.
    val levels = remember { FloatArray(EqBars) }
    var frame by remember { mutableIntStateOf(0) }
    LaunchedEffect(player.isPlaying) {
        var last = 0L
        while (true) {
            val settled = withFrameMillis { t ->
                val dt = if (last == 0L) 0.016f else ((t - last) / 1000f).coerceIn(0.001f, 0.1f)
                last = t
                player.updateLevels(levels, t / 1000f, dt)
                frame++
                !player.isPlaying && player.eqActive < 0.01f && levels.all { it < 0.01f }
            }
            if (settled) break
        }
    }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) player.load(uri)
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { player.loadCover(uri) }
    }

    // ---- edit judul / artis langsung di card ----
    var editing by remember { mutableIntStateOf(0) }   // 0 = tidak mengedit, 1 = judul, 2 = artis
    var editValue by remember { mutableStateOf(TextFieldValue("")) }
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    fun commitEdit() {
        val t = editValue.text.trim()
        when (editing) {
            1 -> player.customTitle = t   // kosong = kembali otomatis dari file
            2 -> player.customArtist = t
        }
        editing = 0
        focusManager.clearFocus()
        keyboard?.hide()
    }
    fun startEdit(which: Int) {
        val snap = player.controlsSnapshot()
        val t = if (which == 1) snap.titleLine else snap.artistLine
        editValue = TextFieldValue(t, TextRange(0, t.length))   // semua terpilih: langsung ketik untuk mengganti
        editing = which
    }

    BoxWithConstraints(modifier) {
    Canvas(
        Modifier.fillMaxSize().pointerInput(player) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = true)
                val w = size.width
                val h = size.height
                val p = toSvg(down.position, w, h)
                if (editing != 0) commitEdit()   // ketuk di luar kolom teks = selesai mengedit
                fun inCircle(c: Offset, r: Float) = (p - c).getDistance() <= r
                // fraksi 0..1 dari posisi jari pada bar tertentu
                fun frac(pos: Offset, x0: Float, width: Float) =
                    ((toSvg(pos, w, h).x - x0) / width).coerceIn(0f, 1f)

                when {
                    RectCover.contains(p) -> {
                        if (awaitTap()) imagePicker.launch(arrayOf("image/*"))
                    }
                    RectTitle.contains(p) -> {
                        if (!player.loaded) {
                            if (awaitTap()) audioPicker.launch(arrayOf("audio/*"))
                        } else {
                            // ketuk = edit teks yang diketuk; tahan = ganti file audio
                            var upChange: PointerInputChange? = null
                            val released = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                upChange = waitForUpOrCancellation()
                                true
                            }
                            val up = upChange
                            when {
                                released == null -> {
                                    audioPicker.launch(arrayOf("audio/*"))
                                    waitForUpOrCancellation()
                                }
                                up != null -> {
                                    up.consume()
                                    startEdit(if (p.y < TitleSplitY) 1 else 2)
                                }
                            }
                        }
                    }
                    RectProgress.contains(p) -> {
                        if (player.loaded) {
                            dragSlider(
                                down = down,
                                toFraction = { frac(it, ProgX, ProgW) },
                                onChange = { player.scrubFraction = it },
                                onEnd = { player.commitScrub(it) }
                            )
                        } else if (awaitTap()) {
                            audioPicker.launch(arrayOf("audio/*"))
                        }
                    }
                    inCircle(PlayCenter, 34f) -> {
                        if (awaitTap()) {
                            if (player.loaded) player.toggle() else audioPicker.launch(arrayOf("audio/*"))
                        }
                    }
                    inCircle(RewindCenter, 30f) -> {
                        if (awaitTap()) player.skip(-10_000)
                    }
                    inCircle(ForwardCenter, 30f) -> {
                        if (awaitTap()) player.skip(10_000)
                    }
                    // bar volume: hanya tampilan, sengaja tidak berfungsi (volume audio dibiarkan default)
                }
            }
        }
    ) {
        if (frame < 0) return@Canvas // dibaca hanya supaya gambar ikut dirender ulang tiap frame
        // baris yang sedang diedit tidak digambar di canvas (digantikan kolom teks di atasnya)
        val snap = player.controlsSnapshot().let {
            when (editing) {
                1 -> it.copy(titleLine = "")
                2 -> it.copy(artistLine = "")
                else -> it
            }
        }
        drawPlayerControlsFitted(ink, snap, measurer, levels)
    }

    // kolom teks inline: tepat di posisi baris yang diketuk, font/ukuran/warna sama dengan yang digambar
    key(editing) {
        if (editing != 0) {
            val density = LocalDensity.current
            val wPx = constraints.maxWidth.toFloat()
            val hPx = constraints.maxHeight.toFloat()
            val sc = min(wPx / SvgW, hPx / SvgH)
            val ox = (wPx - SvgW * sc) / 2f
            val oy = (hPx - SvgH * sc) / 2f
            val isTitle = editing == 1
            val fs = if (isTitle) 16f else 14.8f
            val baseline = if (isTitle) TitleBaseline else ArtistBaseline
            val focus = remember { FocusRequester() }
            var hadFocus by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) { focus.requestFocus() }
            BasicTextField(
                value = editValue,
                onValueChange = { editValue = it },
                singleLine = true,
                textStyle = TextStyle(
                    fontSize = with(density) { (fs * sc).toSp() },
                    fontWeight = if (isTitle) FontWeight.SemiBold else FontWeight.Normal,
                    fontFamily = PlayerFont,
                    letterSpacing = with(density) { (sfTracking(fs) * sc).toSp() },
                    color = if (isTitle) ink else ink.copy(alpha = 0.6f)
                ),
                cursorBrush = SolidColor(ink),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { commitEdit() }),
                modifier = Modifier
                    .offset {
                        IntOffset(
                            (ox + TextX * sc).roundToInt(),
                            (oy + (baseline - 0.97f * fs) * sc).roundToInt()
                        )
                    }
                    .width(with(density) { (TitleMaxW * sc).toDp() })
                    .focusRequester(focus)
                    .onFocusChanged {
                        if (it.isFocused) hadFocus = true
                        else if (hadFocus && editing != 0) commitEdit()   // fokus hilang (ketuk di luar card) = simpan
                    }
            )
        }
    }
    }
}

/**
 * Semua nilai yang dibutuhkan untuk menggambar controls pada satu saat. Dipisah dari [AudioPlayerState]
 * supaya controls bisa digambar untuk waktu mana pun (dipakai export video), bukan hanya posisi putar sekarang.
 */
internal data class ControlsSnapshot(
    val cover: ImageBitmap?,
    val titleLine: String,
    val artistLine: String,
    val loaded: Boolean,
    val isPlaying: Boolean,
    val eqActive: Float,   // 0..1
    val volume: Float,     // 0..1
    val positionMs: Int,
    val durationMs: Int,
    val spectrumColor: Color? = null   // null = default (ink, alpha 0.4)
) {
    val fraction: Float
        get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
}

/** Foto keadaan player saat ini (termasuk posisi geser progress bar kalau sedang digeser). */
internal fun AudioPlayerState.controlsSnapshot(): ControlsSnapshot {
    val scrub = scrubFraction
    val pos = if (scrub != null) (scrub * durationMs).toInt() else positionMs
    return ControlsSnapshot(
        cover = cover,
        titleLine = customTitle.takeIf { it.isNotBlank() } ?: title ?: "Pilih file audio",
        artistLine = customArtist.takeIf { it.isNotBlank() }
            ?: if (loaded) artist ?: "Artis tidak diketahui" else "Nama artis",
        loaded = loaded,
        isPlaying = isPlaying,
        eqActive = eqActive,
        volume = volume,
        positionMs = pos,
        durationMs = durationMs,
        spectrumColor = spectrumColor
    )
}

/** Menggambar controls dengan skala "fit" ke ukuran DrawScope (sama persis dengan tampilan di layar). */
internal fun DrawScope.drawPlayerControlsFitted(
    ink: Color,
    snap: ControlsSnapshot,
    measurer: TextMeasurer,
    levels: FloatArray
) {
    val s = min(size.width / SvgW, size.height / SvgH)
    val ox = (size.width - SvgW * s) / 2f
    val oy = (size.height - SvgH * s) / 2f
    withTransform({
        translate(ox, oy)
        scale(s, s, pivot = Offset.Zero)
    }) {
        drawPlayerControls(ink, PlayerPaths, snap, measurer, levels)
    }
}

/** Tap = jari naik tanpa dibatalkan (mis. oleh geseran card). Mengonsumsi event up. */
private suspend fun AwaitPointerEventScope.awaitTap(): Boolean {
    val up = waitForUpOrCancellation()
    up?.consume()
    return up != null
}

/** Slider horizontal: nilai berubah saat disentuh dan saat digeser; [onEnd] saat jari dilepas. */
private suspend fun AwaitPointerEventScope.dragSlider(
    down: PointerInputChange,
    toFraction: (Offset) -> Float,
    onChange: (Float) -> Unit,
    onEnd: (Float) -> Unit
) {
    down.consume()
    var f = toFraction(down.position)
    onChange(f)
    drag(down.id) { change ->
        change.consume()
        f = toFraction(change.position)
        onChange(f)
    }
    onEnd(f)
}

private fun formatTime(ms: Int): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val sec = total % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%d:%02d", m, sec)
}

/** Teks dengan ukuran dalam satuan SVG (density 1f supaya 1.sp = 1 unit SVG). [align]: 0 kiri, 0.5 tengah, 1 kanan. */
/**
 * Kerapatan huruf ala tabel tracking SF Pro: makin besar makin rapat (16 -> -0.30, 14.8 -> -0.21,
 * 13 -> -0.08), 12 netral, di bawah itu sedikit renggang supaya teks kecil tetap terbaca.
 */
internal fun sfTracking(size: Float): Float = if (size >= 12f) (12f - size) * 0.075f else 0.06f

private fun DrawScope.svgText(
    measurer: TextMeasurer,
    text: String,
    fontSize: Float,
    weight: FontWeight,
    color: Color,
    x: Float,
    baselineY: Float,
    align: Float = 0f,
    maxWidth: Int = Constraints.Infinity,
    tabular: Boolean = false // angka lebar sama (seperti jam di iOS) supaya 0:09 -> 0:10 tidak bergeser
) {
    val layout = measurer.measure(
        text = text,
        style = TextStyle(
            fontSize = fontSize.sp,
            fontWeight = weight,
            fontFamily = PlayerFont,
            letterSpacing = sfTracking(fontSize).sp, // 1 sp = 1 unit SVG di sini (density 1)
            fontFeatureSettings = if (tabular) "tnum" else null
        ),
        overflow = TextOverflow.Ellipsis,
        softWrap = false,
        maxLines = 1,
        constraints = Constraints(maxWidth = maxWidth),
        density = Density(1f, 1f)
    )
    drawText(
        layout,
        color = color,
        topLeft = Offset(x - layout.size.width * align, baselineY - layout.firstBaseline)
    )
}

private fun DrawScope.drawPlayerControls(
    ink: Color,
    p: List<Path>,
    snap: ControlsSnapshot,
    measurer: TextMeasurer,
    levels: FloatArray
) {
    fun roundRect(x: Float, y: Float, w: Float, h: Float, r: Float, alpha: Float) {
        drawRoundRect(ink.copy(alpha = alpha), Offset(x, y), Size(w, h), CornerRadius(r, r))
    }
    fun fill(index: Int, alpha: Float = 1f, dx: Float = 0f, dy: Float = 0f) {
        withTransform({ translate(dx, dy) }) { drawPath(p[index], ink.copy(alpha = alpha)) }
    }

    val duration = snap.durationMs
    val fraction = snap.fraction
    val positionMs = snap.positionMs

    // 1. sampul persegi: gambar upload (crop tengah) atau placeholder
    val cover = snap.cover
    if (cover != null) {
        val side = min(cover.width, cover.height)
        val clip = Path().apply {
            addRoundRect(RoundRect(CoverX, CoverY, CoverX + CoverS, CoverY + CoverS, CoverR, CoverR))
        }
        clipPath(clip) {
            drawImage(
                image = cover,
                srcOffset = IntOffset((cover.width - side) / 2, (cover.height - side) / 2),
                srcSize = IntSize(side, side),
                dstOffset = IntOffset(CoverX.toInt(), CoverY.toInt()),
                dstSize = IntSize(CoverS.toInt(), CoverS.toInt()),
                filterQuality = FilterQuality.High
            )
        }
    } else {
        roundRect(CoverX, CoverY, CoverS, CoverS, CoverR, 0.25f)
        roundRect(154f, 155f, 28f, 3f, 1.5f, 0.55f)
        roundRect(166.5f, 142.5f, 3f, 28f, 1.5f, 0.55f)
        svgText(measurer, "Upload sampul", 13f, FontWeight.Medium, ink.copy(alpha = 0.55f), 168f, 197f, align = 0.5f)
    }

    // 2. judul (nama file audio) + 3. nama artist tepat di bawahnya
    svgText(
        measurer, snap.titleLine, 16f, FontWeight.SemiBold,
        ink, TextX, TitleBaseline, maxWidth = TitleMaxW
    )
    svgText(
        measurer, snap.artistLine, 14.8f, FontWeight.Normal,
        ink.copy(alpha = 0.6f), TextX, ArtistBaseline, maxWidth = TitleMaxW
    )

    // 4. spectrum: 6 batang rounded, tinggi mengikuti energi frekuensi lagu (bass -> treble).
    //    Diam jadi titik saat dijeda.
    val eqW = 2.2f
    val active = snap.eqActive.coerceIn(0f, 1f)
    val barColor = snap.spectrumColor?.copy(alpha = 0.9f) ?: ink.copy(alpha = 0.4f)
    for (i in 0 until EqBars) {
        val moving = EqLo[i] + (EqHi[i] - EqLo[i]) * levels[i].coerceIn(0f, 1f).pow(EqGamma[i])
        val h = EqDot + (moving - EqDot) * active
        val cx = EqX0 + 4f * i
        drawRoundRect(
            barColor,
            Offset(cx - eqW / 2f, EqCY - h / 2f),
            Size(eqW, h),
            CornerRadius(eqW / 2f, eqW / 2f)
        )
    }

    // 5. progress lagu: track bulat + isi bulat kedua sisi
    roundRect(ProgX, ProgY, ProgW, BarH, BarH / 2f, 0.15f)
    if (fraction > 0f) {
        val fw = ProgW * fraction
        val r = min(BarH / 2f, fw / 2f)
        drawRoundRect(ink.copy(alpha = 0.65f), Offset(ProgX, ProgY), Size(fw, BarH), CornerRadius(r, r))
    }

    // 6-7. waktu berjalan / sisa
    val left = if (snap.loaded) formatTime(positionMs) else "--:--"
    val right = if (snap.loaded) "-" + formatTime(duration - positionMs) else "--:--"
    svgText(measurer, left, 11f, FontWeight.Medium, ink.copy(alpha = 0.8f), 25.3f, 419.5f, tabular = true)
    svgText(measurer, right, 11f, FontWeight.Medium, ink.copy(alpha = 0.5f), 310.7f, 419.5f, align = 1f, tabular = true)

    // 8-10. play / pause (dua batang 10.3 x 34.1, jarak 5), rewind, forward
    if (snap.isPlaying) {
        val barW = 10.3f
        val gap = 5f
        val barH = 34.1f
        val l = PlayCenter.x - (barW * 2f + gap) / 2f
        val t = PlayCenter.y - barH / 2f
        drawRoundRect(ink, Offset(l, t), Size(barW, barH), CornerRadius(2.6f, 2.6f))
        drawRoundRect(ink, Offset(l + barW + gap, t), Size(barW, barH), CornerRadius(2.6f, 2.6f))
    } else {
        fill(IX_PLAY, dx = PlayShift.x, dy = PlayShift.y)
    }
    fill(IX_REWIND, dx = RewindShift.x, dy = RewindShift.y)
    fill(IX_FORWARD, dx = ForwardShift.x, dy = ForwardShift.y)

    // 11-13. volume: track, isi, ikon speaker (ikon diturunkan 1.6 agar sejajar tengah bar)
    roundRect(VolX, VolY, VolW, BarH, BarH / 2f, 0.15f)
    val vw = VolW * snap.volume
    if (vw > 0f) {
        val vr = min(BarH / 2f, vw / 2f)
        drawRoundRect(ink.copy(alpha = 0.65f), Offset(VolX, VolY), Size(vw, BarH), CornerRadius(vr, vr))
    }
    fill(IX_VOL_LOW, 0.4f, dy = 1.6f)
    fill(IX_VOL_HIGH, 0.4f, dy = 1.6f)

    // 14-16. pil AirPlay 90.8 x 33.8: latar, ikon (diperkecil 0.85), teks "AirPlay"
    roundRect(123f, 542.1f, 90.8f, 33.8f, 16.9f, 0.1f)
    withTransform({
        translate(-0.64f, 1.7f)
        scale(0.85f, 0.85f, pivot = Offset(143.04f, 556.9f))
    }) {
        drawPath(p[IX_AIRPLAY], ink)
    }
    svgText(measurer, "AirPlay", 13.5f, FontWeight.Medium, ink, 155.2f, 562.8f)
}
