package com.kyant.backdrop.catalog

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.min

/**
 * Isi card: elemen dari playing_controls.svg (336 x 600), digambar di Canvas dan sekarang
 * INTERAKTIF lewat [AudioPlayerState]:
 *  - ketuk sampul        -> pilih gambar sampul (persegi, di-crop tengah)
 *  - ketuk judul / titik -> pilih file audio
 *  - ikon play/pause     -> putar / jeda (ikon pause = Vector.svg)
 *  - bar progress        -> ikut durasi lagu, bisa diketuk & digeser (model sama dengan volume)
 *  - rewind / forward    -> mundur / maju 10 detik
 *  - bar volume          -> bisa digeser
 *
 * Koordinat sama persis dengan SVG; seluruhnya diskalakan seragam agar muat di card
 * dan ditaruh di tengah. Warna elemen = [ink].
 */
private const val SvgW = 336f
private const val SvgH = 600f

private const val PATH_PLAY =
    "M157.61 473.988C156.028 473.988 154.914 472.777 154.914 470.844V442.992C154.914 441.059 156.028 439.848 157.61 439.848C158.45 439.848 159.153 440.141 160.051 440.668L183.059 453.988C184.758 454.965 185.422 455.707 185.422 456.918C185.422 458.129 184.758 458.871 183.059 459.848L160.051 473.188C159.153 473.695 158.45 473.988 157.61 473.988Z"

private const val PATH_REWIND =
    "M83.3389 466.016C82.7803 466.016 82.2979 465.851 81.752 465.533L68.752 457.891C67.7998 457.332 67.3301 456.659 67.3301 455.809C67.3301 454.971 67.7998 454.311 68.752 453.739L81.752 446.097C82.3106 445.779 82.7803 445.614 83.3389 445.614C84.4434 445.614 85.3701 446.452 85.3701 447.988V455.301C85.5225 454.691 85.9795 454.184 86.7285 453.739L99.7285 446.097C100.287 445.779 100.757 445.614 101.315 445.614C102.42 445.614 103.347 446.452 103.347 447.988V463.642C103.347 465.178 102.42 466.016 101.315 466.016C100.757 466.016 100.274 465.851 99.7285 465.533L86.7285 457.891C85.9795 457.446 85.5225 456.938 85.3701 456.329V463.642C85.3701 465.178 84.4434 466.016 83.3389 466.016Z"

private const val PATH_FORWARD =
    "M235.269 466.016C234.164 466.016 233.237 465.178 233.237 463.642V447.988C233.237 446.452 234.164 445.614 235.269 445.614C235.827 445.614 236.297 445.779 236.855 446.097L249.855 453.739C250.605 454.184 251.062 454.691 251.214 455.301V447.988C251.214 446.452 252.141 445.614 253.245 445.614C253.804 445.614 254.273 445.779 254.832 446.097L267.832 453.739C268.797 454.311 269.267 454.971 269.267 455.809C269.267 456.659 268.784 457.332 267.832 457.891L254.832 465.533C254.286 465.851 253.804 466.016 253.258 466.016C252.141 466.016 251.214 465.178 251.214 463.642V456.329C251.062 456.938 250.605 457.446 249.855 457.891L236.855 465.533C236.31 465.851 235.827 466.016 235.269 466.016Z"

private const val PATH_VOL_LOW =
    "M33.9248 523.098C33.6011 523.098 33.3345 522.971 33.0171 522.667L30.3574 520.159C30.3193 520.121 30.2686 520.108 30.2114 520.108H28.415C27.4819 520.108 26.9805 519.588 26.9805 518.61V516.249C26.9805 515.265 27.4819 514.751 28.415 514.751H30.2114C30.2686 514.751 30.3193 514.732 30.3574 514.7L33.0171 512.206C33.3599 511.875 33.5947 511.742 33.9121 511.742C34.3945 511.742 34.7437 512.123 34.7437 512.593V522.286C34.7437 522.755 34.3945 523.098 33.9248 523.098Z"

private const val PATH_VOL_HIGH =
    "M305.088 523.644C304.79 523.454 304.745 523.085 304.955 522.755C305.926 521.289 306.529 519.442 306.529 517.417C306.529 515.392 305.926 513.558 304.955 512.085C304.745 511.755 304.79 511.387 305.088 511.196C305.361 511.012 305.729 511.082 305.932 511.393C307.03 513.069 307.716 515.138 307.716 517.417C307.716 519.702 307.049 521.778 305.932 523.447C305.729 523.752 305.361 523.828 305.088 523.644ZM296.925 523.098C296.595 523.098 296.328 522.971 296.011 522.667L293.357 520.159C293.319 520.121 293.269 520.108 293.211 520.108H291.409C290.482 520.108 289.98 519.588 289.98 518.61V516.249C289.98 515.265 290.482 514.751 291.409 514.751H293.211C293.269 514.751 293.319 514.732 293.357 514.7L296.011 512.206C296.36 511.875 296.588 511.742 296.912 511.742C297.395 511.742 297.737 512.123 297.737 512.593V522.286C297.737 522.755 297.395 523.098 296.925 523.098ZM302.536 521.93C302.238 521.74 302.2 521.372 302.416 521.042C303.082 520.045 303.482 518.756 303.482 517.417C303.482 516.071 303.095 514.783 302.416 513.792C302.193 513.462 302.238 513.094 302.536 512.904C302.822 512.72 303.171 512.79 303.368 513.082C304.199 514.237 304.675 515.811 304.675 517.417C304.675 519.023 304.199 520.584 303.368 521.752C303.171 522.044 302.822 522.108 302.536 521.93ZM299.997 520.235C299.692 520.026 299.642 519.664 299.876 519.302C300.226 518.794 300.429 518.122 300.429 517.417C300.429 516.706 300.232 516.033 299.876 515.532C299.635 515.176 299.692 514.808 299.997 514.605C300.264 514.421 300.619 514.484 300.81 514.757C301.324 515.449 301.622 516.414 301.622 517.417C301.622 518.42 301.324 519.391 300.81 520.07C300.619 520.35 300.264 520.407 299.997 520.235Z"

private const val PATH_AIRPLAY =
    "M134.486 557.007C134.486 552.317 138.321 548.449 143.044 548.449C147.759 548.449 151.602 552.317 151.602 557.007C151.602 559.364 150.623 561.514 149.07 563.05C148.946 563.174 148.796 563.174 148.68 563.042L148.29 562.602C148.182 562.469 148.19 562.344 148.298 562.228C149.635 560.892 150.473 559.041 150.473 557.007C150.473 552.956 147.111 549.586 143.044 549.586C138.968 549.586 135.606 552.956 135.606 557.007C135.606 559.032 136.445 560.883 137.781 562.228C137.889 562.344 137.897 562.469 137.79 562.593L137.399 563.033C137.283 563.166 137.125 563.174 137.009 563.042C135.457 561.506 134.486 559.364 134.486 557.007ZM136.901 557.007C136.901 553.637 139.657 550.864 143.044 550.864C146.431 550.864 149.178 553.637 149.178 557.007C149.178 558.642 148.531 560.12 147.468 561.224C147.352 561.365 147.186 561.356 147.078 561.224L146.671 560.784C146.563 560.667 146.58 560.535 146.68 560.41C147.526 559.53 148.049 558.327 148.049 557.007C148.049 554.268 145.792 552.001 143.044 552.001C140.296 552.001 138.039 554.268 138.039 557.007C138.039 558.327 138.553 559.522 139.4 560.41C139.5 560.535 139.516 560.667 139.4 560.784L139.01 561.215C138.894 561.34 138.728 561.356 138.611 561.215C137.549 560.12 136.901 558.642 136.901 557.007ZM139.317 557.007C139.317 554.965 140.994 553.28 143.044 553.28C145.094 553.28 146.763 554.965 146.763 557.007C146.763 557.912 146.431 558.742 145.866 559.364C145.75 559.522 145.584 559.522 145.459 559.381L145.053 558.949C144.945 558.841 144.953 558.717 145.028 558.592C145.41 558.177 145.634 557.613 145.634 557.007C145.634 555.596 144.455 554.417 143.044 554.417C141.625 554.417 140.454 555.596 140.454 557.007C140.454 557.604 140.678 558.169 141.043 558.592C141.126 558.708 141.135 558.833 141.027 558.941L140.62 559.373C140.496 559.514 140.321 559.514 140.213 559.364C139.657 558.733 139.317 557.912 139.317 557.007ZM137.889 565.283C137.491 565.283 137.333 564.859 137.59 564.569L142.662 558.825C142.861 558.601 143.21 558.601 143.409 558.825L148.481 564.569C148.738 564.859 148.581 565.283 148.182 565.283H137.889Z"

private const val PATH_LABEL_IPHONE =
    "M160.708 553.875C160.231 553.875 159.844 553.488 159.844 553.018C159.844 552.542 160.231 552.155 160.708 552.155C161.177 552.155 161.571 552.542 161.571 553.018C161.571 553.488 161.177 553.875 160.708 553.875ZM160.016 562V555.106H161.387V562H160.016ZM163.551 562V552.84H167.119C168.915 552.84 170.159 554.046 170.159 555.843V555.855C170.159 557.646 168.915 558.871 167.119 558.871H164.973V562H163.551ZM166.763 554.04H164.973V557.677H166.763C167.995 557.677 168.712 557.011 168.712 555.862V555.849C168.712 554.707 167.995 554.04 166.763 554.04ZM171.898 562V552.402H173.276V556.154H173.377C173.714 555.417 174.374 554.973 175.377 554.973C176.919 554.973 177.77 555.894 177.77 557.538V562H176.399V557.861C176.399 556.719 175.923 556.154 174.914 556.154C173.904 556.154 173.276 556.846 173.276 557.957V562H171.898ZM182.613 562.133C180.588 562.133 179.351 560.781 179.351 558.56V558.547C179.351 556.332 180.595 554.973 182.613 554.973C184.625 554.973 185.87 556.325 185.87 558.547V558.56C185.87 560.781 184.632 562.133 182.613 562.133ZM182.613 560.984C183.794 560.984 184.467 560.083 184.467 558.56V558.547C184.467 557.017 183.794 556.122 182.613 556.122C181.426 556.122 180.76 557.017 180.76 558.547V558.56C180.76 560.089 181.426 560.984 182.613 560.984ZM187.514 562V555.106H188.891V556.154H188.993C189.329 555.417 189.989 554.973 190.992 554.973C192.535 554.973 193.385 555.894 193.385 557.538V562H192.014V557.861C192.014 556.719 191.538 556.154 190.529 556.154C189.52 556.154 188.891 556.846 188.891 557.957V562H187.514ZM198.203 562.133C196.185 562.133 194.966 560.756 194.966 558.572V558.566C194.966 556.414 196.21 554.973 198.133 554.973C200.057 554.973 201.237 556.363 201.237 558.433V558.915H196.35C196.375 560.235 197.099 561.003 198.235 561.003C199.117 561.003 199.644 560.565 199.809 560.21L199.834 560.159L201.161 560.153L201.148 560.21C200.92 561.118 199.968 562.133 198.203 562.133ZM198.14 556.103C197.2 556.103 196.489 556.744 196.369 557.931H199.873C199.765 556.7 199.073 556.103 198.14 556.103Z"

private val PlayerPaths: List<Path> by lazy {
    listOf(
        PATH_PLAY, PATH_REWIND, PATH_FORWARD, PATH_VOL_LOW, PATH_VOL_HIGH, PATH_AIRPLAY, PATH_LABEL_IPHONE
    ).map { PathParser().parsePathString(it).toPath() }
}

private const val IX_PLAY = 0
private const val IX_REWIND = 1
private const val IX_FORWARD = 2
private const val IX_VOL_LOW = 3
private const val IX_VOL_HIGH = 4
private const val IX_AIRPLAY = 5
private const val IX_LABEL_IPHONE = 6

// ---- geometri (koordinat SVG) ----
private const val ProgX = 27f
private const val ProgY = 391f
private const val ProgW = 282f
private const val VolX = 51f
private const val VolY = 514f
private const val VolW = 225f
private const val BarH = 7f

private val PlayCenter = Offset(170.2f, 456.9f)
private val RewindCenter = Offset(85.3f, 456f)
private val ForwardCenter = Offset(251.3f, 456f)

// area sentuh
private val RectCover = Rect(27f, 27f, 309f, 309f)
private val RectTitle = Rect(20f, 335f, 316f, 372f)
private val RectProgress = Rect(20f, 376f, 316f, 410f)
private val RectVolume = Rect(40f, 496f, 288f, 540f)

private fun toSvg(p: Offset, w: Int, h: Int): Offset {
    val s = min(w / SvgW, h / SvgH)
    return Offset((p.x - (w - SvgW * s) / 2f) / s, (p.y - (h - SvgH * s) / 2f) / s)
}

@Composable
fun PlayerControls(ink: Color, player: AudioPlayerState, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val measurer = rememberTextMeasurer()
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) player.load(uri)
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { player.loadCover(uri) }
    }

    Canvas(
        modifier.pointerInput(player) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = true)
                val w = size.width
                val h = size.height
                val p = toSvg(down.position, w, h)
                fun inCircle(c: Offset, r: Float) = (p - c).getDistance() <= r
                // fraksi 0..1 dari posisi jari pada bar tertentu
                fun frac(pos: Offset, x0: Float, width: Float) =
                    ((toSvg(pos, w, h).x - x0) / width).coerceIn(0f, 1f)

                when {
                    RectCover.contains(p) -> {
                        if (awaitTap()) imagePicker.launch(arrayOf("image/*"))
                    }
                    RectTitle.contains(p) -> {
                        if (awaitTap()) audioPicker.launch(arrayOf("audio/*"))
                    }
                    RectProgress.contains(p) -> {
                        if (player.loaded) {
                            dragSlider(
                                down = down,
                                toFraction = { frac(it, ProgX, ProgW) },
                                onChange = { player.scrubFraction = it },
                                onEnd = { player.commitScrub(it) }
                            )
                        } else if (awaitTap()) {
                            audioPicker.launch(arrayOf("audio/*"))
                        }
                    }
                    inCircle(PlayCenter, 34f) -> {
                        if (awaitTap()) {
                            if (player.loaded) player.toggle() else audioPicker.launch(arrayOf("audio/*"))
                        }
                    }
                    inCircle(RewindCenter, 30f) -> {
                        if (awaitTap()) player.skip(-10_000)
                    }
                    inCircle(ForwardCenter, 30f) -> {
                        if (awaitTap()) player.skip(10_000)
                    }
                    RectVolume.contains(p) -> {
                        dragSlider(
                            down = down,
                            toFraction = { frac(it, VolX, VolW) },
                            onChange = { player.updateVolume(it) },
                            onEnd = { }
                        )
                    }
                }
            }
        }
    ) {
        val s = min(size.width / SvgW, size.height / SvgH)
        val ox = (size.width - SvgW * s) / 2f
        val oy = (size.height - SvgH * s) / 2f
        withTransform({
            translate(ox, oy)
            scale(s, s, pivot = Offset.Zero)
        }) {
            drawPlayerControls(ink, PlayerPaths, player, measurer)
        }
    }
}

/** Tap = jari naik tanpa dibatalkan (mis. oleh geseran card). Mengonsumsi event up. */
private suspend fun AwaitPointerEventScope.awaitTap(): Boolean {
    val up = waitForUpOrCancellation()
    up?.consume()
    return up != null
}

/** Slider horizontal: nilai berubah saat disentuh dan saat digeser; [onEnd] saat jari dilepas. */
private suspend fun AwaitPointerEventScope.dragSlider(
    down: PointerInputChange,
    toFraction: (Offset) -> Float,
    onChange: (Float) -> Unit,
    onEnd: (Float) -> Unit
) {
    down.consume()
    var f = toFraction(down.position)
    onChange(f)
    drag(down.id) { change ->
        change.consume()
        f = toFraction(change.position)
        onChange(f)
    }
    onEnd(f)
}

private fun formatTime(ms: Int): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val sec = total % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%d:%02d", m, sec)
}

/** Teks dengan ukuran dalam satuan SVG (density 1f supaya 1.sp = 1 unit SVG). [align]: 0 kiri, 0.5 tengah, 1 kanan. */
private fun DrawScope.svgText(
    measurer: TextMeasurer,
    text: String,
    fontSize: Float,
    weight: FontWeight,
    color: Color,
    x: Float,
    baselineY: Float,
    align: Float = 0f,
    maxWidth: Int = Constraints.Infinity
) {
    val layout = measurer.measure(
        text = text,
        style = TextStyle(fontSize = fontSize.sp, fontWeight = weight),
        overflow = TextOverflow.Ellipsis,
        softWrap = false,
        maxLines = 1,
        constraints = Constraints(maxWidth = maxWidth),
        density = Density(1f, 1f)
    )
    drawText(
        layout,
        color = color,
        topLeft = Offset(x - layout.size.width * align, baselineY - layout.firstBaseline)
    )
}

private fun DrawScope.drawPlayerControls(
    ink: Color,
    p: List<Path>,
    player: AudioPlayerState,
    measurer: TextMeasurer
) {
    fun roundRect(x: Float, y: Float, w: Float, h: Float, r: Float, alpha: Float) {
        drawRoundRect(ink.copy(alpha = alpha), Offset(x, y), Size(w, h), CornerRadius(r, r))
    }
    fun fill(index: Int, alpha: Float = 1f) {
        drawPath(p[index], ink.copy(alpha = alpha))
    }

    val duration = player.durationMs
    val scrub = player.scrubFraction
    val fraction = scrub ?: if (duration > 0) player.positionMs.toFloat() / duration else 0f
    val positionMs = if (scrub != null) (scrub * duration).toInt() else player.positionMs

    // 2. sampul persegi: gambar upload (crop tengah) atau placeholder
    val cover = player.cover
    if (cover != null) {
        val side = min(cover.width, cover.height)
        val clip = Path().apply { addRoundRect(RoundRect(27f, 27f, 309f, 309f, 6f, 6f)) }
        clipPath(clip) {
            drawImage(
                image = cover,
                srcOffset = IntOffset((cover.width - side) / 2, (cover.height - side) / 2),
                srcSize = IntSize(side, side),
                dstOffset = IntOffset(27, 27),
                dstSize = IntSize(282, 282),
                filterQuality = FilterQuality.High
            )
        }
    } else {
        roundRect(27f, 27f, 282f, 282f, 6f, 0.25f)
        roundRect(154f, 156f, 28f, 3f, 1.5f, 0.55f)
        roundRect(166.5f, 143.5f, 3f, 28f, 1.5f, 0.55f)
        svgText(measurer, "Upload sampul", 13f, FontWeight.Medium, ink.copy(alpha = 0.55f), 168f, 198f, align = 0.5f)
    }

    // 3. judul = nama file audio
    svgText(
        measurer, player.title ?: "Pilih file audio", 16f, FontWeight.SemiBold,
        ink, 27.5f, 358f, maxWidth = 250
    )

    // 5-6. waktu berjalan / sisa
    val left = if (player.loaded) formatTime(positionMs) else "--:--"
    val right = if (player.loaded) "-" + formatTime(duration - positionMs) else "--:--"
    svgText(measurer, left, 11f, FontWeight.Medium, ink.copy(alpha = 0.8f), 27.5f, 419.5f)
    svgText(measurer, right, 11f, FontWeight.Medium, ink.copy(alpha = 0.5f), 308.5f, 419.5f, align = 1f)

    // 7-9. play / pause (pause = Vector.svg), rewind, forward
    if (player.isPlaying) {
        val l = PlayCenter.x - 11.5f
        val t = PlayCenter.y - 15.5f
        drawRoundRect(ink, Offset(l, t), Size(9f, 31f), CornerRadius(2f, 2f))
        drawRoundRect(ink, Offset(l + 14f, t), Size(9f, 31f), CornerRadius(2f, 2f))
    } else {
        fill(IX_PLAY)
    }
    fill(IX_REWIND)
    fill(IX_FORWARD)

    // 4. progress lagu: model sama dengan volume (track bulat + isi ujung kotak)
    roundRect(ProgX, ProgY, ProgW, BarH, 3.5f, 0.15f)
    if (fraction > 0f) {
        drawRect(ink.copy(alpha = 0.65f), Offset(ProgX, ProgY), Size(ProgW * fraction, BarH))
    }

    // 10-12. volume: track, isi, ikon speaker
    roundRect(VolX, VolY, VolW, BarH, 3.5f, 0.15f)
    drawRect(ink.copy(alpha = 0.65f), Offset(VolX, VolY), Size(VolW * player.volume, BarH))
    fill(IX_VOL_LOW, 0.4f)
    fill(IX_VOL_HIGH, 0.4f)

    // 13-15. pil output audio: latar, ikon AirPlay, teks "iPhone"
    roundRect(121f, 541f, 94f, 32f, 16f, 0.1f)
    fill(IX_AIRPLAY)
    fill(IX_LABEL_IPHONE)

    // 16. 6 titik kecil di kanan judul (juga area ketuk pilih audio)
    var x = 288f
    repeat(6) {
        drawCircle(ink.copy(alpha = 0.15f), radius = 1f, center = Offset(x, 352f))
        x += 4f
    }
}
