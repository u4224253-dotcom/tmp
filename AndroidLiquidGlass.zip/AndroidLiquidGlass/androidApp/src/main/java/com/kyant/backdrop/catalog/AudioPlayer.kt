package com.kyant.backdrop.catalog

import android.content.Context
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.min

/**
 * State pemutar audio + sampul. Dibuat di level layar (bukan di dalam card) supaya audio
 * tidak berhenti ketika card dibuat ulang (mis. saat radius diubah lewat slider).
 */
@Stable
class AudioPlayerState(private val context: Context) {
    private var mp: MediaPlayer? = null

    /** true kalau ada file audio yang sudah siap diputar. */
    var loaded by mutableStateOf(false)
        private set
    var title by mutableStateOf<String?>(null)
        private set
    var durationMs by mutableIntStateOf(0)
        private set
    var positionMs by mutableIntStateOf(0)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var volume by mutableFloatStateOf(0.5f)
        private set

    /** Posisi (0..1) saat bar progress sedang digeser; null kalau tidak sedang digeser. */
    var scrubFraction by mutableStateOf<Float?>(null)

    var cover by mutableStateOf<ImageBitmap?>(null)
        private set

    fun load(uri: Uri) {
        release()
        title = queryName(uri)?.substringBeforeLast('.') ?: "Audio"
        val p = MediaPlayer()
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            p.setDataSource(context, uri)
            p.prepare()
        } catch (e: Exception) {
            runCatching { p.release() }
            title = "Gagal membuka audio"
            return
        }
        p.setOnCompletionListener {
            isPlaying = false
            positionMs = 0
            runCatching { it.seekTo(0) }
        }
        p.setOnErrorListener { _, _, _ ->
            isPlaying = false
            true
        }
        p.setVolume(volume, volume)
        mp = p
        durationMs = p.duration.coerceAtLeast(0)
        positionMs = 0
        loaded = true
    }

    fun toggle() {
        val p = mp ?: return
        runCatching {
            if (p.isPlaying) {
                p.pause()
                isPlaying = false
            } else {
                p.start()
                isPlaying = true
            }
        }
    }

    fun seekTo(ms: Int) {
        val p = mp ?: return
        val target = ms.coerceIn(0, durationMs)
        runCatching { p.seekTo(target) }
        positionMs = target
    }

    fun skip(deltaMs: Int) {
        if (loaded) seekTo(positionMs + deltaMs)
    }

    /** Dipanggil saat jari dilepas setelah menggeser bar progress. */
    fun commitScrub(fraction: Float) {
        seekTo((fraction * durationMs).toInt())
        scrubFraction = null
    }

    fun setVolume(v: Float) {
        volume = v.coerceIn(0f, 1f)
        runCatching { mp?.setVolume(volume, volume) }
    }

    /** Menyalin posisi putar ke state; dipanggil berkala selama audio jalan. */
    fun syncPosition() {
        val p = mp ?: return
        if (!isPlaying || scrubFraction != null) return
        runCatching { positionMs = p.currentPosition.coerceIn(0, durationMs) }
    }

    suspend fun loadCover(uri: Uri) {
        val bmp = withContext(Dispatchers.IO) { decodeSampled(uri) }
        if (bmp != null) cover = bmp.asImageBitmap()
    }

    fun release() {
        mp?.let { runCatching { it.release() } }
        mp = null
        loaded = false
        isPlaying = false
        durationMs = 0
        positionMs = 0
        scrubFraction = null
    }

    private fun queryName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull()

    /** Decode gambar dengan sisi terpendek ~1024 px supaya hemat memori. */
    private fun decodeSampled(uri: Uri): android.graphics.Bitmap? = try {
        val cr = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val minSide = min(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (minSide / (sample * 2) >= 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    } catch (e: Exception) {
        null
    }
}

@Composable
fun rememberAudioPlayer(): AudioPlayerState {
    val context = LocalContext.current.applicationContext
    val state = remember { AudioPlayerState(context) }
    DisposableEffect(state) { onDispose { state.release() } }
    LaunchedEffect(state) {
        while (true) {
            state.syncPosition()
            delay(50)
        }
    }
    return state
}
