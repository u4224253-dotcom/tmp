package com.kyant.backdrop.catalog

import android.content.Context
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * State pemutar audio + sampul. Dibuat di level layar (bukan di dalam card) supaya audio
 * tidak berhenti ketika card dibuat ulang (mis. saat radius diubah lewat slider).
 */
@Stable
class AudioPlayerState(private val context: Context) {
    private var mp: MediaPlayer? = null

    // analisis spectrum + metadata dikerjakan di background; generation menolak hasil lagu lama
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var analysisJob: Job? = null
    @Volatile private var generation = 0
    @Volatile private var spectrum: SpectrumData? = null
    private val levelTarget = FloatArray(EqBars)
    private var clockMs = 0f

    /** Level 6 pita (bass..treble, 0..1) frame terakhir. Hanya dibaca; diisi oleh updateLevels. */
    val bands = FloatArray(EqBars)

    /** 0 = batang jadi titik (dijeda), 1 = bergerak penuh; berubah halus. Dibaca saat menggambar. */
    var eqActive = 0f
        private set

    /** true kalau ada file audio yang sudah siap diputar. */
    var loaded by mutableStateOf(false)
        private set
    var title by mutableStateOf<String?>(null)
        private set

    /** Nama artist dari tag metadata file; null kalau file tidak punya tag artist. */
    var artist by mutableStateOf<String?>(null)
        private set
    var durationMs by mutableIntStateOf(0)
        private set
    var positionMs by mutableIntStateOf(0)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var volume by mutableFloatStateOf(0.5f)
        private set

    /** Posisi (0..1) saat bar progress sedang digeser; null kalau tidak sedang digeser. */
    var scrubFraction by mutableStateOf<Float?>(null)

    var cover by mutableStateOf<ImageBitmap?>(null)
        private set

    fun load(uri: Uri) {
        release()
        title = queryName(uri)?.substringBeforeLast('.') ?: "Audio"
        val p = MediaPlayer()
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            p.setDataSource(context, uri)
            p.prepare()
        } catch (e: Exception) {
            runCatching { p.release() }
            title = "Gagal membuka audio"
            return
        }
        p.setOnCompletionListener {
            isPlaying = false
            positionMs = 0
            runCatching { it.seekTo(0) }
        }
        p.setOnErrorListener { _, _, _ ->
            isPlaying = false
            true
        }
        p.setVolume(volume, volume)
        mp = p
        durationMs = p.duration.coerceAtLeast(0)
        positionMs = 0
        loaded = true

        val gen = generation
        analysisJob = scope.launch {
            val name = readArtist(uri)
            if (isActive && gen == generation) artist = name
            val data = SpectrumAnalyzer.analyze(context, uri) { isActive && gen == generation }
            if (data != null && isActive && gen == generation) spectrum = data
        }
    }

    fun toggle() {
        val p = mp ?: return
        runCatching {
            if (p.isPlaying) {
                p.pause()
                isPlaying = false
            } else {
                p.start()
                isPlaying = true
            }
        }
    }

    fun seekTo(ms: Int) {
        val p = mp ?: return
        val target = ms.coerceIn(0, durationMs)
        runCatching { p.seekTo(target) }
        positionMs = target
    }

    fun skip(deltaMs: Int) {
        if (loaded) seekTo(positionMs + deltaMs)
    }

    /** Dipanggil saat jari dilepas setelah menggeser bar progress. */
    fun commitScrub(fraction: Float) {
        seekTo((fraction * durationMs).toInt())
        scrubFraction = null
    }

    fun updateVolume(v: Float) {
        volume = v.coerceIn(0f, 1f)
        runCatching { mp?.setVolume(volume, volume) }
    }

    /** Menyalin posisi putar ke state; dipanggil berkala selama audio jalan. */
    fun syncPosition() {
        val p = mp ?: return
        if (!isPlaying || scrubFraction != null) return
        runCatching { positionMs = p.currentPosition.coerceIn(0, durationMs) }
    }

    /**
     * Mengisi [out] (panjang [EqBars]) dengan tinggi batang 0..1 untuk frame ini.
     * Sumber: spectrum hasil analisis lagu pada posisi putar saat ini. Selama analisis belum
     * selesai dipakai animasi cadangan. Naik cepat, turun pelan supaya terlihat halus.
     */
    fun updateLevels(out: FloatArray, nowSec: Float, dt: Float) {
        val target = levelTarget
        val sp = spectrum
        val playing = isPlaying
        // jam sendiri yang berjalan mulus per frame; currentPosition MediaPlayer naik patah-patah
        // (per buffer audio), jadi dipakai hanya untuk koreksi pelan supaya batang tidak bergetar
        val raw = runCatching { mp?.currentPosition ?: positionMs }.getOrDefault(positionMs).toFloat()
        if (!playing) {
            clockMs = raw
        } else {
            clockMs += dt * 1000f
            val err = raw - clockMs
            if (abs(err) > 150f) clockMs = raw else clockMs += err * (1f - exp(-dt / 0.25f))
        }
        eqActive += ((if (playing) 1f else 0f) - eqActive) * (1f - exp(-dt / 0.12f))
        if (!playing) {
            target.fill(0f)
        } else if (sp != null) {
            sp.levelsAt(clockMs, target)
        } else {
            for (i in 0 until EqBars) {
                target[i] = 0.2f + 0.6f * (0.5f + 0.5f * sin(nowSec * FallbackSpeed[i] + FallbackPhase[i]))
            }
        }
        // hasil fit ke video referensi: naik ~15 ms, turun ~80 ms (eksponensial, bebas-framerate)
        val up = 1f - exp(-dt / 0.015f)
        val down = 1f - exp(-dt / 0.08f)
        for (i in 0 until min(EqBars, out.size)) {
            val t = target[i]
            out[i] += (t - out[i]) * (if (t > out[i]) up else down)
        }
        // salinan level terakhir untuk visual lain (aurora); tidak memajukan jam audio lagi
        for (i in 0 until min(EqBars, out.size)) bands[i] = out[i]
    }

    suspend fun loadCover(uri: Uri) {
        val bmp = withContext(Dispatchers.IO) { decodeSampled(uri) }
        if (bmp != null) cover = bmp.asImageBitmap()
    }

    fun release() {
        generation++
        analysisJob?.cancel()
        analysisJob = null
        spectrum = null
        artist = null
        mp?.let { runCatching { it.release() } }
        mp = null
        loaded = false
        isPlaying = false
        durationMs = 0
        positionMs = 0
        scrubFraction = null
    }

    /** Dipanggil sekali saat state dibuang (bukan saat ganti lagu). */
    fun destroy() {
        release()
        scope.cancel()
    }

    /** Nama artist dari tag file (ARTIST, lalu ALBUMARTIST, dst); null kalau kosong. */
    private fun readArtist(uri: Uri): String? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            listOf(
                MediaMetadataRetriever.METADATA_KEY_ARTIST,
                MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST,
                MediaMetadataRetriever.METADATA_KEY_AUTHOR,
                MediaMetadataRetriever.METADATA_KEY_WRITER,
                MediaMetadataRetriever.METADATA_KEY_COMPOSER
            ).firstNotNullOfOrNull { key ->
                r.extractMetadata(key)?.trim()?.takeIf { it.isNotEmpty() }
            }
        } catch (e: Exception) {
            null
        } finally {
            runCatching { r.release() }
        }
    }

    private fun queryName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull()

    /** Decode gambar dengan sisi terpendek ~1024 px supaya hemat memori. */
    private fun decodeSampled(uri: Uri): android.graphics.Bitmap? = try {
        val cr = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val minSide = min(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (minSide / (sample * 2) >= 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    } catch (e: Exception) {
        null
    }
}

@Composable
fun rememberAudioPlayer(): AudioPlayerState {
    val context = LocalContext.current.applicationContext
    val state = remember { AudioPlayerState(context) }
    DisposableEffect(state) { onDispose { state.destroy() } }
    LaunchedEffect(state) {
        while (true) {
            state.syncPosition()
            delay(50)
        }
    }
    return state
}
