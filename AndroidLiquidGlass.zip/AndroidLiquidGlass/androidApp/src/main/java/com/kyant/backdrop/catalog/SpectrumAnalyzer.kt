package com.kyant.backdrop.catalog

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Jumlah batang indikator spectrum di kanan judul. */
internal const val EqBars = 6

/** Animasi cadangan (dipakai selama analisis belum selesai / format tidak bisa dianalisis). */
internal val FallbackSpeed = floatArrayOf(9f, 12f, 7.5f, 13.5f, 10f, 8.5f)
internal val FallbackPhase = floatArrayOf(0f, 1.7f, 3.1f, 4.4f, 0.9f, 2.5f)

/**
 * Hasil analisis frekuensi satu lagu: [EqBars] level (0..1) untuk tiap frame waktu [hopMs].
 * Batang 0 = bass paling rendah ... batang 5 = treble paling tinggi.
 */
internal class SpectrumData(
    private val hopMs: Float,
    private val offsetMs: Float,
    private val levels: FloatArray // frames * EqBars
) {
    private val frames = levels.size / EqBars

    /** Level pada posisi putar [positionMs], diinterpolasi antar frame. */
    fun levelsAt(positionMs: Int, out: FloatArray) {
        if (frames == 0) {
            out.fill(0f)
            return
        }
        val idx = ((positionMs - offsetMs) / hopMs).coerceIn(0f, (frames - 1).toFloat())
        val i0 = floor(idx).toInt()
        val i1 = min(i0 + 1, frames - 1)
        val f = idx - i0
        for (b in 0 until min(EqBars, out.size)) {
            val a = levels[i0 * EqBars + b]
            val c = levels[i1 * EqBars + b]
            out[b] = a + (c - a) * f
        }
    }
}

/**
 * Menganalisis isi audio sebenarnya (bukan animasi acak):
 * decode ke PCM dengan MediaCodec -> FFT 2048 titik tiap 40 ms -> energi di 6 pita frekuensi.
 * Tidak butuh izin RECORD_AUDIO (beda dengan android.media.audiofx.Visualizer).
 */
internal object SpectrumAnalyzer {
    private const val FFT_SIZE = 2048
    private const val HOP_MS = 40

    // batas pita (Hz): bass, low-mid, mid, upper-mid, presence, treble
    private val EDGES_HZ = floatArrayOf(40f, 120f, 300f, 800f, 2200f, 6000f, 16000f)

    private const val TIMEOUT_US = 10_000L
    private const val MAX_RUN_NS = 5L * 60L * 1_000_000_000L

    /** Blocking; panggil dari thread background. Mengembalikan null kalau gagal / dibatalkan. */
    fun analyze(context: Context, uri: Uri, isActive: () -> Boolean): SpectrumData? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    track = i
                    format = f
                    break
                }
            }
            if (track < 0 || format == null) return null
            extractor.selectTrack(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null

            var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else 44100
            var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            } else 2
            channels = max(1, channels)
            var pcmFloat = false

            val collector = FrameCollector()
            collector.configure(sampleRate)

            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(format, null, null, 0)
            c.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val deadline = System.nanoTime() + MAX_RUN_NS

            while (!outputDone) {
                if (!isActive() || System.nanoTime() > deadline) return null

                if (!inputDone) {
                    val inIdx = c.dequeueInputBuffer(TIMEOUT_US)
                    if (inIdx >= 0) {
                        val inBuf = c.getInputBuffer(inIdx)
                        val n = if (inBuf != null) extractor.readSampleData(inBuf, 0) else -1
                        if (n < 0) {
                            c.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(inIdx, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIdx = c.dequeueOutputBuffer(info, TIMEOUT_US)
                when {
                    outIdx >= 0 -> {
                        val buf = c.getOutputBuffer(outIdx)
                        if (buf != null && info.size > 0) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            buf.order(ByteOrder.nativeOrder())
                            if (pcmFloat) {
                                val fb = buf.asFloatBuffer()
                                val total = fb.remaining()
                                var k = 0
                                while (k + channels <= total) {
                                    var s = 0f
                                    for (q in 0 until channels) s += fb.get(k + q)
                                    collector.push(s / channels)
                                    k += channels
                                }
                            } else {
                                val sb = buf.asShortBuffer()
                                val total = sb.remaining()
                                var k = 0
                                while (k + channels <= total) {
                                    var s = 0f
                                    for (q in 0 until channels) s += sb.get(k + q)
                                    collector.push(s / channels / 32768f)
                                    k += channels
                                }
                            }
                        }
                        c.releaseOutputBuffer(outIdx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }

                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = c.outputFormat
                        if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                            sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        }
                        if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                            channels = max(1, of.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                        }
                        pcmFloat = Build.VERSION.SDK_INT >= 24 &&
                            of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                        collector.configure(sampleRate)
                    }
                }
            }
            return collector.finish()
        } catch (e: Exception) {
            return null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    /** Mengumpulkan sampel mono, menjalankan FFT tiap hop, dan menyimpan energi per pita. */
    private class FrameCollector {
        private val n = FFT_SIZE
        private val window = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
        private val cosT = FloatArray(n / 2) { cos(2.0 * PI * it / n).toFloat() }
        private val sinT = FloatArray(n / 2) { (-sin(2.0 * PI * it / n)).toFloat() }
        private val rev = IntArray(n).also { r ->
            val bits = Integer.numberOfTrailingZeros(n)
            for (i in 0 until n) r[i] = Integer.reverse(i) ushr (32 - bits)
        }

        private val ring = FloatArray(n)
        private val re = FloatArray(n)
        private val im = FloatArray(n)
        private var writePos = 0
        private var total = 0L

        private var sampleRate = 44100
        private var hop = 1764
        private val loBin = IntArray(EqBars)
        private val hiBin = IntArray(EqBars) // eksklusif

        private var raw = FloatArray(EqBars * 2048)
        private var frames = 0

        fun configure(sr: Int) {
            sampleRate = max(8000, sr)
            hop = max(1, sampleRate * HOP_MS / 1000)
            val binHz = sampleRate.toFloat() / n
            val nyquistCap = sampleRate * 0.45f
            for (b in 0 until EqBars) {
                var lo = ceil(EDGES_HZ[b] / binHz).toInt().coerceAtLeast(1)
                var hi = floor(min(EDGES_HZ[b + 1], nyquistCap) / binHz).toInt()
                hi = min(max(hi, lo + 1), n / 2)
                lo = min(lo, hi - 1)
                loBin[b] = lo
                hiBin[b] = hi
            }
        }

        fun push(sample: Float) {
            ring[writePos] = sample
            writePos++
            if (writePos == n) writePos = 0
            total++
            if (total >= n && (total - n) % hop == 0L) computeFrame()
        }

        private fun computeFrame() {
            for (j in 0 until n) {
                re[rev[j]] = ring[(writePos + j) % n] * window[j]
                im[rev[j]] = 0f
            }
            var len = 2
            while (len <= n) {
                val half = len / 2
                val step = n / len
                var i = 0
                while (i < n) {
                    var k = 0
                    for (j in i until i + half) {
                        val wr = cosT[k]
                        val wi = sinT[k]
                        val xr = re[j + half] * wr - im[j + half] * wi
                        val xi = re[j + half] * wi + im[j + half] * wr
                        re[j + half] = re[j] - xr
                        im[j + half] = im[j] - xi
                        re[j] += xr
                        im[j] += xi
                        k += step
                    }
                    i += len
                }
                len = len shl 1
            }

            if ((frames + 1) * EqBars > raw.size) raw = raw.copyOf(raw.size * 2)
            for (b in 0 until EqBars) {
                var sum = 0f
                for (k in loBin[b] until hiBin[b]) sum += re[k] * re[k] + im[k] * im[k]
                raw[frames * EqBars + b] = sqrt(sum / (hiBin[b] - loBin[b]))
            }
            frames++
        }

        /** Normalisasi tiap pita ke persentil 97 supaya semua batang sama hidupnya. */
        fun finish(): SpectrumData? {
            if (frames == 0) return null
            val out = FloatArray(frames * EqBars)
            val tmp = FloatArray(frames)
            for (b in 0 until EqBars) {
                for (i in 0 until frames) tmp[i] = raw[i * EqBars + b]
                tmp.sort()
                val ref = max(tmp[((frames - 1) * 0.97f).toInt()], 1e-6f)
                for (i in 0 until frames) {
                    val x = raw[i * EqBars + b] / ref
                    out[i * EqBars + b] = sqrt(x).coerceIn(0f, 1f)
                }
            }
            // frame i dihitung dari jendela yang berpusat (n/2) sampel setelah awalnya
            val offsetMs = (n / 2f) * 1000f / sampleRate
            return SpectrumData(HOP_MS.toFloat(), offsetMs, out)
        }
    }
}
