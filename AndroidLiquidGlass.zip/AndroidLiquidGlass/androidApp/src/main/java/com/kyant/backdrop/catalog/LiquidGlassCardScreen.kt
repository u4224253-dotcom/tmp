package com.kyant.backdrop.catalog

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.colorControls
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.highlight.Highlight
import com.kyant.backdrop.highlight.HighlightStyle
import com.kyant.shapes.RoundedRectangle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.roundToInt

private val InkColor = Color(0xFF0B0F2E)

// ---- tema dock terang di atas latar gradient animasi ----
internal val DockInk = Color(0xFF0B0F2E)
internal val DockAccent = Color(0xFF4B5BFF)
private val CanvasCorner = 14f // sudut canvas preview: melengkung sedikit saja

/** Teks dock: Inter (pengganti SF Pro yang berlisensi) dengan kerapatan huruf ala iOS. */
internal fun dockText(size: Float, weight: FontWeight = FontWeight.Medium, color: Color = DockInk) = TextStyle(
    color = color,
    fontSize = size.sp,
    fontWeight = weight,
    fontFamily = PlayerFont,
    letterSpacing = sfTracking(size).sp
)

private const val DefSize = 256f // sama dengan GlassPlayground asli

// Canvas 9:16 selalu 360 x 640 dp secara logis. Resolusi hanya mengubah kerapatan pixel
// (1080p -> 3x, 1280p -> 2x), jadi komposisi card + foto identik di kedua resolusi.
internal const val CanvasWDp = 360f

// Ukuran card TETAP, diukur dari hasil render Alight Motion (Proyek Baru.png, canvas 1080x1920):
// persegi panjang x 107..973, y 180..1740 = 866 x 1560 px (di XML: size 100x180 * scale 4.33, dan
// AM menggambar size itu 2x -> 866 x 1558.8). Dibagi 3 = 288.67 x 519.6 dp di canvas logis 360x640.
internal const val CardWDp = 866f / 3f
internal const val CardHDp = 1558.8f / 3f

/** Resolusi canvas 9:16. 1080p = 1080x1920, 1280p = 720x1280. */
private enum class CanvasRes(val label: String, val w: Int, val h: Int) {
    P1080("1080p", 1080, 1920),
    P1280("1280p", 720, 1280)
}

/** Jenis card yang diambil apa adanya dari catalog project asli (Kyant0/AndroidLiquidGlass). */
private enum class CardStyle(val label: String, val short: String, val source: String) {
    Playground("Dasar", "Dasar", "GlassPlaygroundContent"),
    DialogLight("Terang", "Terang", "DialogContent (light)"),
    ControlCenter("Gelap", "Gelap", "ControlCenterContent")
}

/**
 * Semua angka di sini disalin dari project asli. Refraksi dalam % supaya cocok dengan
 * slider: height% = refractionHeight / (minDim * 0.5), amount% = refractionAmount / minDim,
 * dihitung untuk card 256dp (ukuran card di GlassPlayground asli).
 */
private data class Preset(
    val radius: Float,          // dp
    val blur: Float,            // dp
    val refrHeight: Float,      // %
    val refrAmount: Float,      // %
    val bgColor: Color,         // warna onDrawSurface
    val bgOpacity: Float,       // % (0..100)
    val brightness: Float?,     // null = vibrancy(), selain itu colorControls(...)
    val saturation: Float = 1.5f,
    val plainHighlight: Boolean = true,
    val titleColor: Color = Color.White,
    val aberration: Float = 0f,         // %
    val wallpaperOpacity: Float = 100f, // % (opacity foto background)
    val bgBlur: Float = 0f              // px (blur foto background)
)

private fun CardStyle.preset(): Preset = when (this) {
    // GlassPlaygroundContent: radius 48 (default sudut seragam), blur 0, lens 0.2/0.2, Highlight.Plain, tanpa surface
    CardStyle.Playground -> Preset(48f, 0f, 20f, 20f, Color.White, 0f, null)
    // DialogContent light: colorControls(0.2, sat 1.5), blur 16, lens(24, 48, depth), FAFAFA @ 0.6
    CardStyle.DialogLight -> Preset(
        48f, 16f, 18.75f, 18.75f, Color(0xFFFAFAFA), 60f, 0.2f,
        titleColor = Color.Black,
        wallpaperOpacity = 62f, bgBlur = 11f // opacity foto 62%, blur background 11px
    )
    // ControlCenterContent: vibrancy, lens(24, 48, depth), putih 0.05 (diubah dari hitam: opacity dinaikkan jadi putih seperti mode Dasar), highlight Default(falloff 2)
    // Preset Gelap (dari pengaturan pilihan user): sudut 43, blur 5, opacity 28, aberasi 11, refraksi 20/12, opacity foto 62, blur background 11
    CardStyle.ControlCenter -> Preset(
        43f, 5f, 20f, 12f, Color.White, 28f, null,
        plainHighlight = false,
        aberration = 11f, wallpaperOpacity = 62f, bgBlur = 11f
    )
}

/**
 * Satu card liquid glass + panel pengaturan.
 * Efek glass memakai library `backdrop` dengan parameter yang sama seperti catalog asli.
 */
@Composable
fun LiquidGlassCardScreen() {
    val backdrop = rememberLayerBackdrop()       // backdrop di dalam canvas (untuk card)
    val dockBackdrop = rememberLayerBackdrop()   // backdrop latar studio (untuk dock)
    val player = rememberAudioPlayer()           // di luar key(cardRadius) supaya audio tidak putus saat card dibuat ulang
    val glassCapture = rememberGlassCapture()    // tangkap canvas tanpa controls untuk export video
    val bg = rememberBackgroundState()           // background canvas (foto) — terpisah dari sampul

    // ---- pilihan jenis card ----
    var styleName by rememberSaveable { mutableStateOf(CardStyle.Playground.name) }
    val style = runCatching { CardStyle.valueOf(styleName) }.getOrDefault(CardStyle.Playground)
    val res = CanvasRes.P1080 // resolusi tunggal 1080x1920

    // ---- pengaturan card ----
    val p0 = CardStyle.Playground.preset()
    var radiusDp by rememberSaveable { mutableStateOf(p0.radius) }
    var blurDp by rememberSaveable { mutableStateOf(p0.blur) }
    var bgOpacity by rememberSaveable { mutableStateOf(p0.bgOpacity) }
    var bgDark by rememberSaveable { mutableStateOf(false) } // warna latar: putih / hitam
    var edge by rememberSaveable { mutableStateOf(100f) }
    var refrHeight by rememberSaveable { mutableStateOf(p0.refrHeight) }
    var refrAmount by rememberSaveable { mutableStateOf(p0.refrAmount) }
    var aberration by rememberSaveable { mutableStateOf(0f) }
    // opacity foto/latar utama; .alpha() harus SETELAH .layerBackdrop() supaya rekaman backdrop (isi kaca) ikut redup
    var wallpaperOpacity by rememberSaveable { mutableStateOf(100f) }
    // blur foto/latar utama di canvas (Modifier.blur: efek nyata di Android 12+)
    var bgBlur by rememberSaveable { mutableStateOf(0f) }
    // sub kategori Customized (default tertutup biar dock bersih)
    var customOpen by rememberSaveable { mutableStateOf(false) }
    // mode layar penuh: dock + status bar + nav bar disembunyikan, preview 9:16 memenuhi layar
    var fullscreen by rememberSaveable { mutableStateOf(false) }

    val hostView = LocalView.current
    DisposableEffect(fullscreen) {
        val window = hostView.context.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, hostView) }
        if (fullscreen) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    BackHandler(enabled = fullscreen) { fullscreen = false }

    val preset = style.preset()
    // ---- export video ----
    val exportScope = rememberCoroutineScope()
    val appContext = LocalContext.current.applicationContext
    val exportMeasurer = rememberTextMeasurer() // instance sendiri, dipakai di background saat export
    var exportState by remember { mutableStateOf<ExportUiState?>(null) }
    var exportJob by remember { mutableStateOf<Job?>(null) }
    val exporting = exportState?.finished == false
    DisposableEffect(exporting) {
        hostView.keepScreenOn = exporting // layar jangan mati selama export
        onDispose { hostView.keepScreenOn = false }
    }
    // ---- upload terpisah: sampul (di card) dan background (di canvas, foto) ----
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) exportScope.launch { player.loadCover(uri) }
    }
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) exportScope.launch { bg.load(uri) }
    }

    val startExport: () -> Unit = {
        if (exportJob?.isActive != true && player.loaded) {
            exportState = ExportUiState("Menyiapkan…", 0f)
            exportJob = exportScope.launch {
                runExport(appContext, player, glassCapture, exportMeasurer, preset.titleColor, radiusDp) {
                    exportState = it
                }
            }
        }
    }

    val presetIsDark = preset.bgColor.red < 0.2f && preset.bgColor.green < 0.2f && preset.bgColor.blue < 0.2f
    val bgBase = when {
        bgDark && presetIsDark -> preset.bgColor
        bgDark -> Color.Black
        !presetIsDark -> preset.bgColor
        else -> Color.White
    }

    fun applyStyle(s: CardStyle) {
        val p = s.preset()
        styleName = s.name
        radiusDp = p.radius
        blurDp = p.blur
        refrHeight = p.refrHeight
        refrAmount = p.refrAmount
        bgOpacity = p.bgOpacity
        bgDark = p.bgColor.red < 0.2f && p.bgColor.green < 0.2f && p.bgColor.blue < 0.2f
        edge = 100f
        aberration = p.aberration
        wallpaperOpacity = p.wallpaperOpacity
        bgBlur = p.bgBlur
    }

    // ---- geser card ----
    var offset by remember { mutableStateOf(Offset.Zero) }
    var isPressed by remember { mutableStateOf(false) }
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed) 1.05f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 300f)
    )

    // ---- aurora latar utama (di luar canvas): 3 warna dominan dari isi canvas (foto background, atau foto bawaan kalau belum ada); geraknya ikut spektrum audio ----
    val defaultWall = ImageBitmap.imageResource(R.drawable.wallpaper_light)
    val paletteSource = bg.paletteSource ?: defaultWall
    val palette = remember(paletteSource) { extractAuroraPalette(paletteSource) }
    val auroraC0 by animateColorAsState(palette[0], tween(900))
    val auroraC1 by animateColorAsState(palette[1], tween(900))
    val auroraC2 by animateColorAsState(palette[2], tween(900))

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val screenH = maxHeight

        // ---------- latar utama: aurora dari warna isi canvas (selalu aktif, normal maupun layar penuh) ----------
        Box(
            Modifier
                .fillMaxSize()
                .layerBackdrop(dockBackdrop)
        ) {
            AuroraBackground(
                auroraC0, auroraC1, auroraC2, player,
                Modifier.fillMaxSize()
            )
        }

        Column(Modifier.fillMaxSize()) {
            // jarak untuk status bar (hilang saat layar penuh)
            if (!fullscreen) Box(Modifier.statusBarsPadding().height(10f.dp))

            // ---------- area canvas: 9:16, diskalakan agar muat di layar ----------
            BoxWithConstraints(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(
                        horizontal = if (fullscreen) 0f.dp else 16f.dp,
                        vertical = if (fullscreen) 0f.dp else 4f.dp
                    ),
                contentAlignment = Alignment.Center
            ) {
                // kolom 42dp di kiri & kanan canvas (kiri kosong supaya canvas tetap di tengah; kanan untuk tombol layar penuh)
                val sideW = if (fullscreen) 0f else 42f
                val dispW = minOf(maxWidth.value - 2f * sideW, maxHeight.value * 9f / 16f).coerceAtLeast(1f).dp
                val dispH = (dispW.value * 16f / 9f).dp
                val deviceDensity = LocalDensity.current
                val fit = with(deviceDensity) { dispW.toPx() } / res.w
                val canvasW = with(deviceDensity) { res.w.toDp() }
                val canvasH = with(deviceDensity) { res.h.toDp() }

                val canvasShape = RoundedCornerShape(CanvasCorner.dp)
                Row(verticalAlignment = Alignment.Bottom) {
                if (!fullscreen) Box(Modifier.width(sideW.dp))
                Box(
                    Modifier
                        .size(dispW, dispH)
                        .then(
                            if (fullscreen) Modifier else Modifier
                                .shadow(
                                    elevation = 22f.dp,
                                    shape = canvasShape,
                                    clip = false,
                                    ambientColor = DockInk.copy(alpha = 0.18f),
                                    spotColor = DockInk.copy(alpha = 0.28f)
                                )
                                .clip(canvasShape)
                                .border(1f.dp, Color.White.copy(alpha = 0.85f), canvasShape)
                        )
                ) {
                    // canvas dirender di ukuran pixel asli (res.w x res.h), lalu diperkecil untuk tampilan
                    Box(
                        Modifier
                            .requiredSize(canvasW, canvasH)
                            .graphicsLayer {
                                scaleX = fit
                                scaleY = fit
                                transformOrigin = TransformOrigin.Center
                                clip = true
                            }
                    ) {
                        // di dalam canvas: 360 x 640 dp logis, kerapatan = res.w / 360
                        CompositionLocalProvider(LocalDensity provides Density(res.w / CanvasWDp, 1f)) {
                            BoxWithConstraints(Modifier.fillMaxSize().glassCapture(glassCapture)) {
                                val w = maxWidth
                                val h = maxHeight
                                val cardW = CardWDp.dp
                                val cardH = CardHDp.dp
                                val cardMin = cardW // sisi terpendek, dipakai untuk skala ikon & teks
                                val cardRadius = radiusDp.coerceAtMost(CardWDp / 2f).dp

                                // ---------- wallpaper + objek di belakang kaca ----------
                                val wallpaperAlpha = (wallpaperOpacity / 100f).coerceIn(0f, 1f)
                                // isi canvas: background khusus (foto), atau foto bawaan kalau belum ada.
                                // TIDAK memakai sampul: sampul hanya tampil di dalam card.
                                val bgImg = bg.display
                                val bgPainter = if (bgImg != null) {
                                    remember(bgImg) { BitmapPainter(bgImg) }
                                } else {
                                    painterResource(R.drawable.wallpaper_light)
                                }
                                Image(
                                    bgPainter,
                                    null,
                                    Modifier
                                        .fillMaxSize()
                                        .layerBackdrop(backdrop)
                                        // lapisan paling bawah: hitam penuh (di dalam rekaman backdrop, di luar blur/alpha foto)
                                        .background(Color.Black)
                                        .blur(bgBlur.dp)
                                        .alpha(wallpaperAlpha),
                                    contentScale = ContentScale.Crop
                                )


                                // ---------- CARD LIQUID GLASS ----------
                                // key(cardRadius): library backdrop tidak memperbarui clip layer kaca saat bentuk berubah
                                // (hanya tepi/highlight yang ikut), jadi card dibuat ulang tiap radius berganti.
                                key(cardRadius) {
                                    Box(
                                        Modifier
                                            .align(Alignment.TopStart)
                                            .offset(x = (w - cardW) / 2f, y = (h - cardH) / 2f) // tengah canvas, sama seperti XML (540,960)
                                            .drawBackdrop(
                                                backdrop = backdrop,
                                                shape = { RoundedRectangle(cardRadius) },
                                                effects = {
                                                    val minDimension = size.minDimension
                                                    // urutan persis seperti catalog asli: warna -> blur -> lens
                                                    if (preset.brightness == null) {
                                                        vibrancy()
                                                    } else {
                                                        colorControls(brightness = preset.brightness, saturation = preset.saturation)
                                                    }
                                                    blur(blurDp.dp.toPx())
                                                    lens(
                                                        refractionHeight = refrHeight / 100f * minDimension * 0.5f,
                                                        refractionAmount = refrAmount / 100f * minDimension,
                                                        depthEffect = true,
                                                        chromaticAberration = aberration > 0f
                                                    )
                                                },
                                                highlight = {
                                                    val alpha = (edge / 100f).coerceIn(0f, 1f)
                                                    if (preset.plainHighlight) {
                                                        Highlight.Plain.copy(alpha = alpha)
                                                    } else {
                                                        Highlight(alpha = alpha, style = HighlightStyle.Default(falloff = 2f))
                                                    }
                                                },
                                                layerBlock = {
                                                    translationX = offset.x
                                                    translationY = offset.y
                                                    scaleX = pressScale
                                                    scaleY = pressScale
                                                },
                                                onDrawSurface = {
                                                    // satu-satunya lapisan di atas kaca: warna latar dengan opacity yang bisa diatur
                                                    val a = (bgOpacity / 100f).coerceIn(0f, 1f)
                                                    if (a > 0f) drawRect(bgBase.copy(alpha = a))
                                                }
                                            )
                                            // posisi card dikunci di tengah (tidak bisa digeser)
                                            .size(cardW, cardH)
                                    ) {
                                        // isi card: semua elemen dari playing_controls.svg
                                        // saat menangkap layer kaca untuk export, isi card dikosongkan (controls digambar terpisah per frame)
                                        if (!glassCapture.capturing) {
                                            PlayerControls(ink = preset.titleColor, player = player, modifier = Modifier.fillMaxSize())
                                        }
                                    }
                                }
                            }
                        }
                    }
                    // layar penuh: tidak ada ruang di luar canvas, jadi tombol keluar ada di pojok kanan bawah canvas
                    if (fullscreen) {
                        FullscreenToggle(
                            fullscreen = true,
                            modifier = Modifier.align(Alignment.BottomEnd).padding(8f.dp)
                        ) { fullscreen = false }
                    }
                }
                // tombol layar penuh: di samping kanan canvas, sejajar dengan sisi bawah canvas
                if (!fullscreen) {
                    Box(Modifier.width(sideW.dp), contentAlignment = Alignment.BottomCenter) {
                        FullscreenToggle(fullscreen = false) { fullscreen = true }
                    }
                }
                }
            }

            // ---------- DOCK PENGATURAN (disusun ulang: tab -> aksi -> teks -> Customized) ----------
            if (!fullscreen) Column(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .widthIn(max = 440f.dp)
                    .fillMaxWidth()
                    .heightIn(max = screenH * 0.45f)
                    .navigationBarsPadding() // tanpa imePadding: keyboard menutupi dock, isi app tidak terdorong
                    .verticalScroll(rememberScrollState())
                    .padding(start = 16f.dp, end = 16f.dp, bottom = 16f.dp),
                verticalArrangement = Arrangement.spacedBy(10f.dp)
            ) {
                // 1) jenis card
                DockTabs(dockBackdrop, CardStyle.entries.map { it.short }, style.ordinal) {
                    applyStyle(CardStyle.entries[it])
                }

                // 2) aksi utama: 3 tile sama besar (Sampul, Background, Export)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10f.dp)) {
                    DockTile(
                        dockBackdrop, "Sampul",
                        modifier = Modifier.weight(1f),
                        active = player.cover != null,
                        onClear = { player.clearCover() },
                        icon = { c -> drawDiscIcon(c) },
                        onClick = { coverPicker.launch(arrayOf("image/*")) }
                    )
                    DockTile(
                        dockBackdrop,
                        when {
                            bg.loading -> "Memuat…"
                            bg.error != null -> "Coba lagi"
                            else -> "Background"
                        },
                        modifier = Modifier.weight(1f),
                        active = bg.hasCustom,
                        onClear = { bg.clear() },
                        icon = { c -> drawLandscapeIcon(c) },
                        onClick = { bgPicker.launch(arrayOf("image/*")) }
                    )
                    DockTile(
                        dockBackdrop, "Export",
                        modifier = Modifier.weight(1f),
                        primary = true,
                        enabled = player.loaded && !exporting,
                        icon = { c -> drawDownloadIcon(c) },
                        onClick = startExport
                    )
                }

                // 3) teks card (kosong = otomatis dari file)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10f.dp)) {
                    DockTextField(dockBackdrop, player.customTitle, { player.customTitle = it }, "Judul", Modifier.weight(1f))
                    DockTextField(dockBackdrop, player.customArtist, { player.customArtist = it }, "Artis", Modifier.weight(1f))
                }

                // 4) Customized: bisa dibuka / ditutup
                Column {
                    DockHeader(dockBackdrop, "Customized", customOpen) { customOpen = !customOpen }
                    AnimatedVisibility(
                        visible = customOpen,
                        enter = expandVertically(spring(dampingRatio = 0.8f, stiffness = 400f)) + fadeIn(),
                        exit = shrinkVertically(spring(dampingRatio = 0.8f, stiffness = 500f)) + fadeOut()
                    ) {
                        Column(
                            Modifier.padding(top = 10f.dp),
                            verticalArrangement = Arrangement.spacedBy(10f.dp)
                        ) {
                            DockCaption("Card")
                            DockSliderRow(
                                { m -> DockSlider(dockBackdrop, "Sudut", radiusDp, 0f..144f, "px", m) { radiusDp = it } },
                                { m -> DockSlider(dockBackdrop, "Blur", blurDp, 0f..32f, "px", m) { blurDp = it } }
                            )
                            DockSliderRow(
                                { m -> DockSlider(dockBackdrop, "Opacity", bgOpacity, 0f..100f, "%", m) { bgOpacity = it } },
                                { m -> DockSlider(dockBackdrop, "Tepi cahaya", edge, 0f..100f, "%", m) { edge = it } }
                            )
                            DockSliderRow(
                                { m -> DockSlider(dockBackdrop, "Aberasi", aberration, 0f..100f, "%", m) { aberration = it } },
                                { m -> DockToggle(dockBackdrop, "Latar hitam", bgDark, m) { bgDark = !bgDark } }
                            )
                            DockSliderRow(
                                { m -> DockSlider(dockBackdrop, "Refraksi tinggi", refrHeight, 0f..100f, "%", m) { refrHeight = it } },
                                { m -> DockSlider(dockBackdrop, "Refraksi jumlah", refrAmount, 0f..100f, "%", m) { refrAmount = it } }
                            )

                            DockCaption("Background")
                            DockSliderRow(
                                { m -> DockSlider(dockBackdrop, "Opacity", wallpaperOpacity, 0f..100f, "%", m) { wallpaperOpacity = it } },
                                { m -> DockSlider(dockBackdrop, "Blur", bgBlur, 0f..60f, "px", m) { bgBlur = it } }
                            )

                            // reset ke angka asli jenis card yang dipilih
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .height(46f.dp)
                                    .glass(dockBackdrop, 23f.dp)
                                    .clip(RoundedCornerShape(23f.dp))
                                    .clickable(interactionSource = null, indication = null) {
                                        applyStyle(style)
                                        offset = Offset.Zero
                                    },
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Canvas(Modifier.size(16f.dp)) { drawResetIcon() }
                                Box(Modifier.width(8f.dp))
                                BasicText("Reset", style = dockText(13f, FontWeight.SemiBold), maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        exportState?.let { st ->
            ExportDialog(
                state = st,
                onCancel = {
                    exportJob?.cancel()
                    exportJob = null
                    exportState = null
                },
                onClose = { exportState = null }
            )
        }
    }
}

// =====================================================================================
// Komponen dock — meniru .glass / #tabs / .sl / #toggle / #reset di chord-finder-island
// =====================================================================================

/** Cari Activity dari Context (bisa terbungkus ContextWrapper). */
private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Tombol bulat di pojok preview: maximize (masuk layar penuh) / minimize (keluar). */
@Composable
private fun FullscreenToggle(fullscreen: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .size(34f.dp)
            .alpha(0.8f)
            .background(Color.Black.copy(alpha = 0.4f), CircleShape)
            .clip(CircleShape)
            .clickable(interactionSource = null, indication = null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(16f.dp)) { drawFullscreenIcon(minimize = fullscreen) }
    }
}

/**
 * Ikon 4 sudut: maximize = sudut menghadap keluar, minimize = sudut menghadap ke dalam.
 * Grid 24 x 24.
 */
private fun DrawScope.drawFullscreenIcon(minimize: Boolean) {
    val k = size.width / 24f
    val corners: List<FloatArray> = if (minimize) {
        listOf(
            floatArrayOf(9f, 3f, 9f, 9f, 3f, 9f),
            floatArrayOf(15f, 3f, 15f, 9f, 21f, 9f),
            floatArrayOf(9f, 21f, 9f, 15f, 3f, 15f),
            floatArrayOf(15f, 21f, 15f, 15f, 21f, 15f)
        )
    } else {
        listOf(
            floatArrayOf(3f, 9f, 3f, 3f, 9f, 3f),
            floatArrayOf(15f, 3f, 21f, 3f, 21f, 9f),
            floatArrayOf(3f, 15f, 3f, 21f, 9f, 21f),
            floatArrayOf(21f, 15f, 21f, 21f, 15f, 21f)
        )
    }
    for (c in corners) {
        val path = Path().apply {
            moveTo(c[0] * k, c[1] * k)
            lineTo(c[2] * k, c[3] * k)
            lineTo(c[4] * k, c[5] * k)
        }
        drawPath(path, Color.White, style = Stroke(width = 2.2f * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** .glass terang: putih bening 58% + blur 16 + garis tepi putih tipis. */
internal fun Modifier.glass(backdrop: Backdrop, radius: Dp): Modifier =
    drawBackdrop(
        backdrop = backdrop,
        shape = { RoundedRectangle(radius) },
        effects = { blur(16f.dp.toPx()) },
        highlight = null,
        shadow = null,
        onDrawSurface = { drawRect(Color.White.copy(alpha = 0.58f)) }
    ).border(1f.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(radius))

/** Header sub kategori: pil kaca dengan judul kiri dan panah putar kanan; klik untuk buka/tutup. */
@Composable
private fun DockHeader(backdrop: Backdrop, label: String, open: Boolean, onToggle: () -> Unit) {
    val rotation by animateFloatAsState(
        targetValue = if (open) 180f else 0f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f)
    )
    Row(
        Modifier
            .fillMaxWidth()
            .height(46f.dp)
            .glass(backdrop, 23f.dp)
            .clip(RoundedCornerShape(23f.dp))
            .clickable(interactionSource = null, indication = null) { onToggle() }
            .padding(start = 18f.dp, end = 16f.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicText(
            label,
            style = dockText(14f, FontWeight.SemiBold),
            maxLines = 1
        )
        Canvas(
            Modifier
                .size(18f.dp)
                .graphicsLayer { rotationZ = rotation }
        ) { drawChevronIcon() }
    }
}

/** Ikon panah (chevron) naik: terbuka = menunjuk bawah. */
private fun DrawScope.drawChevronIcon() {
    val path = Path().apply {
        moveTo(6f, 9f)
        lineTo(12f, 15f)
        lineTo(18f, 9f)
    }
    val k = size.width / 24f
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawPath(path, DockInk, style = Stroke(width = 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** #tabs: pil kaca, indikator #eceff7 meluncur dengan spring ke tab aktif. */
@Composable
private fun DockTabs(backdrop: Backdrop, labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .glass(backdrop, 28f.dp)
            .clip(RoundedCornerShape(28f.dp))
            .padding(5f.dp)
    ) {
        val tabW = maxWidth / labels.size
        val x by animateDpAsState(tabW * selected, spring(dampingRatio = 0.72f, stiffness = 380f))
        Box(
            Modifier
                .offset(x = x)
                .width(tabW)
                .height(42f.dp)
                .background(DockInk, RoundedCornerShape(22f.dp))
        )
        Row(Modifier.fillMaxWidth()) {
            labels.forEachIndexed { i, label ->
                Box(
                    Modifier
                        .weight(1f)
                        .height(42f.dp)
                        .clip(RoundedCornerShape(22f.dp))
                        .clickable(interactionSource = null, indication = null) { onSelect(i) },
                    contentAlignment = Alignment.Center
                ) {
                    BasicText(
                        label,
                        style = dockText(
                            11.5f, FontWeight.Medium,
                            if (i == selected) Color.White else DockInk.copy(alpha = 0.68f)
                        ).copy(textAlign = TextAlign.Center),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
    }
}

/**
 * Tile aksi di dock: ikon di atas, label pendek di bawah.
 * [primary] = tile gelap penuh (Export), [active] = sudah terisi (tampil bertinta + tombol hapus kecil).
 */
@Composable
private fun DockTile(
    backdrop: Backdrop,
    label: String,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    active: Boolean = false,
    enabled: Boolean = true,
    onClear: (() -> Unit)? = null,
    icon: DrawScope.(Color) -> Unit,
    onClick: () -> Unit
) {
    val ink = if (primary) Color.White else DockInk
    val fill = when {
        primary -> DockInk
        active -> DockAccent.copy(alpha = 0.16f)
        else -> Color.Transparent
    }
    Box(
        modifier
            .alpha(if (enabled) 1f else 0.45f)
            .height(66f.dp)
            .glass(backdrop, 22f.dp)
            .clip(RoundedCornerShape(22f.dp))
            .background(fill)
            .clickable(interactionSource = null, indication = null, enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5f.dp)
        ) {
            Canvas(Modifier.size(22f.dp)) { icon(this, ink) }
            BasicText(
                label,
                style = dockText(12f, FontWeight.SemiBold, ink).copy(textAlign = TextAlign.Center),
                maxLines = 1,
                softWrap = false
            )
        }
        if (active && onClear != null) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(6f.dp)
                    .size(20f.dp)
                    .clip(CircleShape)
                    .background(DockInk.copy(alpha = 0.12f))
                    .clickable(interactionSource = null, indication = null) { onClear() },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.size(9f.dp)) { drawCloseIcon() }
            }
        }
    }
}

/** Judul kecil untuk mengelompokkan slider di Customized. */
@Composable
private fun DockCaption(text: String) {
    BasicText(
        text.uppercase(),
        Modifier.padding(start = 8f.dp, top = 2f.dp),
        style = dockText(10.5f, FontWeight.SemiBold, DockInk.copy(alpha = 0.6f)).copy(letterSpacing = 0.8f.sp),
        maxLines = 1
    )
}

/** Pil toggle: label kiri, switch kanan. Tinggi sama dengan slider supaya baris rata. */
@Composable
private fun DockToggle(
    backdrop: Backdrop,
    label: String,
    on: Boolean,
    modifier: Modifier = Modifier,
    onToggle: () -> Unit
) {
    Row(
        modifier
            .height(46f.dp)
            .glass(backdrop, 23f.dp)
            .clip(RoundedCornerShape(23f.dp))
            .clickable(interactionSource = null, indication = null) { onToggle() }
            .padding(start = 15f.dp, end = 10f.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicText(label, style = dockText(12.5f, FontWeight.Normal), maxLines = 1)
        DockSwitch(on)
    }
}

/** Ikon silang (hapus). Grid 24 x 24. */
private fun DrawScope.drawCloseIcon() {
    val k = size.width / 24f
    val path = Path().apply {
        moveTo(6f, 6f); lineTo(18f, 18f)
        moveTo(18f, 6f); lineTo(6f, 18f)
    }
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawPath(path, DockInk, style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Ikon sampul: bingkai persegi dengan piringan di tengah. Grid 24 x 24. */
private fun DrawScope.drawDiscIcon(color: Color) {
    val k = size.width / 24f
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawRoundRect(
            color, topLeft = Offset(3f, 3f), size = Size(18f, 18f),
            cornerRadius = CornerRadius(4f, 4f), style = Stroke(width = 2f)
        )
        drawCircle(color, radius = 4f, center = Offset(12f, 12f), style = Stroke(width = 2f))
        drawCircle(color, radius = 1f, center = Offset(12f, 12f))
    }
}

/** Ikon background: bingkai foto dengan matahari dan gunung. Grid 24 x 24. */
private fun DrawScope.drawLandscapeIcon(color: Color) {
    val k = size.width / 24f
    val hills = Path().apply {
        moveTo(4f, 18f); lineTo(10f, 12.5f); lineTo(14f, 16f); lineTo(16.5f, 13.8f); lineTo(20f, 17f)
    }
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawRoundRect(
            color, topLeft = Offset(3f, 4f), size = Size(18f, 16f),
            cornerRadius = CornerRadius(3.5f, 3.5f), style = Stroke(width = 2f)
        )
        drawCircle(color, radius = 1.7f, center = Offset(9f, 9.5f))
        drawPath(hills, color, style = Stroke(width = 2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Ikon export: panah ke bawah di atas garis alas. Grid 24 x 24. */
private fun DrawScope.drawDownloadIcon(color: Color) {
    val k = size.width / 24f
    val path = Path().apply {
        moveTo(12f, 4f); lineTo(12f, 15f)
        moveTo(7f, 10.5f); lineTo(12f, 15.5f); lineTo(17f, 10.5f)
        moveTo(5f, 20f); lineTo(19f, 20f)
    }
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawPath(path, color, style = Stroke(width = 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

private fun formatClock(ms: Long): String {
    val total = (ms / 1000L).toInt()
    return "${total / 60}:${(total % 60).toString().padStart(2, '0')}"
}

@Composable
private fun DockSliderRow(left: @Composable (Modifier) -> Unit, right: @Composable (Modifier) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10f.dp)) {
        left(Modifier.weight(1f))
        right(Modifier.weight(1f))
    }
}

/** .sl: pil kaca 46dp, isi putih 34% dengan garis putih 3dp di ujung, label kiri, nilai tebal kanan. */
@Composable
private fun DockSlider(
    backdrop: Backdrop,
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    unit: String,
    modifier: Modifier = Modifier,
    onChange: (Float) -> Unit
) {
    val currentOnChange by rememberUpdatedState(onChange)
    val currentValue by rememberUpdatedState(value)
    val span = range.endInclusive - range.start
    val frac = if (span > 0f) ((value - range.start) / span).coerceIn(0f, 1f) else 0f
    val textStyle = dockText(12.5f, FontWeight.Normal)

    Box(
        modifier
            .height(46f.dp)
            .glass(backdrop, 23f.dp)
            .clip(RoundedCornerShape(23f.dp))
            // Anti salah sentuh: tap TIDAK mengubah nilai, dan gerakan baru dianggap geser slider kalau
            // jelas mendatar. Gerakan vertikal (scroll dock) dilepas ke scroll. Geseran bersifat relatif
            // dari nilai saat ini, jadi nilai tidak pernah melompat ke posisi jari.
            .pointerInput(range) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = true)
                    val slop = viewConfiguration.touchSlop
                    var dx = 0f
                    var dy = 0f
                    var locked = false
                    var v = currentValue
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break
                        if (!locked) {
                            if (change.isConsumed) break // scroll sudah mengambil alih
                            val d = change.positionChange()
                            dx += d.x
                            dy += d.y
                            if (abs(dy) > slop && abs(dy) * 1.5f >= abs(dx)) break // vertikal: scroll
                            if (abs(dx) > slop * 2f && abs(dx) > abs(dy) * 2f) {
                                locked = true
                                v = currentValue
                            }
                        } else {
                            val d = change.positionChange()
                            change.consume()
                            if (size.width > 0) {
                                v = (v + d.x / size.width * span).coerceIn(range.start, range.endInclusive)
                                currentOnChange(v)
                            }
                        }
                    }
                }
            }
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(frac)
                .background(DockAccent.copy(alpha = 0.22f))
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .width(3f.dp)
                    .fillMaxHeight()
                    .background(DockAccent)
            )
        }
        BasicText(
            label,
            Modifier
                .align(Alignment.CenterStart)
                .padding(start = 15f.dp, end = 48f.dp),
            style = textStyle,
            maxLines = 1
        )
        BasicText(
            "${value.roundToInt()}$unit",
            Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 14f.dp),
            style = textStyle.copy(fontWeight = FontWeight.SemiBold, fontFeatureSettings = "tnum"),
            maxLines = 1
        )
    }
}

@Composable
private fun DockTextField(
    backdrop: Backdrop,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = dockText(13f, FontWeight.Normal),
        cursorBrush = SolidColor(DockAccent),
        modifier = modifier
            .height(42f.dp)
            .glass(backdrop, 21f.dp)
            .clip(RoundedCornerShape(21f.dp)),
        decorationBox = { inner ->
            Box(Modifier.padding(horizontal = 16f.dp), contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) {
                    BasicText(
                        placeholder,
                        style = dockText(13f, FontWeight.Normal, DockInk.copy(alpha = 0.45f))
                    )
                }
                inner()
            }
        }
    )
}

/** .sw: 38 x 24, bulatan 18 yang bergeser 14 dengan spring. */
@Composable
private fun DockSwitch(on: Boolean) {
    val x by animateDpAsState(if (on) 17f.dp else 3f.dp, spring(dampingRatio = 0.6f, stiffness = 400f))
    Box(
        Modifier
            .size(38f.dp, 24f.dp)
            .background(if (on) DockInk else DockInk.copy(alpha = 0.16f), RoundedCornerShape(12f.dp))
    ) {
        Box(
            Modifier
                .offset(x = x, y = 3f.dp)
                .size(18f.dp)
                .background(Color.White, CircleShape)
        )
    }
}

/** Ikon reset: path "M20 12a8 8 0 1 1-2.3-5.6M20 4v4h-4" dari HTML. */
private fun DrawScope.drawResetIcon() {
    val path = Path().apply {
        moveTo(20f, 12f)
        arcTo(Rect(4f, 4f, 20f, 20f), 0f, 315.5f, false)
        moveTo(20f, 4f)
        lineTo(20f, 8f)
        lineTo(16f, 8f)
    }
    val k = size.width / 24f
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawPath(path, DockInk, style = Stroke(width = 2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
