package com.kyant.backdrop.catalog

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.highlight.Highlight
import com.kyant.shapes.RoundedRectangle
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.roundToInt

private val InkColor = Color(0xFF0B0F2E)

private const val DefTitle = "Liquid Glass"
private const val DefSubtitle = "Card persegi custom"
private const val DefSize = 220f
private const val DefRadius = 44f
private const val DefBlur = 2f
private const val DefTint = 12f
private const val DefSpec = 55f
private const val DefEdge = 100f
private const val DefRefrHeight = 20f
private const val DefRefrAmount = 20f
private const val DefAberration = 0f

/**
 * Satu card liquid glass + panel pengaturan.
 * Efek glass memakai library `backdrop` (drawBackdrop + vibrancy + blur + lens).
 */
@Composable
fun LiquidGlassCardScreen() {
    val backdrop = rememberLayerBackdrop()

    // ---- pengaturan card ----
    var title by rememberSaveable { mutableStateOf(DefTitle) }
    var subtitle by rememberSaveable { mutableStateOf(DefSubtitle) }
    var sizeDp by rememberSaveable { mutableStateOf(DefSize) }
    var radiusDp by rememberSaveable { mutableStateOf(DefRadius) }
    var blurDp by rememberSaveable { mutableStateOf(DefBlur) }
    var tint by rememberSaveable { mutableStateOf(DefTint) }
    var spec by rememberSaveable { mutableStateOf(DefSpec) }
    var edge by rememberSaveable { mutableStateOf(DefEdge) }
    var refrHeight by rememberSaveable { mutableStateOf(DefRefrHeight) }
    var refrAmount by rememberSaveable { mutableStateOf(DefRefrAmount) }
    var aberration by rememberSaveable { mutableStateOf(DefAberration) }

    // ---- geser card ----
    var offset by remember { mutableStateOf(Offset.Zero) }
    var isPressed by remember { mutableStateOf(false) }
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed) 1.05f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 300f)
    )

    // animasi wallpaper (sama seperti CSS: d1 26s, d2 31s, d3 23s, b4 29s reverse, glow 5s)
    val wallTransition = rememberInfiniteTransition()
    val easeInOut = CubicBezierEasing(0.42f, 0f, 0.58f, 1f)
    val t1 by wallTransition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(26000, easing = easeInOut), RepeatMode.Reverse)
    )
    val t2 by wallTransition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(31000, easing = easeInOut), RepeatMode.Reverse)
    )
    val t3 by wallTransition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(23000, easing = easeInOut), RepeatMode.Reverse)
    )
    val t4 by wallTransition.animateFloat(
        1f, 0f, infiniteRepeatable(tween(29000, easing = easeInOut), RepeatMode.Reverse)
    )
    val glowT by wallTransition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(5000, easing = easeInOut), RepeatMode.Reverse)
    )

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = maxWidth
        val h = maxHeight
        val maxCard = minOf(420f, minOf(w.value, h.value) * 0.9f)
        val cardSize = sizeDp.coerceIn(90f, maxCard).dp
        val cardRadius = radiusDp.coerceAtMost(cardSize.value / 2f).dp
        val titleSize = (w.value * 0.16f).coerceIn(46f, 110f).sp

        // ---------- wallpaper + objek di belakang kaca ----------
        Box(
            Modifier
                .fillMaxSize()
                .layerBackdrop(backdrop)
                .drawBehind { drawWallpaper(t1, t2, t3, t4, glowT) }
        ) {
            BasicText(
                "Liquid",
                Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = h * 0.09f),
                style = TextStyle(
                    color = InkColor.copy(alpha = 0.9f),
                    fontSize = titleSize,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.03f).em
                ),
                maxLines = 1,
                softWrap = false
            )
            Box(
                Modifier
                    .offset(x = w * 0.09f, y = h * 0.30f)
                    .size(120f.dp)
                    .background(Color(25, 184, 255), CircleShape)
            )
            Box(
                Modifier
                    .offset(x = w - w * 0.09f - 90f.dp, y = h * 0.35f)
                    .size(90f.dp)
                    .background(Color(123, 75, 255), CircleShape)
            )
            Box(
                Modifier
                    .offset(x = w * 0.54f, y = h * 0.41f)
                    .size(60f.dp)
                    .background(Color.White, CircleShape)
            )
            Box(
                Modifier
                    .offset(x = w * 0.06f, y = h * 0.38f)
                    .width(w * 0.88f)
                    .height(10f.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFFDBE7FF), Color(45, 91, 255), Color(123, 75, 255))
                        ),
                        RoundedCornerShape(5f.dp)
                    )
            )
        }

        BasicText(
            "Geser card untuk memindahkan",
            Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 12f.dp),
            style = TextStyle(color = InkColor.copy(alpha = 0.6f), fontSize = 12f.sp)
        )

        // ---------- CARD LIQUID GLASS ----------
        Box(
            Modifier
                .align(Alignment.TopStart)
                .offset(x = (w - cardSize) / 2f, y = h * 0.38f - cardSize / 2f)
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { RoundedRectangle(cardRadius) },
                    effects = {
                        val minDimension = size.minDimension
                        vibrancy()
                        blur(blurDp.dp.toPx())
                        lens(
                            refractionHeight = refrHeight / 100f * minDimension * 0.5f,
                            refractionAmount = refrAmount / 100f * minDimension,
                            depthEffect = true,
                            chromaticAberration = aberration > 0f
                        )
                    },
                    highlight = { Highlight.Plain.copy(alpha = (edge / 100f).coerceIn(0f, 1f)) },
                    layerBlock = {
                        translationX = offset.x
                        translationY = offset.y
                        scaleX = pressScale
                        scaleY = pressScale
                    },
                    onDrawSurface = {
                        drawRect(InkColor.copy(alpha = (tint / 100f).coerceIn(0f, 1f)))
                        drawRect(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = (spec / 100f * 0.5f).coerceIn(0f, 1f)),
                                    Color.Transparent
                                ),
                                center = Offset(size.width * 0.3f, size.height * 0.2f),
                                radius = size.minDimension * 0.7f
                            )
                        )
                    }
                )
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { isPressed = true },
                        onDragEnd = { isPressed = false },
                        onDragCancel = { isPressed = false },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            offset += dragAmount * pressScale
                        }
                    )
                }
                .size(cardSize)
        ) {
            Canvas(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(cardSize * 0.1f)
                    .size(cardSize * 0.17f)
            ) {
                drawDropIcon()
            }
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(cardSize * 0.1f)
            ) {
                BasicText(
                    title,
                    style = TextStyle(
                        color = Color.White,
                        fontSize = (cardSize.value * 0.11f).sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                BasicText(
                    subtitle,
                    Modifier.padding(top = 4f.dp),
                    style = TextStyle(
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = (cardSize.value * 0.06f).sp
                    )
                )
            }
        }

        // ---------- PANEL PENGATURAN ----------
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 10f.dp)
                .padding(bottom = 10f.dp)
                .navigationBarsPadding()
                .imePadding()
                .widthIn(max = 560f.dp)
                .fillMaxWidth()
                .heightIn(max = h * 0.46f)
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { RoundedRectangle(26f.dp) },
                    effects = {
                        vibrancy()
                        blur(8f.dp.toPx())
                        lens(12f.dp.toPx(), 24f.dp.toPx())
                    },
                    onDrawSurface = { drawRect(InkColor.copy(alpha = 0.5f)) }
                )
                .verticalScroll(rememberScrollState())
                .padding(start = 16f.dp, end = 16f.dp, top = 14f.dp, bottom = 12f.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8f.dp)
            ) {
                SettingTextField(title, { title = it }, "Judul", Modifier.weight(1f))
                SettingTextField(subtitle, { subtitle = it }, "Subjudul", Modifier.weight(1f))
            }
            Box(Modifier.height(6f.dp))

            SettingSlider("Ukuran", sizeDp.coerceIn(90f, maxCard), 90f..maxCard, "px") { sizeDp = it }
            SettingSlider("Sudut", radiusDp, 0f..210f, "px") { radiusDp = it }
            SettingSlider("Blur", blurDp, 0f..32f, "px") { blurDp = it }
            SettingSlider("Gelap", tint, 0f..70f, "%") { tint = it }
            SettingSlider("Kilau", spec, 0f..100f, "%") { spec = it }
            SettingSlider("Tepi cahaya", edge, 0f..100f, "%") { edge = it }
            SettingSlider("Refraksi tinggi", refrHeight, 0f..100f, "%") { refrHeight = it }
            SettingSlider("Refraksi jumlah", refrAmount, 0f..100f, "%") { refrAmount = it }
            SettingSlider("Aberasi warna", aberration, 0f..100f, "%") { aberration = it }

            Box(
                Modifier
                    .padding(top = 8f.dp)
                    .fillMaxWidth()
                    .height(40f.dp)
                    .background(Color.White.copy(alpha = 0.14f), RoundedCornerShape(20f.dp))
                    .clickable {
                        title = DefTitle
                        subtitle = DefSubtitle
                        sizeDp = DefSize
                        radiusDp = DefRadius
                        blurDp = DefBlur
                        tint = DefTint
                        spec = DefSpec
                        edge = DefEdge
                        refrHeight = DefRefrHeight
                        refrAmount = DefRefrAmount
                        aberration = DefAberration
                        offset = Offset.Zero
                    },
                contentAlignment = Alignment.Center
            ) {
                BasicText(
                    "Reset",
                    style = TextStyle(color = Color.White, fontSize = 13f.sp, fontWeight = FontWeight.SemiBold)
                )
            }
        }
    }
}

@Composable
private fun SettingTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 13f.sp),
        cursorBrush = SolidColor(Color.White),
        modifier = modifier
            .height(36f.dp)
            .background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(18f.dp)),
        decorationBox = { inner ->
            Box(Modifier.padding(horizontal = 14f.dp), contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) {
                    BasicText(
                        placeholder,
                        style = TextStyle(color = Color.White.copy(alpha = 0.55f), fontSize = 13f.sp)
                    )
                }
                inner()
            }
        }
    )
}

@Composable
private fun SettingSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    unit: String,
    onChange: (Float) -> Unit
) {
    val currentOnChange by rememberUpdatedState(onChange)
    val textStyle = TextStyle(color = Color.White, fontSize = 12f.sp)

    Row(
        Modifier
            .fillMaxWidth()
            .height(34f.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicText(label, Modifier.width(104f.dp), style = textStyle, maxLines = 1)
        Box(
            Modifier
                .weight(1f)
                .height(30f.dp)
                .pointerInput(range) {
                    detectTapGestures { currentOnChange(sliderValueAt(it.x, size.width.toFloat(), 11f.dp.toPx(), range)) }
                }
                .pointerInput(range) {
                    detectHorizontalDragGestures { change, _ ->
                        change.consume()
                        currentOnChange(sliderValueAt(change.position.x, size.width.toFloat(), 11f.dp.toPx(), range))
                    }
                }
                .drawBehind {
                    val r = 11f.dp.toPx()
                    val trackH = 6f.dp.toPx()
                    val span = range.endInclusive - range.start
                    val frac = if (span > 0f) ((value - range.start) / span).coerceIn(0f, 1f) else 0f
                    val cx = r + frac * (size.width - 2f * r)
                    val cy = size.height / 2f
                    val top = Offset(0f, cy - trackH / 2f)
                    drawRoundRect(
                        Color.White.copy(alpha = 0.2f), top, Size(size.width, trackH),
                        CornerRadius(trackH / 2f)
                    )
                    drawRoundRect(
                        Color.White.copy(alpha = 0.85f), top, Size(cx, trackH),
                        CornerRadius(trackH / 2f)
                    )
                    drawCircle(Color(0xFFECEFF7), r, Offset(cx, cy))
                }
        )
        BasicText(
            "${value.roundToInt()}$unit",
            Modifier
                .width(52f.dp)
                .padding(start = 8f.dp),
            style = textStyle.copy(fontWeight = FontWeight.Bold, textAlign = TextAlign.End),
            maxLines = 1
        )
    }
}

private fun sliderValueAt(x: Float, width: Float, thumbRadius: Float, range: ClosedFloatingPointRange<Float>): Float {
    val usable = width - 2f * thumbRadius
    val frac = if (usable > 0f) ((x - thumbRadius) / usable).coerceIn(0f, 1f) else 0f
    return range.start + frac * (range.endInclusive - range.start)
}

/**
 * Wallpaper persis seperti #bg di HTML:
 * linear-gradient(160deg, ...) + 4 blob radial + glow elips putih di atas.
 */
private fun DrawScope.drawWallpaper(t1: Float, t2: Float, t3: Float, t4: Float, glowT: Float) {
    val w = size.width
    val h = size.height
    val m = max(w, h) // 1vmax

    // linear-gradient(160deg, #dbe7ff 0%, #b7cdff 30%, #7e95ff 62%, #4b3fd0 100%)
    val angle = 160f * (PI.toFloat() / 180f)
    val dx = sin(angle)
    val dy = -cos(angle)
    val length = abs(w * sin(angle)) + abs(h * cos(angle))
    val mid = Offset(w / 2f, h / 2f)
    drawRect(
        Brush.linearGradient(
            0f to Color(0xFFDBE7FF),
            0.3f to Color(0xFFB7CDFF),
            0.62f to Color(0xFF7E95FF),
            1f to Color(0xFF4B3FD0),
            start = Offset(mid.x - dx * length / 2f, mid.y - dy * length / 2f),
            end = Offset(mid.x + dx * length / 2f, mid.y + dy * length / 2f)
        )
    )

    // radial-gradient(closest-side, warna, transparent)
    fun blob(color: Color, cx: Float, cy: Float, r: Float) {
        val c = Offset(cx, cy)
        drawCircle(
            brush = Brush.radialGradient(listOf(color, Color.Transparent), center = c, radius = r),
            radius = r,
            center = c
        )
    }

    // .b1 90vmax, d1: translate(14vmax, -8vmax)
    blob(
        Color(123, 75, 255).copy(alpha = 0.9f),
        0.10f * m + 0.14f * m * t1, 0.35f * h + 0.45f * m - 0.08f * m * t1, 0.45f * m
    )
    // .b2 80vmax, d2: translate(-12vmax, 10vmax)
    blob(
        Color(45, 91, 255).copy(alpha = 0.85f),
        w - 0.10f * m - 0.12f * m * t2, -0.10f * h + 0.40f * m + 0.10f * m * t2, 0.40f * m
    )
    // .b3 70vmax, d3: translate(10vmax, -12vmax)
    blob(
        Color(25, 184, 255).copy(alpha = 0.8f),
        0.05f * w + 0.35f * m + 0.10f * m * t3, h - 0.12f * m * t3, 0.35f * m
    )
    // .b4 55vmax, d2 (reverse)
    blob(
        Color(210, 240, 255).copy(alpha = 0.95f),
        0.20f * w + 0.275f * m - 0.12f * m * t4, 0.075f * m + 0.10f * m * t4, 0.275f * m
    )

    // #glow: radial-gradient(ellipse 70vw 60vh at 50% -12%, #fff 0%, rgba(255,255,255,.65) 30%, transparent 62%)
    // opacity .82 -> 1
    val rx = 0.7f * w
    val ry = 0.6f * h
    val glowCenter = Offset(w / 2f, -0.12f * h)
    withTransform({ scale(1f, ry / rx, pivot = glowCenter) }) {
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color.White,
                0.3f to Color.White.copy(alpha = 0.65f),
                0.62f to Color.Transparent,
                1f to Color.Transparent,
                center = glowCenter,
                radius = rx
            ),
            radius = rx,
            center = glowCenter,
            alpha = 0.82f + 0.18f * glowT
        )
    }
}

/** Ikon tetesan air (outline putih) di sudut kiri atas card. */
private fun DrawScope.drawDropIcon() {
    val path = Path().apply {
        moveTo(12f, 3f)
        cubicTo(15.5f, 7.2f, 18f, 10f, 18f, 13.2f)
        arcTo(Rect(6f, 7.2f, 18f, 19.2f), 0f, 180f, false)
        cubicTo(6f, 10f, 8.5f, 7.2f, 12f, 3f)
        close()
    }
    val s = size.width / 24f
    withTransform({ scale(s, s, pivot = Offset.Zero) }) {
        drawPath(
            path,
            Color.White.copy(alpha = 0.9f),
            style = Stroke(width = 1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}
