package com.kyant.backdrop.catalog

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.colorControls
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.highlight.Highlight
import com.kyant.backdrop.highlight.HighlightStyle
import com.kyant.shapes.RoundedRectangle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.roundToInt

private val InkColor = Color(0xFF0B0F2E)

// ---- tema dock terang di atas latar gradient animasi ----
internal val DockInk = Color(0xFF0B0F2E)
internal val DockAccent = Color(0xFF4B5BFF)
private val CanvasCorner = 14f // sudut canvas preview: melengkung sedikit saja

/** Teks dock: Inter (pengganti SF Pro yang berlisensi) dengan kerapatan huruf ala iOS. */
internal fun dockText(size: Float, weight: FontWeight = FontWeight.Medium, color: Color = DockInk) = TextStyle(
    color = color,
    fontSize = size.sp,
    fontWeight = weight,
    fontFamily = PlayerFont,
    letterSpacing = sfTracking(size).sp
)

private const val DefSize = 256f // sama dengan GlassPlayground asli

// Canvas 9:16 selalu 360 x 640 dp secara logis. Resolusi hanya mengubah kerapatan pixel
// (1080p -> 3x, 1280p -> 2x), jadi komposisi card + foto identik di kedua resolusi.
internal const val CanvasWDp = 360f

// Ukuran card TETAP, diukur dari hasil render Alight Motion (Proyek Baru.png, canvas 1080x1920):
// persegi panjang x 107..973, y 180..1740 = 866 x 1560 px (di XML: size 100x180 * scale 4.33, dan
// AM menggambar size itu 2x -> 866 x 1558.8). Dibagi 3 = 288.67 x 519.6 dp di canvas logis 360x640.
internal const val CardWDp = 866f / 3f
internal const val CardHDp = 1558.8f / 3f

/** Resolusi canvas 9:16. 1080p = 1080x1920, 1280p = 720x1280. */
private enum class CanvasRes(val label: String, val w: Int, val h: Int) {
    P1080("1080p", 1080, 1920),
    P1280("1280p", 720, 1280)
}

/** Jenis card yang diambil apa adanya dari catalog project asli (Kyant0/AndroidLiquidGlass). */
private enum class CardStyle(val label: String, val short: String, val source: String) {
    Playground("Playground", "Dasar", "GlassPlaygroundContent"),
    Panel("Panel", "Panel", "GlassPlayground sheet"),
    DialogLight("Dialog terang", "Terang", "DialogContent (light)"),
    DialogDark("Dialog gelap", "Gelap", "DialogContent (dark)"),
    Round("Bulat / Button", "Bulat", "LiquidButton"),
    ControlCenter("Control Center", "Control", "ControlCenterContent")
}

/**
 * Semua angka di sini disalin dari project asli. Refraksi dalam % supaya cocok dengan
 * slider: height% = refractionHeight / (minDim * 0.5), amount% = refractionAmount / minDim,
 * dihitung untuk card 256dp (ukuran card di GlassPlayground asli).
 */
private data class Preset(
    val radius: Float,          // dp
    val blur: Float,            // dp
    val refrHeight: Float,      // %
    val refrAmount: Float,      // %
    val bgColor: Color,         // warna onDrawSurface
    val bgOpacity: Float,       // % (0..100)
    val brightness: Float?,     // null = vibrancy(), selain itu colorControls(...)
    val saturation: Float = 1.5f,
    val plainHighlight: Boolean = true,
    val titleColor: Color = Color.White
)

private fun CardStyle.preset(): Preset = when (this) {
    // GlassPlaygroundContent: radius 256/2*0.5, blur 0, lens 0.2/0.2, Highlight.Plain, tanpa surface
    CardStyle.Playground -> Preset(64f, 0f, 20f, 20f, Color.White, 0f, null)
    // sheet di GlassPlayground: RoundedRectangle(32), blur 4, lens(16, 32), putih 0.5
    CardStyle.Panel -> Preset(32f, 4f, 12.5f, 12.5f, Color.White, 50f, null, titleColor = Color(0xFF111111))
    // DialogContent light: colorControls(0.2, sat 1.5), blur 16, lens(24, 48, depth), FAFAFA @ 0.6
    CardStyle.DialogLight -> Preset(48f, 16f, 18.75f, 18.75f, Color(0xFFFAFAFA), 60f, 0.2f, titleColor = Color.Black)
    // DialogContent dark: blur 8, 121212 @ 0.4
    CardStyle.DialogDark -> Preset(48f, 8f, 18.75f, 18.75f, Color(0xFF121212), 40f, 0f)
    // LiquidButton: vibrancy, blur 2, lens(12, 24), highlight default, capsule
    CardStyle.Round -> Preset(128f, 2f, 9.375f, 9.375f, Color.White, 0f, null, plainHighlight = false)
    // ControlCenterContent: vibrancy, lens(24, 48, depth), putih 0.05 (diubah dari hitam: opacity dinaikkan jadi putih seperti mode Dasar), highlight Default(falloff 2)
    CardStyle.ControlCenter -> Preset(48f, 0f, 18.75f, 18.75f, Color.White, 5f, null, plainHighlight = false)
}

/**
 * Satu card liquid glass + panel pengaturan.
 * Efek glass memakai library `backdrop` dengan parameter yang sama seperti catalog asli.
 */
@Composable
fun LiquidGlassCardScreen() {
    val backdrop = rememberLayerBackdrop()       // backdrop di dalam canvas (untuk card)
    val dockBackdrop = rememberLayerBackdrop()   // backdrop latar studio (untuk dock)
    val player = rememberAudioPlayer()           // di luar key(cardRadius) supaya audio tidak putus saat card dibuat ulang
    val glassCapture = rememberGlassCapture()    // tangkap canvas tanpa controls untuk export video
    val bg = rememberBackgroundState()           // background canvas (foto) — terpisah dari sampul

    // ---- pilihan jenis card ----
    var styleName by rememberSaveable { mutableStateOf(CardStyle.Playground.name) }
    val style = CardStyle.valueOf(styleName)
    val res = CanvasRes.P1080 // resolusi tunggal 1080x1920

    // ---- pengaturan card ----
    val p0 = CardStyle.Playground.preset()
    var radiusDp by rememberSaveable { mutableStateOf(p0.radius) }
    var blurDp by rememberSaveable { mutableStateOf(p0.blur) }
    var bgOpacity by rememberSaveable { mutableStateOf(p0.bgOpacity) }
    var bgDark by rememberSaveable { mutableStateOf(false) } // warna latar: putih / hitam
    var edge by rememberSaveable { mutableStateOf(100f) }
    var refrHeight by rememberSaveable { mutableStateOf(p0.refrHeight) }
    var refrAmount by rememberSaveable { mutableStateOf(p0.refrAmount) }
    var aberration by rememberSaveable { mutableStateOf(0f) }
    // opacity foto/latar utama; .alpha() harus SETELAH .layerBackdrop() supaya rekaman backdrop (isi kaca) ikut redup
    var wallpaperOpacity by rememberSaveable { mutableStateOf(100f) }
    // blur foto/latar utama di canvas (Modifier.blur: efek nyata di Android 12+)
    var bgBlur by rememberSaveable { mutableStateOf(0f) }
    // sub kategori Customized (default tertutup biar dock bersih)
    var customOpen by rememberSaveable { mutableStateOf(false) }
    // mode layar penuh: dock + status bar + nav bar disembunyikan, preview 9:16 memenuhi layar
    var fullscreen by rememberSaveable { mutableStateOf(false) }

    val hostView = LocalView.current
    DisposableEffect(fullscreen) {
        val window = hostView.context.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, hostView) }
        if (fullscreen) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    BackHandler(enabled = fullscreen) { fullscreen = false }

    val preset = style.preset()
    // ---- export video ----
    val exportScope = rememberCoroutineScope()
    val appContext = LocalContext.current.applicationContext
    val exportMeasurer = rememberTextMeasurer() // instance sendiri, dipakai di background saat export
    var exportState by remember { mutableStateOf<ExportUiState?>(null) }
    var exportJob by remember { mutableStateOf<Job?>(null) }
    val exporting = exportState?.finished == false
    DisposableEffect(exporting) {
        hostView.keepScreenOn = exporting // layar jangan mati selama export
        onDispose { hostView.keepScreenOn = false }
    }
    // ---- upload terpisah: sampul (di card) dan background (di canvas, foto) ----
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) exportScope.launch { player.loadCover(uri) }
    }
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) exportScope.launch { bg.load(uri) }
    }

    val startExport: () -> Unit = {
        if (exportJob?.isActive != true && player.loaded) {
            exportState = ExportUiState("Menyiapkan…", 0f)
            exportJob = exportScope.launch {
                runExport(appContext, player, glassCapture, exportMeasurer, preset.titleColor, radiusDp) {
                    exportState = it
                }
            }
        }
    }

    val presetIsDark = preset.bgColor.red < 0.2f && preset.bgColor.green < 0.2f && preset.bgColor.blue < 0.2f
    val bgBase = when {
        bgDark && presetIsDark -> preset.bgColor
        bgDark -> Color.Black
        !presetIsDark -> preset.bgColor
        else -> Color.White
    }

    fun applyStyle(s: CardStyle) {
        val p = s.preset()
        styleName = s.name
        radiusDp = p.radius
        blurDp = p.blur
        refrHeight = p.refrHeight
        refrAmount = p.refrAmount
        bgOpacity = p.bgOpacity
        bgDark = p.bgColor.red < 0.2f && p.bgColor.green < 0.2f && p.bgColor.blue < 0.2f
        edge = 100f
        aberration = 0f
    }

    // ---- geser card ----
    var offset by remember { mutableStateOf(Offset.Zero) }
    var isPressed by remember { mutableStateOf(false) }
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed) 1.05f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 300f)
    )

    // ---- aurora latar utama (di luar canvas): 3 warna dominan dari isi canvas (foto background, atau foto bawaan kalau belum ada); geraknya ikut spektrum audio ----
    val defaultWall = ImageBitmap.imageResource(R.drawable.wallpaper_light)
    val paletteSource = bg.paletteSource ?: defaultWall
    val palette = remember(paletteSource) { extractAuroraPalette(paletteSource) }
    val auroraC0 by animateColorAsState(palette[0], tween(900))
    val auroraC1 by animateColorAsState(palette[1], tween(900))
    val auroraC2 by animateColorAsState(palette[2], tween(900))

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val screenH = maxHeight

        // ---------- latar utama: aurora dari warna isi canvas (selalu aktif, normal maupun layar penuh) ----------
        Box(
            Modifier
                .fillMaxSize()
                .layerBackdrop(dockBackdrop)
        ) {
            AuroraBackground(
                auroraC0, auroraC1, auroraC2, player,
                Modifier.fillMaxSize()
            )
        }

        Column(Modifier.fillMaxSize()) {
            // jarak untuk status bar (hilang saat layar penuh)
            if (!fullscreen) Box(Modifier.statusBarsPadding().height(10f.dp))

            // ---------- area canvas: 9:16, diskalakan agar muat di layar ----------
            BoxWithConstraints(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(
                        horizontal = if (fullscreen) 0f.dp else 16f.dp,
                        vertical = if (fullscreen) 0f.dp else 4f.dp
                    ),
                contentAlignment = Alignment.Center
            ) {
                val dispW = minOf(maxWidth.value, maxHeight.value * 9f / 16f).coerceAtLeast(1f).dp
                val dispH = (dispW.value * 16f / 9f).dp
                val deviceDensity = LocalDensity.current
                val fit = with(deviceDensity) { dispW.toPx() } / res.w
                val canvasW = with(deviceDensity) { res.w.toDp() }
                val canvasH = with(deviceDensity) { res.h.toDp() }

                val canvasShape = RoundedCornerShape(CanvasCorner.dp)
                Box(
                    Modifier
                        .size(dispW, dispH)
                        .then(
                            if (fullscreen) Modifier else Modifier
                                .shadow(
                                    elevation = 22f.dp,
                                    shape = canvasShape,
                                    clip = false,
                                    ambientColor = DockInk.copy(alpha = 0.18f),
                                    spotColor = DockInk.copy(alpha = 0.28f)
                                )
                                .clip(canvasShape)
                                .border(1f.dp, Color.White.copy(alpha = 0.85f), canvasShape)
                        )
                ) {
                    // canvas dirender di ukuran pixel asli (res.w x res.h), lalu diperkecil untuk tampilan
                    Box(
                        Modifier
                            .requiredSize(canvasW, canvasH)
                            .graphicsLayer {
                                scaleX = fit
                                scaleY = fit
                                transformOrigin = TransformOrigin.Center
                                clip = true
                            }
                    ) {
                        // di dalam canvas: 360 x 640 dp logis, kerapatan = res.w / 360
                        CompositionLocalProvider(LocalDensity provides Density(res.w / CanvasWDp, 1f)) {
                            BoxWithConstraints(Modifier.fillMaxSize().glassCapture(glassCapture)) {
                                val w = maxWidth
                                val h = maxHeight
                                val cardW = CardWDp.dp
                                val cardH = CardHDp.dp
                                val cardMin = cardW // sisi terpendek, dipakai untuk skala ikon & teks
                                val cardRadius = radiusDp.coerceAtMost(CardWDp / 2f).dp

                                // ---------- wallpaper + objek di belakang kaca ----------
                                val wallpaperAlpha = (wallpaperOpacity / 100f).coerceIn(0f, 1f)
                                // isi canvas: background khusus (foto), atau foto bawaan kalau belum ada.
                                // TIDAK memakai sampul: sampul hanya tampil di dalam card.
                                val bgImg = bg.display
                                val bgPainter = if (bgImg != null) {
                                    remember(bgImg) { BitmapPainter(bgImg) }
                                } else {
                                    painterResource(R.drawable.wallpaper_light)
                                }
                                Image(
                                    bgPainter,
                                    null,
                                    Modifier
                                        .fillMaxSize()
                                        .layerBackdrop(backdrop)
                                        // lapisan paling bawah: hitam penuh (di dalam rekaman backdrop, di luar blur/alpha foto)
                                        .background(Color.Black)
                                        .blur(bgBlur.dp)
                                        .alpha(wallpaperAlpha),
                                    contentScale = ContentScale.Crop
                                )


                                // ---------- CARD LIQUID GLASS ----------
                                // key(cardRadius): library backdrop tidak memperbarui clip layer kaca saat bentuk berubah
                                // (hanya tepi/highlight yang ikut), jadi card dibuat ulang tiap radius berganti.
                                key(cardRadius) {
                                    Box(
                                        Modifier
                                            .align(Alignment.TopStart)
                                            .offset(x = (w - cardW) / 2f, y = (h - cardH) / 2f) // tengah canvas, sama seperti XML (540,960)
                                            .drawBackdrop(
                                                backdrop = backdrop,
                                                shape = { RoundedRectangle(cardRadius) },
                                                effects = {
                                                    val minDimension = size.minDimension
                                                    // urutan persis seperti catalog asli: warna -> blur -> lens
                                                    if (preset.brightness == null) {
                                                        vibrancy()
                                                    } else {
                                                        colorControls(brightness = preset.brightness, saturation = preset.saturation)
                                                    }
                                                    blur(blurDp.dp.toPx())
                                                    lens(
                                                        refractionHeight = refrHeight / 100f * minDimension * 0.5f,
                                                        refractionAmount = refrAmount / 100f * minDimension,
                                                        depthEffect = true,
                                                        chromaticAberration = aberration > 0f
                                                    )
                                                },
                                                highlight = {
                                                    val alpha = (edge / 100f).coerceIn(0f, 1f)
                                                    if (preset.plainHighlight) {
                                                        Highlight.Plain.copy(alpha = alpha)
                                                    } else {
                                                        Highlight(alpha = alpha, style = HighlightStyle.Default(falloff = 2f))
                                                    }
                                                },
                                                layerBlock = {
                                                    translationX = offset.x
                                                    translationY = offset.y
                                                    scaleX = pressScale
                                                    scaleY = pressScale
                                                },
                                                onDrawSurface = {
                                                    // satu-satunya lapisan di atas kaca: warna latar dengan opacity yang bisa diatur
                                                    val a = (bgOpacity / 100f).coerceIn(0f, 1f)
                                                    if (a > 0f) drawRect(bgBase.copy(alpha = a))
                                                }
                                            )
                                            // posisi card dikunci di tengah (tidak bisa digeser)
                                            .size(cardW, cardH)
                                    ) {
                                        // isi card: semua elemen dari playing_controls.svg
                                        // saat menangkap layer kaca untuk export, isi card dikosongkan (controls digambar terpisah per frame)
                                        if (!glassCapture.capturing) {
                                            PlayerControls(ink = preset.titleColor, player = player, modifier = Modifier.fillMaxSize())
                                        }
                                    }
                                }
                            }
                        }
                    }
                    FullscreenToggle(
                        fullscreen = fullscreen,
                        modifier = Modifier.align(Alignment.TopEnd).padding(8f.dp)
                    ) { fullscreen = !fullscreen }
                }
            }

            // ---------- DOCK PENGATURAN (gaya sama dengan dock di chord-finder-island) ----------
            if (!fullscreen) Column(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .widthIn(max = 440f.dp)
                    .fillMaxWidth()
                    .heightIn(max = screenH * 0.45f)
                    .navigationBarsPadding()
                    .imePadding()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 16f.dp, end = 16f.dp, bottom = 16f.dp),
                verticalArrangement = Arrangement.spacedBy(10f.dp)
            ) {
                // jenis card
                DockTabs(dockBackdrop, CardStyle.entries.map { it.short }, style.ordinal) {
                    applyStyle(CardStyle.entries[it])
                }
                ExportButton(dockBackdrop, enabled = player.loaded && !exporting, onClick = startExport)
                // sub kategori "Customized": bisa dibuka / ditutup
                Column {
                    DockHeader(dockBackdrop, "Customized", customOpen) { customOpen = !customOpen }
                    AnimatedVisibility(
                        visible = customOpen,
                        enter = expandVertically(spring(dampingRatio = 0.8f, stiffness = 400f)) + fadeIn(),
                        exit = shrinkVertically(spring(dampingRatio = 0.8f, stiffness = 500f)) + fadeOut()
                    ) {
                        Column(
                            Modifier.padding(top = 10f.dp),
                            verticalArrangement = Arrangement.spacedBy(10f.dp)
                        ) {
                            // upload terpisah: sampul khusus (di card) dan background khusus (di canvas, foto)
                            DockPickRow(
                                dockBackdrop,
                                if (player.cover != null) "Sampul khusus: terpasang" else "Sampul khusus: upload gambar",
                                hasValue = player.cover != null,
                                onPick = { coverPicker.launch(arrayOf("image/*")) },
                                onClear = { player.clearCover() },
                                modifier = Modifier.fillMaxWidth()
                            )
                            DockPickRow(
                                dockBackdrop,
                                when {
                                    bg.loading -> "Background: memuat…"
                                    bg.error != null -> "Background: ${bg.error} (ketuk coba lagi)"
                                    bg.image != null -> "Background: foto khusus"
                                    else -> "Background: upload foto"
                                },
                                hasValue = bg.hasCustom,
                                onPick = { bgPicker.launch(arrayOf("image/*")) },
                                onClear = { bg.clear() },
                                modifier = Modifier.fillMaxWidth()
                            )
                            // teks card: kosong = otomatis (nama file / tag artist)
                            DockTextField(
                                dockBackdrop, player.customTitle, { player.customTitle = it },
                                "Judul (kosong = nama file)", Modifier.fillMaxWidth()
                            )
                            DockTextField(
                                dockBackdrop, player.customArtist, { player.customArtist = it },
                                "Artis (kosong = dari tag file)", Modifier.fillMaxWidth()
                            )
                            // slider: 2 kolom
                            Column(verticalArrangement = Arrangement.spacedBy(10f.dp)) {
                                DockSliderRow(
                                    { m -> DockSlider(dockBackdrop, "Sudut", radiusDp, 0f..144f, "px", m) { radiusDp = it } },
                                    { m -> DockSlider(dockBackdrop, "Blur", blurDp, 0f..32f, "px", m) { blurDp = it } }
                                )
                                DockSlider(
                                    dockBackdrop, "Opacity latar", bgOpacity, 0f..100f, "%",
                                    Modifier.fillMaxWidth()
                                ) { bgOpacity = it }
                                DockSliderRow(
                                    { m -> DockSlider(dockBackdrop, "Tepi cahaya", edge, 0f..100f, "%", m) { edge = it } },
                                    { m -> DockSlider(dockBackdrop, "Aberasi", aberration, 0f..100f, "%", m) { aberration = it } }
                                )
                                DockSliderRow(
                                    { m -> DockSlider(dockBackdrop, "Refraksi tinggi", refrHeight, 0f..100f, "%", m) { refrHeight = it } },
                                    { m -> DockSlider(dockBackdrop, "Refraksi jumlah", refrAmount, 0f..100f, "%", m) { refrAmount = it } }
                                )
                                // opacity foto/latar utama di seluruh layar (bukan di dalam card)
                                DockSlider(
                                    dockBackdrop,
                                    "Opacity foto",
                                    wallpaperOpacity,
                                    0f..100f,
                                    "%",
                                    Modifier.fillMaxWidth()
                                ) { wallpaperOpacity = it }
                                // blur foto background canvas
                                DockSlider(
                                    dockBackdrop,
                                    "Blur background",
                                    bgBlur,
                                    0f..60f,
                                    "px",
                                    Modifier.fillMaxWidth()
                                ) { bgBlur = it }
                            }
                            // aksi: toggle warna latar + reset
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10f.dp)) {
                                Row(
                                    Modifier
                                        .weight(1f)
                                        .height(48f.dp)
                                        .glass(dockBackdrop, 24f.dp)
                                        .clip(RoundedCornerShape(24f.dp))
                                        .clickable(interactionSource = null, indication = null) { bgDark = !bgDark }
                                        .padding(start = 18f.dp, end = 8f.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    BasicText(
                                        if (bgDark) "Warna latar: hitam" else "Warna latar: putih",
                                        style = dockText(14f, FontWeight.SemiBold),
                                        maxLines = 1
                                    )
                                    DockSwitch(bgDark)
                                }
                                Box(
                                    Modifier
                                        .size(48f.dp)
                                        .glass(dockBackdrop, 24f.dp)
                                        .clip(CircleShape)
                                        .clickable(interactionSource = null, indication = null) {
                                            applyStyle(style) // kembali ke angka asli jenis card yang dipilih
                                            offset = Offset.Zero
                                            wallpaperOpacity = 100f
                                            bgBlur = 0f
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Canvas(Modifier.size(20f.dp)) { drawResetIcon() }
                                }
                            }
                        }
                    }
                }
            }
        }

        exportState?.let { st ->
            ExportDialog(
                state = st,
                onCancel = {
                    exportJob?.cancel()
                    exportJob = null
                    exportState = null
                },
                onClose = { exportState = null }
            )
        }
    }
}

// =====================================================================================
// Komponen dock — meniru .glass / #tabs / .sl / #toggle / #reset di chord-finder-island
// =====================================================================================

/** Cari Activity dari Context (bisa terbungkus ContextWrapper). */
private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Tombol bulat di pojok preview: maximize (masuk layar penuh) / minimize (keluar). */
@Composable
private fun FullscreenToggle(fullscreen: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .size(34f.dp)
            .alpha(0.8f)
            .background(Color.Black.copy(alpha = 0.4f), CircleShape)
            .clip(CircleShape)
            .clickable(interactionSource = null, indication = null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(16f.dp)) { drawFullscreenIcon(minimize = fullscreen) }
    }
}

/**
 * Ikon 4 sudut: maximize = sudut menghadap keluar, minimize = sudut menghadap ke dalam.
 * Grid 24 x 24.
 */
private fun DrawScope.drawFullscreenIcon(minimize: Boolean) {
    val k = size.width / 24f
    val corners: List<FloatArray> = if (minimize) {
        listOf(
            floatArrayOf(9f, 3f, 9f, 9f, 3f, 9f),
            floatArrayOf(15f, 3f, 15f, 9f, 21f, 9f),
            floatArrayOf(9f, 21f, 9f, 15f, 3f, 15f),
            floatArrayOf(15f, 21f, 15f, 15f, 21f, 15f)
        )
    } else {
        listOf(
            floatArrayOf(3f, 9f, 3f, 3f, 9f, 3f),
            floatArrayOf(15f, 3f, 21f, 3f, 21f, 9f),
            floatArrayOf(3f, 15f, 3f, 21f, 9f, 21f),
            floatArrayOf(21f, 15f, 21f, 21f, 15f, 21f)
        )
    }
    for (c in corners) {
        val path = Path().apply {
            moveTo(c[0] * k, c[1] * k)
            lineTo(c[2] * k, c[3] * k)
            lineTo(c[4] * k, c[5] * k)
        }
        drawPath(path, Color.White, style = Stroke(width = 2.2f * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** .glass terang: putih bening 58% + blur 16 + garis tepi putih tipis. */
internal fun Modifier.glass(backdrop: Backdrop, radius: Dp): Modifier =
    drawBackdrop(
        backdrop = backdrop,
        shape = { RoundedRectangle(radius) },
        effects = { blur(16f.dp.toPx()) },
        highlight = null,
        shadow = null,
        onDrawSurface = { drawRect(Color.White.copy(alpha = 0.58f)) }
    ).border(1f.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(radius))

/** Header sub kategori: pil kaca dengan judul kiri dan panah putar kanan; klik untuk buka/tutup. */
@Composable
private fun DockHeader(backdrop: Backdrop, label: String, open: Boolean, onToggle: () -> Unit) {
    val rotation by animateFloatAsState(
        targetValue = if (open) 180f else 0f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f)
    )
    Row(
        Modifier
            .fillMaxWidth()
            .height(46f.dp)
            .glass(backdrop, 23f.dp)
            .clip(RoundedCornerShape(23f.dp))
            .clickable(interactionSource = null, indication = null) { onToggle() }
            .padding(start = 18f.dp, end = 16f.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicText(
            label,
            style = dockText(14f, FontWeight.SemiBold),
            maxLines = 1
        )
        Canvas(
            Modifier
                .size(18f.dp)
                .graphicsLayer { rotationZ = rotation }
        ) { drawChevronIcon() }
    }
}

/** Ikon panah (chevron) naik: terbuka = menunjuk bawah. */
private fun DrawScope.drawChevronIcon() {
    val path = Path().apply {
        moveTo(6f, 9f)
        lineTo(12f, 15f)
        lineTo(18f, 9f)
    }
    val k = size.width / 24f
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawPath(path, DockInk, style = Stroke(width = 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** #tabs: pil kaca, indikator #eceff7 meluncur dengan spring ke tab aktif. */
@Composable
private fun DockTabs(backdrop: Backdrop, labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .glass(backdrop, 28f.dp)
            .clip(RoundedCornerShape(28f.dp))
            .padding(5f.dp)
    ) {
        val tabW = maxWidth / labels.size
        val x by animateDpAsState(tabW * selected, spring(dampingRatio = 0.72f, stiffness = 380f))
        Box(
            Modifier
                .offset(x = x)
                .width(tabW)
                .height(42f.dp)
                .background(DockInk, RoundedCornerShape(22f.dp))
        )
        Row(Modifier.fillMaxWidth()) {
            labels.forEachIndexed { i, label ->
                Box(
                    Modifier
                        .weight(1f)
                        .height(42f.dp)
                        .clip(RoundedCornerShape(22f.dp))
                        .clickable(interactionSource = null, indication = null) { onSelect(i) },
                    contentAlignment = Alignment.Center
                ) {
                    BasicText(
                        label,
                        style = dockText(
                            11.5f, FontWeight.Medium,
                            if (i == selected) Color.White else DockInk.copy(alpha = 0.68f)
                        ).copy(textAlign = TextAlign.Center),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
    }
}

/** Baris pilih file: kiri "judul: status", kanan ikon unggah (kosong) atau tombol hapus (sudah terpasang). */
@Composable
private fun DockPickRow(
    backdrop: Backdrop,
    text: String,
    hasValue: Boolean,
    onPick: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier
            .height(46f.dp)
            .glass(backdrop, 23f.dp)
            .clip(RoundedCornerShape(23f.dp))
            .clickable(interactionSource = null, indication = null) { onPick() }
            .padding(start = 18f.dp, end = 8f.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicText(
            text,
            Modifier
                .weight(1f)
                .padding(end = 8f.dp),
            style = dockText(13.5f, FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (hasValue) {
            Box(
                Modifier
                    .size(30f.dp)
                    .clip(CircleShape)
                    .background(DockInk.copy(alpha = 0.1f))
                    .clickable(interactionSource = null, indication = null) { onClear() },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.size(12f.dp)) { drawCloseIcon() }
            }
        } else {
            Box(Modifier.size(30f.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(18f.dp)) { drawUploadIcon() }
            }
        }
    }
}

/** Ikon silang (hapus). Grid 24 x 24. */
private fun DrawScope.drawCloseIcon() {
    val k = size.width / 24f
    val path = Path().apply {
        moveTo(6f, 6f); lineTo(18f, 18f)
        moveTo(18f, 6f); lineTo(6f, 18f)
    }
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawPath(path, DockInk, style = Stroke(width = 2.6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Ikon unggah: panah ke atas di atas garis alas. Grid 24 x 24. */
private fun DrawScope.drawUploadIcon() {
    val k = size.width / 24f
    val path = Path().apply {
        moveTo(12f, 16f); lineTo(12f, 5f)
        moveTo(7f, 9.5f); lineTo(12f, 4.5f); lineTo(17f, 9.5f)
        moveTo(5f, 20f); lineTo(19f, 20f)
    }
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawPath(path, DockInk, style = Stroke(width = 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

private fun formatClock(ms: Long): String {
    val total = (ms / 1000L).toInt()
    return "${total / 60}:${(total % 60).toString().padStart(2, '0')}"
}

@Composable
private fun DockSliderRow(left: @Composable (Modifier) -> Unit, right: @Composable (Modifier) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10f.dp)) {
        left(Modifier.weight(1f))
        right(Modifier.weight(1f))
    }
}

/** .sl: pil kaca 46dp, isi putih 34% dengan garis putih 3dp di ujung, label kiri, nilai tebal kanan. */
@Composable
private fun DockSlider(
    backdrop: Backdrop,
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    unit: String,
    modifier: Modifier = Modifier,
    onChange: (Float) -> Unit
) {
    val currentOnChange by rememberUpdatedState(onChange)
    val span = range.endInclusive - range.start
    val frac = if (span > 0f) ((value - range.start) / span).coerceIn(0f, 1f) else 0f
    val textStyle = dockText(12.5f, FontWeight.Normal)

    Box(
        modifier
            .height(46f.dp)
            .glass(backdrop, 23f.dp)
            .clip(RoundedCornerShape(23f.dp))
            .pointerInput(range) {
                detectTapGestures { currentOnChange(sliderValueAt(it.x, size.width.toFloat(), range)) }
            }
            .pointerInput(range) {
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    currentOnChange(sliderValueAt(change.position.x, size.width.toFloat(), range))
                }
            }
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(frac)
                .background(DockAccent.copy(alpha = 0.22f))
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .width(3f.dp)
                    .fillMaxHeight()
                    .background(DockAccent)
            )
        }
        BasicText(
            label,
            Modifier
                .align(Alignment.CenterStart)
                .padding(start = 15f.dp, end = 48f.dp),
            style = textStyle,
            maxLines = 1
        )
        BasicText(
            "${value.roundToInt()}$unit",
            Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 14f.dp),
            style = textStyle.copy(fontWeight = FontWeight.SemiBold, fontFeatureSettings = "tnum"),
            maxLines = 1
        )
    }
}

private fun sliderValueAt(x: Float, width: Float, range: ClosedFloatingPointRange<Float>): Float {
    val frac = if (width > 0f) (x / width).coerceIn(0f, 1f) else 0f
    return range.start + frac * (range.endInclusive - range.start)
}

@Composable
private fun DockTextField(
    backdrop: Backdrop,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = dockText(13f, FontWeight.Normal),
        cursorBrush = SolidColor(DockAccent),
        modifier = modifier
            .height(42f.dp)
            .glass(backdrop, 21f.dp)
            .clip(RoundedCornerShape(21f.dp)),
        decorationBox = { inner ->
            Box(Modifier.padding(horizontal = 16f.dp), contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) {
                    BasicText(
                        placeholder,
                        style = dockText(13f, FontWeight.Normal, DockInk.copy(alpha = 0.45f))
                    )
                }
                inner()
            }
        }
    )
}

/** .sw: 38 x 24, bulatan 18 yang bergeser 14 dengan spring. */
@Composable
private fun DockSwitch(on: Boolean) {
    val x by animateDpAsState(if (on) 17f.dp else 3f.dp, spring(dampingRatio = 0.6f, stiffness = 400f))
    Box(
        Modifier
            .size(38f.dp, 24f.dp)
            .background(if (on) DockInk else DockInk.copy(alpha = 0.16f), RoundedCornerShape(12f.dp))
    ) {
        Box(
            Modifier
                .offset(x = x, y = 3f.dp)
                .size(18f.dp)
                .background(Color.White, CircleShape)
        )
    }
}

/** Ikon reset: path "M20 12a8 8 0 1 1-2.3-5.6M20 4v4h-4" dari HTML. */
private fun DrawScope.drawResetIcon() {
    val path = Path().apply {
        moveTo(20f, 12f)
        arcTo(Rect(4f, 4f, 20f, 20f), 0f, 315.5f, false)
        moveTo(20f, 4f)
        lineTo(20f, 8f)
        lineTo(16f, 8f)
    }
    val k = size.width / 24f
    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
        drawPath(path, DockInk, style = Stroke(width = 2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
