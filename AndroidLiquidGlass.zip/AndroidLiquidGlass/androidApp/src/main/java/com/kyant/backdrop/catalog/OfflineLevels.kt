package com.kyant.backdrop.catalog

import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * Tinggi batang spectrum untuk export video. Versi deterministik dari [AudioPlayerState.updateLevels]:
 * waktu diberikan dari luar (bukan MediaPlayer / jam layar), jadi hasilnya sama setiap kali dirender.
 *
 * Penghalusan (naik ~15 ms, turun ~80 ms) sama persis dengan di layar. Karena ini keadaan berurutan,
 * [advanceTo] harus dipanggil dengan waktu yang naik terus, dimulai dari frame pertama.
 * Tiap langkah dipecah jadi sub-langkah <= 1/60 detik supaya puncak singkat tidak terlewat di 30 fps
 * (hasil mendekati tampilan 60 fps di layar).
 */
internal class OfflineLevels(private val spectrum: SpectrumData?) {
    private val target = FloatArray(EqBars)
    private val level = FloatArray(EqBars)
    private var lastMs = Float.NaN

    /** Majukan ke [timeMs] (posisi lagu, milidetik) lalu salin level 0..1 ke [out] (panjang >= [EqBars]). */
    fun advanceTo(timeMs: Float, out: FloatArray) {
        if (lastMs.isNaN()) {
            // frame pertama: tidak ada dt sebelumnya, mulai dari batang diam lalu naik dalam ~15 ms
            lastMs = timeMs - 1000f / 60f
        }
        val dtTotal = (timeMs - lastMs) / 1000f
        if (dtTotal > 0f) {
            val n = ceil(dtTotal * 60f - 1e-4f).toInt().coerceAtLeast(1)
            val dt = dtTotal / n
            val up = 1f - exp(-dt / 0.015f)
            val down = 1f - exp(-dt / 0.08f)
            for (k in 1..n) {
                val tMs = lastMs + dt * 1000f * k
                computeTarget(tMs)
                for (i in 0 until EqBars) {
                    val t = target[i]
                    level[i] += (t - level[i]) * (if (t > level[i]) up else down)
                }
            }
            lastMs = timeMs
        }
        for (i in 0 until min(EqBars, out.size)) out[i] = level[i]
    }

    private fun computeTarget(tMs: Float) {
        val sp = spectrum
        if (sp != null) {
            sp.levelsAt(tMs, target)
        } else {
            val sec = tMs / 1000f
            for (i in 0 until EqBars) {
                target[i] = 0.2f + 0.6f * (0.5f + 0.5f * sin(sec * FallbackSpeed[i] + FallbackPhase[i]))
            }
        }
    }
}
