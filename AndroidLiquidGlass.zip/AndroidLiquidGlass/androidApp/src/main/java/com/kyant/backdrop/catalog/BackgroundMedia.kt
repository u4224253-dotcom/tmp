package com.kyant.backdrop.catalog

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.min

/**
 * Background canvas yang berdiri sendiri, TIDAK terkait dengan sampul di card.
 * Bisa berupa foto atau kosong (pakai wallpaper bawaan).
 */
@Stable
internal class BackgroundState(private val context: Context) {
    /** Foto background (kalau yang dipilih foto). */
    var image by mutableStateOf<ImageBitmap?>(null)
        private set

    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    /** Yang digambar di canvas; null = pakai wallpaper bawaan. */
    val display: ImageBitmap?
        get() = image

    /** Sumber warna untuk aurora layar penuh. */
    val paletteSource: ImageBitmap?
        get() = image

    val hasCustom: Boolean
        get() = image != null

    /** Muat foto. Video tidak didukung lagi sebagai background. */
    suspend fun load(uri: Uri) {
        loading = true
        error = null
        try {
            val mime = context.contentResolver.getType(uri).orEmpty()
            if (mime.startsWith("video/")) {
                error = "video tidak didukung, pilih foto"
            } else if (!loadImage(uri)) {
                error = "file tidak bisa dibuka"
            }
        } finally {
            loading = false
        }
    }

    fun clear() {
        image = null
        error = null
    }

    private suspend fun loadImage(uri: Uri): Boolean {
        val bmp = withContext(Dispatchers.IO) { decodeBackground(uri) } ?: return false
        image = bmp.asImageBitmap()
        return true
    }

    /** Decode foto dengan sisi terpendek ~1080 px (sama dengan lebar canvas) + hormati rotasi EXIF. */
    private fun decodeBackground(uri: Uri): Bitmap? {
        return try {
            val cr = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            val minSide = min(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (minSide / (sample * 2) >= 1080) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val deg = readRotation(uri)
            if (deg == 0) {
                raw
            } else {
                val m = Matrix().apply { postRotate(deg.toFloat()) }
                val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                if (rotated !== raw) raw.recycle()
                rotated
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Rotasi EXIF dalam derajat (0/90/180/270). */
    private fun readRotation(uri: Uri): Int {
        if (Build.VERSION.SDK_INT < 24) return 0
        return try {
            context.contentResolver.openInputStream(uri)?.use {
                val exif = android.media.ExifInterface(it)
                when (exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)) {
                    android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } ?: 0
        } catch (e: Exception) {
            0
        }
    }
}

@Composable
internal fun rememberBackgroundState(): BackgroundState {
    val context = LocalContext.current.applicationContext
    val state = remember { BackgroundState(context) }
    DisposableEffect(state) { onDispose { state.clear() } }
    return state
}
