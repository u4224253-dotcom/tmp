package com.kyant.backdrop.catalog

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Sumber frame dari file video background. Frame diambil berdasarkan waktu (bukan diputar),
 * jadi preview dan export memakai jalur yang sama dan hasilnya identik. Video otomatis diulang
 * (loop) kalau waktu yang diminta melewati durasinya. Suaranya tidak dipakai (audio dari lagu).
 *
 * MediaMetadataRetriever tidak thread-safe, jadi semua akses dikunci.
 */
internal class VideoFrameSource private constructor(
    private val retriever: MediaMetadataRetriever,
    val durationMs: Long,
    private val outW: Int, // lebar frame setelah rotasi
    private val outH: Int  // tinggi frame setelah rotasi
) {
    private val lock = Any()
    @Volatile private var closed = false

    /** Frame pada [timeMs] (di-loop ke durasi video), sisi terpanjang paling besar [maxSide] px. */
    fun frameAt(timeMs: Long, maxSide: Int): Bitmap? {
        if (closed) return null
        val t = if (durationMs > 0L) timeMs.mod(durationMs) else 0L
        val scale = min(1f, maxSide.toFloat() / max(outW, outH).toFloat())
        val tw = (outW * scale).roundToInt().coerceAtLeast(2)
        val th = (outH * scale).roundToInt().coerceAtLeast(2)
        return synchronized(lock) {
            if (closed) {
                null
            } else {
                try {
                    grab(t, tw, th) ?: grab(t, tw, th, sync = true)
                } catch (e: Exception) {
                    null
                }
            }
        }
    }

    private fun grab(tMs: Long, tw: Int, th: Int, sync: Boolean = false): Bitmap? {
        val option = if (sync) MediaMetadataRetriever.OPTION_CLOSEST_SYNC else MediaMetadataRetriever.OPTION_CLOSEST
        return if (Build.VERSION.SDK_INT >= 27) {
            retriever.getScaledFrameAtTime(tMs * 1000L, option, tw, th)
        } else {
            val full = retriever.getFrameAtTime(tMs * 1000L, option) ?: return null
            if (full.width <= tw) {
                full
            } else {
                val ratio = full.height.toFloat() / full.width.toFloat()
                val scaled = Bitmap.createScaledBitmap(full, tw, (tw * ratio).roundToInt().coerceAtLeast(2), true)
                if (scaled !== full) full.recycle()
                scaled
            }
        }
    }

    fun close() {
        synchronized(lock) {
            if (!closed) {
                closed = true
                runCatching { retriever.release() }
            }
        }
    }

    companion object {
        /** Buka file video; null kalau bukan video / tidak bisa dibaca. */
        fun open(context: Context, uri: Uri): VideoFrameSource? {
            val r = MediaMetadataRetriever()
            return try {
                r.setDataSource(context, uri)
                val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (dur <= 0L || w <= 0 || h <= 0) {
                    runCatching { r.release() }
                    null
                } else {
                    val swap = rot == 90 || rot == 270
                    VideoFrameSource(r, dur, if (swap) h else w, if (swap) w else h)
                }
            } catch (e: Exception) {
                runCatching { r.release() }
                null
            }
        }
    }
}

/**
 * Background canvas yang berdiri sendiri, TIDAK terkait dengan sampul di card.
 * Bisa berupa foto, video (di-loop, tanpa suara), atau kosong (pakai wallpaper bawaan).
 */
@Stable
internal class BackgroundState(private val context: Context) {
    /** Foto background (kalau yang dipilih foto). */
    var image by mutableStateOf<ImageBitmap?>(null)
        private set

    /** Sumber video background (kalau yang dipilih video). */
    var video by mutableStateOf<VideoFrameSource?>(null)
        private set

    /** Uri video yang sedang dipakai (export membuka sumber sendiri dari uri ini). */
    var videoUri: Uri? = null
        private set

    /** Frame video yang sedang ditampilkan (diisi preview / export). */
    var frame by mutableStateOf<ImageBitmap?>(null)

    var firstFrame by mutableStateOf<ImageBitmap?>(null)
        private set

    /** Dinaikkan setelah export supaya preview mengambil ulang frame pada posisi sekarang. */
    var refreshKey by mutableIntStateOf(0)

    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    /** Yang digambar di canvas; null = pakai wallpaper bawaan. */
    val display: ImageBitmap?
        get() = if (video != null) (frame ?: firstFrame) else image

    /** Sumber warna untuk aurora layar penuh. */
    val paletteSource: ImageBitmap?
        get() = if (video != null) firstFrame else image

    val hasCustom: Boolean
        get() = video != null || image != null

    /** Muat foto atau video (dikenali dari tipe file). */
    suspend fun load(uri: Uri) {
        loading = true
        error = null
        try {
            val mime = context.contentResolver.getType(uri).orEmpty()
            val ok = if (mime.startsWith("video/")) {
                loadVideo(uri)
            } else {
                loadImage(uri) || loadVideo(uri)
            }
            if (!ok) error = "file tidak bisa dibuka"
        } finally {
            loading = false
        }
    }

    fun clear() {
        clearVideo()
        image = null
        error = null
    }

    private fun clearVideo() {
        video?.close()
        video = null
        videoUri = null
        frame = null
        firstFrame = null
    }

    private suspend fun loadImage(uri: Uri): Boolean {
        val bmp = withContext(Dispatchers.IO) { decodeBackground(uri) } ?: return false
        clearVideo()
        image = bmp.asImageBitmap()
        return true
    }

    private suspend fun loadVideo(uri: Uri): Boolean {
        val (src, first) = withContext(Dispatchers.IO) {
            val s = VideoFrameSource.open(context, uri)
            s to s?.frameAt(0L, PreviewMaxSide)
        }
        if (src == null || first == null) {
            src?.close()
            return false
        }
        clearVideo()
        image = null
        video = src
        videoUri = uri
        firstFrame = first.asImageBitmap()
        frame = firstFrame
        return true
    }

    /** Decode foto dengan sisi terpendek ~1080 px (sama dengan lebar canvas) + hormati rotasi EXIF. */
    private fun decodeBackground(uri: Uri): Bitmap? {
        return try {
            val cr = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            val minSide = min(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (minSide / (sample * 2) >= 1080) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val deg = readRotation(uri)
            if (deg == 0) {
                raw
            } else {
                val m = Matrix().apply { postRotate(deg.toFloat()) }
                val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                if (rotated !== raw) raw.recycle()
                rotated
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Rotasi EXIF dalam derajat (0/90/180/270). */
    private fun readRotation(uri: Uri): Int {
        if (Build.VERSION.SDK_INT < 24) return 0
        return try {
            context.contentResolver.openInputStream(uri)?.use {
                val exif = android.media.ExifInterface(it)
                when (exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)) {
                    android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } ?: 0
        } catch (e: Exception) {
            0
        }
    }

    companion object {
        /** Sisi terpanjang frame video untuk preview di layar (export memakai 1920). */
        const val PreviewMaxSide = 960
    }
}

@Composable
internal fun rememberBackgroundState(): BackgroundState {
    val context = LocalContext.current.applicationContext
    val state = remember { BackgroundState(context) }
    DisposableEffect(state) { onDispose { state.clear() } }
    return state
}
