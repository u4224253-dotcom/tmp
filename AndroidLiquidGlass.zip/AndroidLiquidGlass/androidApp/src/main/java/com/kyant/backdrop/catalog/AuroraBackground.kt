package com.kyant.backdrop.catalog

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/** Dipakai hanya kalau gambar nyaris hitam-putih / gagal dibaca. */
internal val FallbackAurora = listOf(Color(0xFF7B4BFF), Color(0xFF2D5BFF), Color(0xFF19B8FF))

private val AuroraBlack = Color(0xFF05060A)

/**
 * 3 warna dominan gambar canvas, urut dari yang paling banyak.
 *
 * "Dominan" = menutupi PALING BANYAK piksel dari SELURUH gambar, termasuk area gelap dan abu-abu.
 * Piksel gelap / abu-abu TIDAK dibuang: kalau background-nya 75% hampir hitam, aurora memang harus
 * gelap, supaya seimbang dengan background (dulu piksel gelap dibuang, jadi segelintir piksel merah
 * kecil bisa menang dan aurora jadi merah menyala padahal gambarnya gelap).
 *
 * Caranya: gambar dikecilkan bertahap ke 96x96, lalu klaster kepadatan greedy: cari warna paling
 * ramai (histogram 4 bit per kanal), geser pusatnya ke rata-rata piksel di sekitarnya (radius 64
 * di ruang RGB), ambil semua piksel di radius itu sebagai satu klaster, buang, ulangi. Klaster di
 * bawah 4% piksel diabaikan. Hue dan terang-gelap warna asli dipertahankan; hanya sedikit dinaikkan
 * (V = 0,15 + 0,85 x V) supaya warna yang nyaris hitam tetap menghasilkan cahaya tipis.
 */
internal fun extractAuroraPalette(src: ImageBitmap?): List<Color> {
    if (src == null) return FallbackAurora
    return runCatching {
        var bmp = src.asAndroidBitmap()
        if (bmp.config == Bitmap.Config.HARDWARE) bmp = bmp.copy(Bitmap.Config.ARGB_8888, false)
        val n = 96
        // kecilkan bertahap (tiap langkah paling banyak setengah) supaya hasilnya rata-rata area yang adil
        var small = bmp
        while (small.width / 2 >= n && small.height / 2 >= n) {
            small = Bitmap.createScaledBitmap(small, small.width / 2, small.height / 2, true)
        }
        small = Bitmap.createScaledBitmap(small, n, n, true)
        val px = IntArray(n * n)
        small.getPixels(px, 0, n, 0, 0, n, n)

        val rs = FloatArray(px.size); val gs = FloatArray(px.size); val bs = FloatArray(px.size)
        var m = 0
        for (p in px) {
            if ((p ushr 24) < 128) continue                 // transparan
            rs[m] = ((p shr 16) and 0xFF).toFloat()
            gs[m] = ((p shr 8) and 0xFF).toFloat()
            bs[m] = (p and 0xFF).toFloat()
            m++
        }
        if (m < 130) return@runCatching FallbackAurora

        fun key(i: Int) = ((rs[i].toInt() shr 4) shl 8) or ((gs[i].toInt() shr 4) shl 4) or (bs[i].toInt() shr 4)
        val alive = BooleanArray(m) { true }
        val radius2 = 64f * 64f
        val centers = ArrayList<FloatArray>()

        for (round in 0 until 3) {
            // 1) warna paling ramai di antara piksel yang tersisa
            val hist = IntArray(4096)
            for (i in 0 until m) if (alive[i]) hist[key(i)]++
            var seed = -1; var seedCount = 0
            for (k in 0 until 4096) if (hist[k] > seedCount) { seedCount = hist[k]; seed = k }
            if (seed < 0) break
            var cr = 0f; var cg = 0f; var cb = 0f
            for (i in 0 until m) if (alive[i] && key(i) == seed) { cr += rs[i]; cg += gs[i]; cb += bs[i] }
            cr /= seedCount; cg /= seedCount; cb /= seedCount

            // 2) geser pusat ke rata-rata piksel di radius 64 (mean shift singkat)
            repeat(4) {
                var sr = 0f; var sg = 0f; var sb = 0f; var c = 0
                for (i in 0 until m) if (alive[i]) {
                    val dr = rs[i] - cr; val dg = gs[i] - cg; val db = bs[i] - cb
                    if (dr * dr + dg * dg + db * db <= radius2) { sr += rs[i]; sg += gs[i]; sb += bs[i]; c++ }
                }
                if (c > 0) { cr = sr / c; cg = sg / c; cb = sb / c }
            }

            // 3) ambil semua piksel di radius itu sebagai satu klaster, lalu buang
            var size = 0
            for (i in 0 until m) if (alive[i]) {
                val dr = rs[i] - cr; val dg = gs[i] - cg; val db = bs[i] - cb
                if (dr * dr + dg * dg + db * db <= radius2) { alive[i] = false; size++ }
            }
            if (size < m * 0.04f) break                     // terlalu sedikit untuk jadi warna dominan
            centers += floatArrayOf(cr, cg, cb)
        }
        if (centers.isEmpty()) return@runCatching FallbackAurora

        val hsv = FloatArray(3)
        val out = ArrayList<Color>()
        for (c in centers) {
            android.graphics.Color.RGBToHSV(c[0].toInt(), c[1].toInt(), c[2].toInt(), hsv)
            out += Color(
                android.graphics.Color.HSVToColor(
                    floatArrayOf(hsv[0], (hsv[1] * 1.1f).coerceAtMost(0.95f), (0.15f + hsv[2] * 0.85f).coerceIn(0f, 1f))
                )
            )
        }
        // gambar hampir satu warna: lengkapi dengan variasi hue + terang-gelap tetangga
        var shift = 24f
        var dv = 0.12f
        while (out.size < 3) {
            android.graphics.Color.colorToHSV(out.first().toArgb(), hsv)
            out += Color(
                android.graphics.Color.HSVToColor(
                    floatArrayOf((hsv[0] + shift + 360f) % 360f, hsv[1], (hsv[2] + dv).coerceIn(0.1f, 1f))
                )
            )
            shift = -shift - 8f
            dv = -dv
        }
        out
    }.getOrDefault(FallbackAurora)
}

/** Jam + energi tiga pita (bass / mid / treble) yang sudah dihaluskan; dibaca tiap frame saat menggambar. */
private class AuroraClock {
    var t = 0f
    val e = FloatArray(3)

    fun step(bands: FloatArray, dt: Float) {
        for (k in 0 until 3) {
            val raw = (bands[2 * k] + bands[2 * k + 1]) * 0.5f
            val shaped = raw.coerceIn(0f, 1f).pow(1.5f)
            val rate = 1f - exp(-dt / (if (shaped > e[k]) 0.05f else 0.30f))
            e[k] += (shaped - e[k]) * rate
        }
        // tempo gerak ikut keras lagu: sepi = melayang pelan, ramai = lebih cepat
        t += dt * (0.40f + 0.8f * max(e[0], max(e[1], e[2])))
    }
}

/**
 * Aurora "Kabut Warna" dari 3 warna sampul. Dasar gelap menutup penuh seluruh layar, di atasnya 6 gumpalan
 * cahaya besar melayang di SEMUA bagian layar (bukan hanya tepi atas/bawah), dicampur dengan mode Screen
 * supaya bagian yang bertumpuk menyala lembut, tidak jadi putih. Warna 1 mengikuti bass, 2 mid, 3 treble.
 */
@Composable
fun AuroraBackground(c0: Color, c1: Color, c2: Color, player: AudioPlayerState, modifier: Modifier = Modifier) {
    val clock = remember { AuroraClock() }
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
                last = now
                clock.step(player.bands, dt)
                tick = now
            }
        }
    }
    val colors = listOf(c0, c1, c2)
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val redraw = tick // baca state -> gambar ulang tiap frame
        val w = size.width
        val h = size.height
        val t = clock.t
        val e = clock.e

        // dasar gelap, sedikit bernuansa warna dominan
        drawRect(
            Brush.verticalGradient(
                listOf(lerp(AuroraBlack, c0, 0.10f), AuroraBlack, lerp(AuroraBlack, c1, 0.10f))
            )
        )

        for (i in 0 until 6) {
            val k = i % 3
            val c = Offset(
                w * (0.5f + 0.42f * sin(t * 0.21f + i * 1.7f)),
                h * (0.5f + 0.42f * sin(t * 0.17f + i * 2.3f + 1f))
            )
            val r = w * (0.62f + 0.25f * e[k])
            val a = (0.55f + 0.35f * e[k]).coerceAtMost(0.95f)
            val col = colors[k]
            withTransform({ scale(1f, 1.3f, pivot = c) }) {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(col.copy(alpha = a), col.copy(alpha = a * 0.45f), Color.Transparent),
                        center = c, radius = r
                    ),
                    radius = r, center = c, blendMode = BlendMode.Screen
                )
            }
        }
    }
}
