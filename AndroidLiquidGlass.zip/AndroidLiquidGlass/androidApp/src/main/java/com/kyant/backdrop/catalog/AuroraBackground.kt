package com.kyant.backdrop.catalog

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/** Dipakai kalau sampul nyaris abu-abu / tidak ada: biru-ungu-cyan dari wallpaper HTML. */
internal val FallbackAurora = listOf(Color(0xFF7B4BFF), Color(0xFF2D5BFF), Color(0xFF19B8FF))

/**
 * Ambil 3 warna dominan dari gambar. Piksel digolongkan per hue (12 kelompok), dibobot
 * saturasi x kecerahan supaya warna yang benar-benar mencolok menang atas area gelap/abu.
 * Hue yang terlalu mirip digabung; kalau cuma ada 1-2 hue (sampul monokrom) sisanya dibuat
 * dari hue tetangga supaya aurora tetap punya 3 warna yang selaras.
 * Warna hasil dinaikkan saturasi + kecerahannya agar menyala seperti cahaya.
 */
internal fun extractAuroraPalette(src: ImageBitmap?): List<Color> {
    if (src == null) return FallbackAurora
    return runCatching {
        var bmp = src.asAndroidBitmap()
        if (bmp.config == Bitmap.Config.HARDWARE) bmp = bmp.copy(Bitmap.Config.ARGB_8888, false)
        val n = 48
        val small = Bitmap.createScaledBitmap(bmp, n, n, true)
        val px = IntArray(n * n)
        small.getPixels(px, 0, n, 0, 0, n, n)

        val bins = 12
        val wSum = DoubleArray(bins)
        val sSum = DoubleArray(bins)
        val vSum = DoubleArray(bins)
        val hSum = DoubleArray(bins)
        val hsv = FloatArray(3)
        var total = 0.0
        for (p in px) {
            android.graphics.Color.colorToHSV(p, hsv)
            val s = hsv[1]
            val v = hsv[2]
            if (v < 0.14f || s < 0.18f) continue
            val w = (s * v).toDouble()
            val hs = (hsv[0] + 15f) % 360f // geser 15 derajat supaya merah tidak terbelah di batas bin
            val b = (hs / 30f).toInt().coerceIn(0, bins - 1)
            wSum[b] += w; sSum[b] += w * s; vSum[b] += w * v; hSum[b] += w * hs
            total += w
        }
        if (total < 25.0) return@runCatching FallbackAurora

        class Pick(val hue: Float, val s: Float, val v: Float)
        fun hueDist(a: Float, b: Float): Float {
            val d = abs(a - b) % 360f
            return if (d > 180f) 360f - d else d
        }
        val picks = ArrayList<Pick>()
        for (b in (0 until bins).sortedByDescending { wSum[it] }) {
            if (wSum[b] <= 0.0 || picks.size >= 3) break
            val hue = ((hSum[b] / wSum[b]).toFloat() - 15f + 360f) % 360f
            if (picks.none { hueDist(it.hue, hue) < 35f }) {
                picks += Pick(hue, (sSum[b] / wSum[b]).toFloat(), (vSum[b] / wSum[b]).toFloat())
            }
        }
        val first = picks.first()
        val offsets = floatArrayOf(28f, -28f, 56f)
        var k = 0
        while (picks.size < 3) {
            picks += Pick((first.hue + offsets[k++ % 3] + 360f) % 360f, first.s, first.v)
        }
        picks.map {
            Color(
                android.graphics.Color.HSVToColor(
                    floatArrayOf(it.hue, (it.s * 1.05f).coerceIn(0.5f, 0.95f), (it.v + 0.3f).coerceIn(0.8f, 1f))
                )
            )
        }
    }.getOrDefault(FallbackAurora)
}

/** Jam + energi pita (bass/mid/treble) yang sudah dihaluskan; dibaca tiap frame saat menggambar. */
private class AuroraClock {
    var t = 0f
    val e = FloatArray(3)

    fun step(bands: FloatArray, dt: Float) {
        for (k in 0 until 3) {
            val raw = (bands[2 * k] + bands[2 * k + 1]) * 0.5f
            val shaped = raw.coerceIn(0f, 1f).pow(1.5f) // perkuat kontras dinamika
            val rate = 1f - exp(-dt / (if (shaped > e[k]) 0.05f else 0.30f))
            e[k] += (shaped - e[k]) * rate
        }
        // tempo gerak ikut keras lagu: sepi = melayang pelan, ramai = lebih cepat
        t += dt * (0.45f + 0.9f * max(e[0], max(e[1], e[2])))
    }
}

/**
 * Aurora dari 3 warna sampul. Warna 0 mengikuti bass, 1 mid, 2 treble: tiap pita frekuensi
 * menebalkan, mencerahkan, dan melebarkan gelombang tirai warnanya. Tanpa audio tetap bergerak pelan.
 */
@Composable
fun AuroraBackground(c0: Color, c1: Color, c2: Color, player: AudioPlayerState, modifier: Modifier = Modifier) {
    val clock = remember { AuroraClock() }
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
                last = now
                clock.step(player.bands, dt)
                tick = now
            }
        }
    }
    val colors = listOf(c0, c1, c2)
    Canvas(modifier.blur(18.dp, BlurredEdgeTreatment.Unbounded)) {
        @Suppress("UNUSED_VARIABLE") val redraw = tick // baca state -> gambar ulang tiap frame
        val w = size.width
        val h = size.height
        val t = clock.t
        val e = clock.e

        // dasar: versi gelap pekat dari warna sampul supaya menyatu dengan foto di tengah
        fun deep(c: Color) = lerp(c, Color.Black, 0.80f)
        drawRect(Brush.verticalGradient(listOf(deep(c0), deep(c2), deep(c1))))

        // cahaya sudut, berdenyut mengikuti bass / mid
        fun glow(c: Color, center: Offset, r: Float) = drawCircle(
            brush = Brush.radialGradient(listOf(c, Color.Transparent), center = center, radius = r),
            radius = r, center = center, blendMode = BlendMode.Plus
        )
        glow(c0.copy(alpha = 0.22f + 0.30f * e[0]), Offset(w * 0.15f, h * 0.06f), w * 0.85f)
        glow(c1.copy(alpha = 0.22f + 0.30f * e[1]), Offset(w * 0.85f, h * 0.96f), w * 0.85f)
        glow(c2.copy(alpha = 0.10f + 0.25f * e[2]), Offset(w * 0.50f, h * 0.50f), w * 1.0f)

        // tirai aurora: (indeks warna, posisi y relatif) -> 2 di atas, 2 di bawah, tempat yang terlihat di luar canvas 9:16
        val bandDefs = arrayOf(
            0 to 0.07f, 1 to 0.16f,
            2 to 0.93f, 0 to 0.84f
        )
        val cols = 72
        bandDefs.forEachIndexed { bi, (ci, baseY) ->
            val idx = ci
            val col = colors[idx]
            val en = e[idx]
            val ph = bi * 1.9f
            val amp = h * (0.012f + 0.035f * en)
            val colW = w / cols * 1.7f
            for (i in 0..cols) {
                val xf = i / cols.toFloat()
                val ray = (0.5f + 0.5f * sin(xf * 19f + t * 1.1f + ph)) * (0.55f + 0.45f * sin(xf * 6f - t * 0.6f + ph * 1.7f))
                val a = ((0.25f + 0.75f * ray) * (0.45f + 0.9f * en)).coerceIn(0f, 1f) * 0.85f
                val yc = baseY * h + amp * sin(xf * 6.5f + t * 0.8f + ph) + amp * 0.6f * sin(xf * 13f - t * 1.2f + ph)
                val thick = h * (0.075f + 0.06f * en) * (0.7f + 0.5f * ray)
                val x = xf * w
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.55f to col.copy(alpha = a),
                        1f to Color.Transparent,
                        startY = yc - thick, endY = yc + thick
                    ),
                    topLeft = Offset(x - colW / 2f, yc - thick),
                    size = Size(colW, thick * 2f),
                    blendMode = BlendMode.Plus
                )
            }
        }
    }
}
