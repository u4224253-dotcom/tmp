package com.kyant.backdrop.catalog

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/** Dipakai hanya kalau gambar nyaris hitam-putih / gagal dibaca. */
internal val FallbackAurora = listOf(Color(0xFF7B4BFF), Color(0xFF2D5BFF), Color(0xFF19B8FF))

private val AuroraBlack = Color(0xFF05060A)

/**
 * 3 warna dominan gambar canvas, urut dari yang paling banyak.
 *
 * "Dominan" = warna yang menutupi PALING BANYAK piksel, bukan yang paling terang atau paling jenuh.
 * Gambar dikecilkan bertahap (rata-rata area, bukan loncat piksel) ke 96x96, lalu tiap piksel
 * berwarna dimasukkan ke histogram hue 24 keranjang (15 derajat). Setiap piksel bobotnya sama (1),
 * kecerahan tidak ikut menentukan. Piksel abu-abu / nyaris hitam dibuang karena tidak punya hue.
 * Keranjang digabung dengan tetangganya, lalu diambil 3 puncak terbesar yang hue-nya berjauhan
 * (minimal 45 derajat) dan yang menutupi minimal 6% piksel berwarna; warna puncak = rata-rata piksel
 * di dalamnya. Hue asli dipertahankan; hanya kecerahan dinaikkan secukupnya supaya terbaca di atas
 * dasar gelap aurora.
 */
internal fun extractAuroraPalette(src: ImageBitmap?): List<Color> {
    if (src == null) return FallbackAurora
    return runCatching {
        var bmp = src.asAndroidBitmap()
        if (bmp.config == Bitmap.Config.HARDWARE) bmp = bmp.copy(Bitmap.Config.ARGB_8888, false)
        val n = 96
        // kecilkan bertahap (tiap langkah paling banyak setengah) supaya hasilnya rata-rata area yang adil
        var small = bmp
        while (small.width / 2 >= n && small.height / 2 >= n) {
            small = Bitmap.createScaledBitmap(small, small.width / 2, small.height / 2, true)
        }
        small = Bitmap.createScaledBitmap(small, n, n, true)
        val px = IntArray(n * n)
        small.getPixels(px, 0, n, 0, 0, n, n)

        val bins = 24
        val cnt = FloatArray(bins)
        val sr = FloatArray(bins); val sg = FloatArray(bins); val sb = FloatArray(bins)
        val hsv = FloatArray(3)
        var m = 0
        for (p in px) {
            if ((p ushr 24) < 128) continue                 // transparan
            android.graphics.Color.colorToHSV(p, hsv)
            if (hsv[1] < 0.15f || hsv[2] < 0.12f) continue  // abu-abu / nyaris hitam: tidak punya hue
            val b = (hsv[0] / 360f * bins).toInt().coerceIn(0, bins - 1)
            cnt[b] += 1f
            sr[b] += ((p shr 16) and 0xFF).toFloat()
            sg[b] += ((p shr 8) and 0xFF).toFloat()
            sb[b] += (p and 0xFF).toFloat()
            m++
        }
        if (m < 130) return@runCatching FallbackAurora

        // gabung dengan tetangga supaya satu warna yang jatuh di perbatasan keranjang tidak terbelah
        val score = FloatArray(bins) { cnt[it] + 0.5f * (cnt[(it + bins - 1) % bins] + cnt[(it + 1) % bins]) }
        fun binDist(a: Int, b: Int): Int { val d = kotlin.math.abs(a - b); return minOf(d, bins - d) }

        val peaks = ArrayList<Int>()
        for (b in (0 until bins).sortedByDescending { score[it] }) {
            if (peaks.size >= 3) break
            if (score[b] < m * 0.06f) break                 // terlalu sedikit untuk jadi warna dominan
            if (peaks.all { binDist(it, b) >= 3 }) peaks += b
        }

        val out = ArrayList<Color>()
        for (b in peaks) {
            var c = 0f; var r = 0f; var g = 0f; var bl = 0f
            for (o in -1..1) {
                val i = (b + o + bins) % bins
                c += cnt[i]; r += sr[i]; g += sg[i]; bl += sb[i]
            }
            if (c <= 0f) continue
            android.graphics.Color.RGBToHSV((r / c).toInt(), (g / c).toInt(), (bl / c).toInt(), hsv)
            out += Color(
                android.graphics.Color.HSVToColor(
                    floatArrayOf(hsv[0], (hsv[1] * 1.15f + 0.05f).coerceIn(0.25f, 0.95f), (0.45f + hsv[2] * 0.55f).coerceIn(0.6f, 1f))
                )
            )
        }
        if (out.isEmpty()) return@runCatching FallbackAurora
        // gambar hampir satu warna: lengkapi dengan variasi hue tetangga
        var shift = 24f
        while (out.size < 3) {
            val b = out.first()
            android.graphics.Color.colorToHSV(b.toArgb(), hsv)
            out += Color(android.graphics.Color.HSVToColor(floatArrayOf((hsv[0] + shift + 360f) % 360f, hsv[1], hsv[2])))
            shift = -shift - 8f
        }
        out
    }.getOrDefault(FallbackAurora)
}

/** Jam + energi tiga pita (bass / mid / treble) yang sudah dihaluskan; dibaca tiap frame saat menggambar. */
private class AuroraClock {
    var t = 0f
    val e = FloatArray(3)

    fun step(bands: FloatArray, dt: Float) {
        for (k in 0 until 3) {
            val raw = (bands[2 * k] + bands[2 * k + 1]) * 0.5f
            val shaped = raw.coerceIn(0f, 1f).pow(1.5f)
            val rate = 1f - exp(-dt / (if (shaped > e[k]) 0.05f else 0.30f))
            e[k] += (shaped - e[k]) * rate
        }
        // tempo gerak ikut keras lagu: sepi = melayang pelan, ramai = lebih cepat
        t += dt * (0.40f + 0.8f * max(e[0], max(e[1], e[2])))
    }
}

/**
 * Aurora "Kabut Warna" dari 3 warna sampul. Dasar gelap menutup penuh seluruh layar, di atasnya 6 gumpalan
 * cahaya besar melayang di SEMUA bagian layar (bukan hanya tepi atas/bawah), dicampur dengan mode Screen
 * supaya bagian yang bertumpuk menyala lembut, tidak jadi putih. Warna 1 mengikuti bass, 2 mid, 3 treble.
 */
@Composable
fun AuroraBackground(c0: Color, c1: Color, c2: Color, player: AudioPlayerState, modifier: Modifier = Modifier) {
    val clock = remember { AuroraClock() }
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
                last = now
                clock.step(player.bands, dt)
                tick = now
            }
        }
    }
    val colors = listOf(c0, c1, c2)
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val redraw = tick // baca state -> gambar ulang tiap frame
        val w = size.width
        val h = size.height
        val t = clock.t
        val e = clock.e

        // dasar gelap, sedikit bernuansa warna dominan
        drawRect(
            Brush.verticalGradient(
                listOf(lerp(AuroraBlack, c0, 0.10f), AuroraBlack, lerp(AuroraBlack, c1, 0.10f))
            )
        )

        for (i in 0 until 6) {
            val k = i % 3
            val c = Offset(
                w * (0.5f + 0.42f * sin(t * 0.21f + i * 1.7f)),
                h * (0.5f + 0.42f * sin(t * 0.17f + i * 2.3f + 1f))
            )
            val r = w * (0.62f + 0.25f * e[k])
            val a = (0.55f + 0.35f * e[k]).coerceAtMost(0.95f)
            val col = colors[k]
            withTransform({ scale(1f, 1.3f, pivot = c) }) {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(col.copy(alpha = a), col.copy(alpha = a * 0.45f), Color.Transparent),
                        center = c, radius = r
                    ),
                    radius = r, center = c, blendMode = BlendMode.Screen
                )
            }
        }
    }
}
