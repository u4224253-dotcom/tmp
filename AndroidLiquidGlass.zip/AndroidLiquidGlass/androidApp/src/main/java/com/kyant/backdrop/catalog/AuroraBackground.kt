package com.kyant.backdrop.catalog

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Dipakai hanya kalau gambar nyaris hitam-putih / gagal dibaca. */
internal val FallbackAurora = listOf(Color(0xFF7B4BFF), Color(0xFF2D5BFF), Color(0xFF19B8FF))

private val AuroraBlack = Color(0xFF05060A)

/**
 * 3 warna dominan sampul, urut dari yang paling dominan.
 *
 * k-means (k = 6) pada piksel yang sudah dikecilkan ke 64x64. Piksel hampir hitam dan
 * hampir putih dibuang supaya yang menang adalah warna gambar, bukan bayangan atau highlight.
 * Cluster diurutkan menurut jumlah piksel (sedikit diberi bonus kalau berwarna), lalu diambil
 * 3 teratas yang jaraknya cukup berjauhan. Hue dan saturasi asli dipertahankan; hanya
 * kecerahannya dinaikkan secukupnya supaya terbaca di atas dasar gelap.
 */
internal fun extractAuroraPalette(src: ImageBitmap?): List<Color> {
    if (src == null) return FallbackAurora
    return runCatching {
        var bmp = src.asAndroidBitmap()
        if (bmp.config == Bitmap.Config.HARDWARE) bmp = bmp.copy(Bitmap.Config.ARGB_8888, false)
        val n = 64
        val small = Bitmap.createScaledBitmap(bmp, n, n, true)
        val px = IntArray(n * n)
        small.getPixels(px, 0, n, 0, 0, n, n)

        val hsv = FloatArray(3)
        val rs = FloatArray(px.size)
        val gs = FloatArray(px.size)
        val bs = FloatArray(px.size)
        var m = 0
        for (p in px) {
            android.graphics.Color.colorToHSV(p, hsv)
            if (hsv[2] < 0.20f) continue                    // terlalu gelap
            if (hsv[1] < 0.07f && hsv[2] > 0.85f) continue  // putih / highlight
            rs[m] = ((p shr 16) and 0xFF).toFloat()
            gs[m] = ((p shr 8) and 0xFF).toFloat()
            bs[m] = (p and 0xFF).toFloat()
            m++
        }
        if (m < 60) return@runCatching FallbackAurora

        val k = 6
        val cr = FloatArray(k); val cg = FloatArray(k); val cb = FloatArray(k)
        val cnt = IntArray(k)
        fun d2(i: Int, c: Int): Float {
            val dr = rs[i] - cr[c]; val dg = gs[i] - cg[c]; val db = bs[i] - cb[c]
            return dr * dr + dg * dg + db * db
        }
        // inisialisasi farthest-point (deterministik)
        cr[0] = rs[0]; cg[0] = gs[0]; cb[0] = bs[0]
        for (c in 1 until k) {
            var best = 0; var bestD = -1f
            for (i in 0 until m) {
                var dmin = Float.MAX_VALUE
                for (j in 0 until c) dmin = minOf(dmin, d2(i, j))
                if (dmin > bestD) { bestD = dmin; best = i }
            }
            cr[c] = rs[best]; cg[c] = gs[best]; cb[c] = bs[best]
        }
        val asg = IntArray(m)
        repeat(10) {
            for (i in 0 until m) {
                var bc = 0; var bd = Float.MAX_VALUE
                for (c in 0 until k) { val d = d2(i, c); if (d < bd) { bd = d; bc = c } }
                asg[i] = bc
            }
            val sr = FloatArray(k); val sg = FloatArray(k); val sb = FloatArray(k)
            cnt.fill(0)
            for (i in 0 until m) { val c = asg[i]; sr[c] += rs[i]; sg[c] += gs[i]; sb[c] += bs[i]; cnt[c]++ }
            for (c in 0 until k) if (cnt[c] > 0) { cr[c] = sr[c] / cnt[c]; cg[c] = sg[c] / cnt[c]; cb[c] = sb[c] / cnt[c] }
        }

        fun sat(c: Int): Float {
            android.graphics.Color.RGBToHSV(cr[c].toInt(), cg[c].toInt(), cb[c].toInt(), hsv)
            return hsv[1]
        }
        val order = (0 until k).filter { cnt[it] > 0 }.sortedByDescending { cnt[it] * (0.5f + sat(it)) }
        fun far(a: Int, b: Int): Boolean {
            val dr = cr[a] - cr[b]; val dg = cg[a] - cg[b]; val db = cb[a] - cb[b]
            return sqrt(dr * dr + dg * dg + db * db) >= 80f
        }
        val chosen = ArrayList<Int>()
        for (c in order) if (chosen.size < 3 && chosen.all { far(it, c) }) chosen += c
        for (c in order) if (chosen.size < 3 && c !in chosen) chosen += c

        val out = ArrayList<Color>()
        for (c in chosen) {
            android.graphics.Color.RGBToHSV(cr[c].toInt(), cg[c].toInt(), cb[c].toInt(), hsv)
            out += Color(
                android.graphics.Color.HSVToColor(
                    floatArrayOf(hsv[0], (hsv[1] * 1.15f + 0.05f).coerceIn(0.25f, 0.95f), (0.45f + hsv[2] * 0.55f).coerceIn(0.6f, 1f))
                )
            )
        }
        // sampul hampir satu warna: lengkapi dengan variasi hue tetangga
        var shift = 24f
        while (out.size < 3) {
            val b = out.first()
            android.graphics.Color.colorToHSV(b.toArgb(), hsv)
            out += Color(android.graphics.Color.HSVToColor(floatArrayOf((hsv[0] + shift + 360f) % 360f, hsv[1], hsv[2])))
            shift = -shift - 8f
        }
        out
    }.getOrDefault(FallbackAurora)
}

/** Jam + energi tiga pita (bass / mid / treble) yang sudah dihaluskan; dibaca tiap frame saat menggambar. */
private class AuroraClock {
    var t = 0f
    val e = FloatArray(3)

    fun step(bands: FloatArray, dt: Float) {
        for (k in 0 until 3) {
            val raw = (bands[2 * k] + bands[2 * k + 1]) * 0.5f
            val shaped = raw.coerceIn(0f, 1f).pow(1.5f)
            val rate = 1f - exp(-dt / (if (shaped > e[k]) 0.05f else 0.30f))
            e[k] += (shaped - e[k]) * rate
        }
        // tempo gerak ikut keras lagu: sepi = melayang pelan, ramai = lebih cepat
        t += dt * (0.40f + 0.8f * max(e[0], max(e[1], e[2])))
    }
}

/**
 * Aurora "Kabut Warna" dari 3 warna sampul. Dasar gelap menutup penuh seluruh layar, di atasnya 6 gumpalan
 * cahaya besar melayang di SEMUA bagian layar (bukan hanya tepi atas/bawah), dicampur dengan mode Screen
 * supaya bagian yang bertumpuk menyala lembut, tidak jadi putih. Warna 1 mengikuti bass, 2 mid, 3 treble.
 */
@Composable
fun AuroraBackground(c0: Color, c1: Color, c2: Color, player: AudioPlayerState, modifier: Modifier = Modifier) {
    val clock = remember { AuroraClock() }
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
                last = now
                clock.step(player.bands, dt)
                tick = now
            }
        }
    }
    val colors = listOf(c0, c1, c2)
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val redraw = tick // baca state -> gambar ulang tiap frame
        val w = size.width
        val h = size.height
        val t = clock.t
        val e = clock.e

        // dasar gelap, sedikit bernuansa warna dominan
        drawRect(
            Brush.verticalGradient(
                listOf(lerp(AuroraBlack, c0, 0.10f), AuroraBlack, lerp(AuroraBlack, c1, 0.10f))
            )
        )

        for (i in 0 until 6) {
            val k = i % 3
            val c = Offset(
                w * (0.5f + 0.42f * sin(t * 0.21f + i * 1.7f)),
                h * (0.5f + 0.42f * sin(t * 0.17f + i * 2.3f + 1f))
            )
            val r = w * (0.62f + 0.25f * e[k])
            val a = (0.55f + 0.35f * e[k]).coerceAtMost(0.95f)
            val col = colors[k]
            withTransform({ scale(1f, 1.3f, pivot = c) }) {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(col.copy(alpha = a), col.copy(alpha = a * 0.45f), Color.Transparent),
                        center = c, radius = r
                    ),
                    radius = r, center = c, blendMode = BlendMode.Screen
                )
            }
        }
    }
}
