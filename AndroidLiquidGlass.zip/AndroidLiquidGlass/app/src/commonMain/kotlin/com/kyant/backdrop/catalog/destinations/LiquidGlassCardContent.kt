package com.kyant.backdrop.catalog.destinations

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.highlight.Highlight
import com.kyant.shapes.RoundedRectangle
import kotlin.math.max

private val InkColor = Color(0xFF0B0F2E)

/**
 * Halaman utama: satu card liquid glass di atas wallpaper berwarna.
 * Efek glass memakai library `backdrop` (drawBackdrop + vibrancy + blur + lens).
 */
@Composable
fun LiquidGlassCardContent() {
    val backdrop = rememberLayerBackdrop()

    var offset by remember { mutableStateOf(Offset.Zero) }
    var isPressed by remember { mutableStateOf(false) }
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed) 1.05f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 300f)
    )

    // gerakan pelan blob di wallpaper
    val drift by rememberInfiniteTransition().animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(24000, easing = LinearEasing), RepeatMode.Reverse)
    )

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = maxWidth
        val h = maxHeight
        val cardSize = 220f.dp
        val titleSize = (w.value * 0.16f).coerceIn(46f, 110f).sp

        // ---------- wallpaper + objek di belakang kaca (ini yang di-"bias" oleh glass) ----------
        Box(
            Modifier
                .fillMaxSize()
                .layerBackdrop(backdrop)
                .background(
                    Brush.verticalGradient(
                        0f to Color(0xFFDBE7FF),
                        0.3f to Color(0xFFB7CDFF),
                        0.62f to Color(0xFF7E95FF),
                        1f to Color(0xFF4B3FD0)
                    )
                )
                .drawBehind { drawWallpaper(drift) }
        ) {
            BasicText(
                "Liquid",
                Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = h * 0.09f),
                style = TextStyle(
                    color = InkColor.copy(alpha = 0.9f),
                    fontSize = titleSize,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.03f).em
                ),
                maxLines = 1,
                softWrap = false
            )

            Box(
                Modifier
                    .offset(x = w * 0.09f, y = h * 0.30f)
                    .size(120f.dp)
                    .background(Color(25, 184, 255), CircleShape)
            )
            Box(
                Modifier
                    .offset(x = w - w * 0.09f - 90f.dp, y = h * 0.35f)
                    .size(90f.dp)
                    .background(Color(123, 75, 255), CircleShape)
            )
            Box(
                Modifier
                    .offset(x = w * 0.54f, y = h * 0.41f)
                    .size(60f.dp)
                    .background(Color.White, CircleShape)
            )
            Box(
                Modifier
                    .offset(x = w * 0.06f, y = h * 0.38f)
                    .width(w * 0.88f)
                    .height(10f.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFFDBE7FF), Color(45, 91, 255), Color(123, 75, 255))
                        ),
                        RoundedCornerShape(5f.dp)
                    )
            )
        }

        BasicText(
            "Geser card untuk memindahkan",
            Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 12f.dp),
            style = TextStyle(color = InkColor.copy(alpha = 0.6f), fontSize = 12f.sp)
        )

        // ---------- CARD LIQUID GLASS ----------
        Box(
            Modifier
                .align(Alignment.TopStart)
                .offset(x = (w - cardSize) / 2f, y = h * 0.38f - cardSize / 2f)
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { RoundedRectangle(44f.dp) },
                    effects = {
                        val minDimension = size.minDimension
                        vibrancy()
                        blur(2f.dp.toPx())
                        lens(
                            refractionHeight = 0.1f * minDimension,
                            refractionAmount = 0.2f * minDimension,
                            depthEffect = true
                        )
                    },
                    highlight = { Highlight.Plain },
                    layerBlock = {
                        translationX = offset.x
                        translationY = offset.y
                        scaleX = pressScale
                        scaleY = pressScale
                    },
                    onDrawSurface = {
                        // sedikit gelap + kilau di pojok kiri atas
                        drawRect(InkColor.copy(alpha = 0.12f))
                        drawRect(
                            Brush.radialGradient(
                                colors = listOf(Color.White.copy(alpha = 0.28f), Color.Transparent),
                                center = Offset(size.width * 0.3f, size.height * 0.2f),
                                radius = size.minDimension * 0.7f
                            )
                        )
                    }
                )
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { isPressed = true },
                        onDragEnd = { isPressed = false },
                        onDragCancel = { isPressed = false },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            offset += dragAmount * pressScale
                        }
                    )
                }
                .size(cardSize)
        ) {
            Canvas(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(22f.dp)
                    .size(37f.dp)
            ) {
                drawDropIcon()
            }
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(22f.dp)
            ) {
                BasicText(
                    "Liquid Glass",
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 24f.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                BasicText(
                    "Card persegi custom",
                    Modifier.padding(top = 4f.dp),
                    style = TextStyle(color = Color.White.copy(alpha = 0.7f), fontSize = 13f.sp)
                )
            }
        }
    }
}

/** Glow putih di atas + 4 blob warna yang bergeser pelan (mirip wallpaper contoh). */
private fun DrawScope.drawWallpaper(t: Float) {
    val w = size.width
    val h = size.height
    val m = max(w, h)

    fun blob(color: Color, cx: Float, cy: Float, r: Float) {
        val c = Offset(cx, cy)
        drawCircle(
            brush = Brush.radialGradient(listOf(color, Color.Transparent), center = c, radius = r),
            radius = r,
            center = c
        )
    }

    blob(Color(123, 75, 255).copy(alpha = 0.9f), 0.10f * m + 0.14f * m * t, 0.35f * h + 0.45f * m - 0.08f * m * t, 0.45f * m)
    blob(Color(45, 91, 255).copy(alpha = 0.85f), w - 0.10f * m - 0.12f * m * t, -0.10f * h + 0.40f * m + 0.10f * m * t, 0.40f * m)
    blob(Color(25, 184, 255).copy(alpha = 0.8f), 0.05f * w + 0.35f * m + 0.10f * m * t, h - 0.12f * m * t, 0.35f * m)
    blob(Color(210, 240, 255).copy(alpha = 0.95f), 0.20f * w + 0.275f * m - 0.12f * m * t, 0.075f * m + 0.10f * m * t, 0.275f * m)

    val glowCenter = Offset(w / 2f, -0.12f * h)
    drawRect(
        Brush.radialGradient(
            0f to Color.White,
            0.3f to Color.White.copy(alpha = 0.65f),
            0.62f to Color.Transparent,
            center = glowCenter,
            radius = 0.95f * h
        )
    )
}

/** Ikon tetesan air (outline putih) di sudut kiri atas card. */
private fun DrawScope.drawDropIcon() {
    val path = Path().apply {
        moveTo(12f, 3f)
        cubicTo(15.5f, 7.2f, 18f, 10f, 18f, 13.2f)
        arcTo(Rect(6f, 7.2f, 18f, 19.2f), 0f, 180f, false)
        cubicTo(6f, 10f, 8.5f, 7.2f, 12f, 3f)
        close()
    }
    val s = size.width / 24f
    withTransform({ scale(s, s, pivot = Offset.Zero) }) {
        drawPath(
            path,
            Color.White.copy(alpha = 0.9f),
            style = Stroke(width = 1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}
