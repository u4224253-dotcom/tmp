package com.kyant.backdrop.catalog

import androidx.compose.runtime.Composable
import com.kyant.backdrop.catalog.destinations.LiquidGlassCardContent

@Composable
fun MainContent() {
    LiquidGlassCardContent()
}
